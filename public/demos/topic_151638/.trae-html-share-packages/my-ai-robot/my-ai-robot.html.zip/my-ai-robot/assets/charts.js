(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: Price Comparison ---
  var chartPrice = echarts.init(document.getElementById('chart-price'), null, { renderer: 'svg' });
  chartPrice.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      backgroundColor: bg2,
      borderColor: rule,
      textStyle: { color: ink }
    },
    legend: {
      data: ['价格（元）', '定制深度评分'],
      bottom: 0,
      textStyle: { color: muted }
    },
    grid: {
      left: '3%', right: '4%', bottom: '15%', top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['Lite 轻享版', 'Standard 标准版', 'Pro 高定版', 'Ultimate 旗舰版'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 11 }
    },
    yAxis: [
      {
        type: 'value', name: '价格（元）', nameTextStyle: { color: muted },
        axisLine: { show: false },
        splitLine: { lineStyle: { color: rule, type: 'dashed' } },
        axisLabel: { color: muted, formatter: function(v) { return v >= 10000 ? (v/10000)+'万' : v; } }
      },
      {
        type: 'value', name: '定制深度', nameTextStyle: { color: muted },
        min: 0, max: 100,
        axisLine: { show: false }, splitLine: { show: false },
        axisLabel: { color: muted }
      }
    ],
    series: [
      {
        name: '价格（元）', type: 'bar',
        data: [9800, 29800, 59800, 98000],
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: accent }, { offset: 1, color: accent + '40' }
          ]),
          borderRadius: [6, 6, 0, 0]
        },
        barWidth: '40%'
      },
      {
        name: '定制深度评分', type: 'line', yAxisIndex: 1,
        data: [30, 55, 80, 98],
        symbol: 'circle', symbolSize: 10,
        lineStyle: { color: accent2, width: 3 },
        itemStyle: { color: accent2, borderColor: bg2, borderWidth: 2 }
      }
    ]
  });
  window.addEventListener('resize', function() { chartPrice.resize(); });

  // --- Chart: Revenue Forecast ---
  var chartRevenue = echarts.init(document.getElementById('chart-revenue'), null, { renderer: 'svg' });
  chartRevenue.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis', appendToBody: true,
      backgroundColor: bg2, borderColor: rule,
      textStyle: { color: ink }
    },
    legend: {
      data: ['硬件销售', 'AI订阅', '虚拟商城', '品牌联名', 'B端服务'],
      bottom: 0,
      textStyle: { color: muted }
    },
    grid: {
      left: '3%', right: '4%', bottom: '15%', top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['Y1 Q1', 'Y1 Q2', 'Y1 Q3', 'Y1 Q4', 'Y2 Q1', 'Y2 Q2', 'Y2 Q3', 'Y2 Q4', 'Y3 Q1', 'Y3 Q2', 'Y3 Q3', 'Y3 Q4'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: {
        color: muted,
        formatter: function(value, index) {
          var years = ['第1年','','','','','第2年','','','','','第3年','',''];
          return years[index] ? years[index] + '\n' + value : value;
        }
      }
    },
    yAxis: {
      type: 'value', name: '万元', nameTextStyle: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted }
    },
    series: [
      {
        name: '硬件销售', type: 'bar', stack: 'total',
        data: [800, 1500, 2500, 4000, 6000, 8000, 12000, 15000, 18000, 22000, 26000, 30000],
        itemStyle: { color: accent }
      },
      {
        name: 'AI订阅', type: 'bar', stack: 'total',
        data: [50, 120, 300, 500, 800, 1200, 1800, 2500, 3500, 4500, 5500, 7000],
        itemStyle: { color: accent2 }
      },
      {
        name: '虚拟商城', type: 'bar', stack: 'total',
        data: [20, 60, 150, 300, 500, 800, 1200, 1800, 2500, 3200, 4000, 5000],
        itemStyle: { color: muted }
      },
      {
        name: '品牌联名', type: 'bar', stack: 'total',
        data: [0, 0, 0, 500, 0, 800, 1500, 2000, 1000, 1500, 2500, 3000],
        itemStyle: { color: accent + '80' }
      },
      {
        name: 'B端服务', type: 'bar', stack: 'total',
        data: [0, 0, 0, 0, 0, 0, 500, 1500, 2000, 3500, 5000, 8000],
        itemStyle: { color: accent2 + '80' }
      }
    ]
  });
  window.addEventListener('resize', function() { chartRevenue.resize(); });
})();
