# FastTicket AI

AI 购票策略实验室 —— 基于不同热度场景模拟购票过程，体验 AI 如何帮助用户提升购票成功率。

## 项目说明

本项目为 **AI 购票策略模拟 Demo**，所有场景均为演示用途：

- 不连接真实票务平台
- 不提供自动抢票功能
- 不采集任何用户隐私数据

旨在展示：场景热度分析、准备度优化、策略推演、结果复盘等 AI 辅助决策能力。

## 技术栈

- React 18 + TypeScript
- Vite 5
- TailwindCSS
- Framer Motion

## 快速开始

```bash
# 安装依赖
npm install

# 开发模式
npm run dev

# 生产构建
npm run build

# 预览构建产物
npm run preview
```

## 项目结构

```
src/
  components/    # 公共组件
  context/       # 全局状态管理
  data/          # 模拟场景数据
  pages/         # 页面组件
  App.tsx        # 应用入口
  index.css      # 全局样式
  main.tsx       # 渲染入口
```

## 许可证

仅供比赛展示与学习交流使用。
