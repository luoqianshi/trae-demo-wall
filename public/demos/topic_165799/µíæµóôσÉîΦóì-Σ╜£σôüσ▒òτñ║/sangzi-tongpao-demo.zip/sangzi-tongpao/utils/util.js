// utils/util.js - 桑梓同袍工具函数

/**
 * 格式化时间为 YYYY-MM-DD HH:mm
 */
function formatTime(date) {
  const d = date || new Date();
  const year = d.getFullYear();
  const month = padZero(d.getMonth() + 1);
  const day = padZero(d.getDate());
  const hour = padZero(d.getHours());
  const minute = padZero(d.getMinutes());
  return year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
}

function padZero(n) {
  return n < 10 ? '0' + n : '' + n;
}

/**
 * 计算两个经纬度之间的距离（km）
 */
function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return (R * c).toFixed(1);
}

/**
 * 生成唯一ID
 */
function generateId() {
  return 'ORD' + Date.now() + Math.random().toString(36).substr(2, 5).toUpperCase();
}

/**
 * 获取状态文本
 */
function getStatusText(status) {
  const map = {
    'pending': '等待接单',
    'accepted': '服务中',
    'completed': '已完成',
    'cancelled': '已取消'
  };
  return map[status] || status;
}

module.exports = {
  formatTime,
  getDistance,
  generateId,
  getStatusText
};
