// pages/profile/profile.js - 个人中心逻辑
Page({
  data: {
    userInfo: {},
    communityName: '幸福社区',
    isVolunteer: false,
    isStaff: false,
    showAbout: false
  },

  onShow() {
    this.loadUserInfo();
  },

  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo') || {
      name: '王奶奶',
      role: '老人端用户',
      avatar: '👵',
      age: 78,
      serviceHours: 0
    };
    const isVolunteer = userInfo.role === '志愿者';
    const isStaff = userInfo.role === '社区工作人员';
    this.setData({ userInfo, isVolunteer, isStaff });
  },

  switchRole() {
    // 测试版：三种角色循环切换（老人 → 志愿者 → 社区工作人员 → 老人）
    const current = this.data.userInfo.role;
    const cycle = ['老人端用户', '志愿者', '社区工作人员'];
    const avatars = ['👵', '👩', '🏢'];
    const names = ['王奶奶', '张伯', '李阿姨'];
    const currentIndex = cycle.indexOf(current);
    const nextIndex = (currentIndex + 1) % cycle.length;
    const newRole = cycle[nextIndex];
    const newAvatar = avatars[nextIndex];
    const newName = names[nextIndex];

    const userInfo = { ...this.data.userInfo, role: newRole, avatar: newAvatar, name: newName };
    this.setData({
      userInfo,
      isVolunteer: newRole === '志愿者',
      isStaff: newRole === '社区工作人员'
    });
    wx.setStorageSync('userInfo', userInfo);
    wx.showToast({
      title: '已切换为' + newRole,
      icon: 'none'
    });
  },

  onMenuTap(e) {
    const menu = e.currentTarget.dataset.menu;
    const isVolunteer = this.data.isVolunteer;
    const isStaff = this.data.isStaff;
    switch (menu) {
      case 'register-volunteer':
        wx.showModal({
          title: '志愿者注册',
          content: '志愿者注册功能将在完整版中开放。注册后您可以接单为社区老人提供帮助。\n注意：志愿者年龄须在18-69岁之间。',
          showCancel: false
        });
        break;
      case 'training':
        wx.showModal({
          title: '技能培训',
          content: '提供量血压、按摩、急救等在线培训课程，通过考核后可解锁对应服务接单权限。',
          showCancel: false
        });
        break;
      case 'service-hours':
        if (isVolunteer) {
          wx.showModal({
            title: '我的服务时长',
            content: '当前累计服务时长：' + (this.data.userInfo.serviceHours || 0) + ' 小时\n\n根据国家互助养老政策，您积累的志愿服务时长将直接影响您将来需要帮助时，志愿者响应您求助的优先级。\n\n规则：\n· 每完成一次服务，按实际服务时间累计时长\n· 服务时长永不清零，终身有效\n· 时长越久，未来享受互助服务越优先',
            showCancel: false
          });
        } else if (isStaff) {
          wx.showModal({
            title: '监督时长',
            content: '当前累计监督时长：' + (this.data.userInfo.serviceHours || 0) + ' 小时\n\n作为社区工作人员，您的监督记录体现了对社区互助养老服务的支持与管理贡献。',
            showCancel: false
          });
        } else {
          wx.showModal({
            title: '已存时长',
            content: '当前已存时长：' + (this.data.userInfo.serviceHours || 0) + ' 小时\n\n已存时长是您或家人过去作为志愿者服务时积累的时长。根据互助养老政策，这些时长可以在您需要求助时，提升志愿者响应您求助的优先级。\n\n时长永不清零，终身有效。',
            showCancel: false
          });
        }
        break;
      case 'emergency-contacts':
        wx.showModal({
          title: '紧急联系人设置',
          content: '当前联系人：女儿 138****1234\n\n紧急联系人设置功能将在完整版中开放。',
          showCancel: false
        });
        break;
      case 'about':
        this.setData({ showAbout: !this.data.showAbout });
        break;
    }
  }
});
