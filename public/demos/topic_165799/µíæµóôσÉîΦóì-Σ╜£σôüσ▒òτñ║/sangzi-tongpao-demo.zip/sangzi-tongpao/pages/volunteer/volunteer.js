// pages/volunteer/volunteer.js - 志愿者接单大厅逻辑
const app = getApp();

Page({
  data: {
    orders: [],
    filteredOrders: [],
    currentFilter: 'all',
    orderCount: 0,
    // 服务类型与筛选分类的映射
    typeFilterMap: {
      '量血压': 'health', '测血糖': 'health', '按摩': 'health',
      '买药': 'errand', '取快递': 'errand', '代买菜': 'errand',
      '陪聊天': 'chat', '其他': 'chat'
    }
  },

  onLoad() {
    this.loadOrders();
  },

  onShow() {
    this.loadOrders();
  },

  // 加载工单（Demo 阶段使用模拟数据）
  loadOrders() {
    const orders = app.globalData.mockOrders.map(order => ({
      ...order,
      status: order.status === 'completed' ? 'pending' : order.status
    }));

    // 添加更多模拟工单
    const extraOrders = [
      {
        id: 'MOCK004',
        type: '代买菜',
        elderName: '赵奶奶',
        elderPhone: '136****3456',
        address: '幸福社区 6号楼 101室',
        distance: '0.4km',
        status: 'pending',
        createTime: '2026-07-10 11:00',
        description: '需要帮忙买一些新鲜蔬菜和鸡蛋'
      },
      {
        id: 'MOCK005',
        type: '测血糖',
        elderName: '孙爷爷',
        elderPhone: '135****7890',
        address: '幸福社区 1号楼 601室',
        distance: '0.6km',
        status: 'pending',
        createTime: '2026-07-10 11:30',
        description: '糖尿病老人，需要定期测血糖'
      }
    ];

    const allOrders = [...orders, ...extraOrders];
    this.setData({
      orders: allOrders,
      filteredOrders: allOrders,
      orderCount: allOrders.filter(o => o.status === 'pending').length
    });
  },

  // 获取类型图标
  getTypeIcon(type) {
    const icons = {
      '量血压': '🩺', '测血糖': '🩸', '按摩': '💆',
      '买药': '💊', '取快递': '📦', '代买菜': '🥬',
      '陪聊天': '💬', '其他': '📋'
    };
    return icons[type] || '📋';
  },

  // 筛选切换
  onFilterTap(e) {
    const filter = e.currentTarget.dataset.filter;
    let filtered = this.data.orders;

    if (filter === 'nearby') {
      filtered = [...filtered].sort((a, b) => {
        const da = parseFloat(a.distance);
        const db = parseFloat(b.distance);
        return da - db;
      });
    } else if (filter !== 'all') {
      const map = this.data.typeFilterMap;
      filtered = filtered.filter(o => map[o.type] === filter);
    }

    this.setData({
      currentFilter: filter,
      filteredOrders: filtered,
      orderCount: filtered.filter(o => o.status === 'pending').length
    });
  },

  // 查看工单详情
  onOrderDetail(e) {
    const order = e.currentTarget.dataset.order;
    wx.showModal({
      title: order.type + ' - ' + order.elderName,
      content: '地址：' + order.address + '\n描述：' + order.description + '\n距离：' + order.distance,
      confirmText: '接单',
      cancelText: '返回',
      success: (res) => {
        if (res.confirm) {
          this.acceptOrder(order.id);
        }
      }
    });
  },

  // 接单
  onAcceptOrder(e) {
    const id = e.currentTarget.dataset.id;
    this.acceptOrder(id);
  },

  acceptOrder(id) {
    wx.showModal({
      title: '确认接单',
      content: '确认接下这个求助工单吗？接单后请在30分钟内到达。',
      confirmText: '确认接单',
      confirmColor: '#D4691E',
      success: (res) => {
        if (res.confirm) {
          // 更新本地数据
          const orders = this.data.orders.map(o => {
            if (o.id === id) {
              return { ...o, status: 'accepted', volunteerName: '我' };
            }
            return o;
          });
          this.setData({ orders, filteredOrders: orders });

          wx.showToast({
            title: '接单成功！',
            icon: 'success'
          });

          // 模拟通知
          setTimeout(() => {
            wx.showModal({
              title: '温馨提示',
              content: '已通知求助老人您正在前往，请准时到达。到达后请点击"签到"。',
              showCancel: false
            });
          }, 1500);
        }
      }
    });
  }
});
