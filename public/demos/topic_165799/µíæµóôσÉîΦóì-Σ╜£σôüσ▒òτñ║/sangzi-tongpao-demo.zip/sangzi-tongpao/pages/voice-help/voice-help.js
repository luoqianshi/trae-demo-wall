// pages/voice-help/voice-help.js - 语音/文字求助逻辑
const app = getApp();

Page({
  data: {
    serviceTypes: ['量血压', '测血糖', '按摩', '买药', '取快递', '代买菜', '陪聊天', '其他'],
    serviceIcons: ['🩺', '🩸', '💆', '💊', '📦', '🥬', '💬', '📋'],
    selectedType: '',
    voiceText: '',
    description: '',
    isRecording: false,
    recorderManager: null,
    submitting: false
  },

  onLoad(options) {
    // 如果从首页快捷入口带参数过来
    if (options.type) {
      this.setData({ selectedType: decodeURIComponent(options.type) });
    }
    // 初始化录音管理器
    this.data.recorderManager = wx.getRecorderManager();
    this.data.recorderManager.onStart(() => {
      this.setData({ isRecording: true });
    });
    this.data.recorderManager.onStop((res) => {
      this.setData({ isRecording: false });
      // 模拟语音识别结果
      this.simulateVoiceRecognition();
    });
    this.data.recorderManager.onError((err) => {
      console.log('录音错误:', err);
      this.setData({ isRecording: false });
      wx.showToast({ title: '录音失败', icon: 'none' });
    });
  },

  // 切换录音
  toggleRecording() {
    if (this.data.isRecording) {
      this.data.recorderManager.stop();
    } else {
      this.data.recorderManager.start({
        duration: 30000,
        format: 'mp3'
      });
    }
  },

  // 模拟语音识别（Demo 阶段，实际需接入 ASR API）
  simulateVoiceRecognition() {
    wx.showLoading({ title: '识别中...' });
    setTimeout(() => {
      wx.hideLoading();
      const mockResults = [
        '我需要量血压',
        '帮我买一下降压药',
        '可以帮我按摩一下肩膀吗',
        '帮我取一下快递'
      ];
      const result = mockResults[Math.floor(Math.random() * mockResults.length)];
      this.setData({ voiceText: result });
      this.autoSelectType(result);
    }, 1000);
  },

  // 根据语音结果自动选择类型
  autoSelectType(text) {
    const keywords = {
      '量血压': ['血压'],
      '测血糖': ['血糖'],
      '按摩': ['按摩'],
      '买药': ['买药', '降压药'],
      '取快递': ['快递'],
      '代买菜': ['买菜', '菜'],
      '陪聊天': ['聊天', '陪']
    };
    for (const [type, words] of Object.entries(keywords)) {
      if (words.some(w => text.includes(w))) {
        this.setData({ selectedType: type });
        break;
      }
    }
  },

  // 选择服务类型
  onTypeSelect(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      selectedType: this.data.selectedType === type ? '' : type
    });
  },

  // 输入描述
  onDescInput(e) {
    this.setData({ description: e.detail.value });
  },

  // 提交求助
  onSubmit() {
    const { selectedType, voiceText, description } = this.data;
    if (!selectedType && !voiceText) {
      wx.showToast({ title: '请选择服务类型或录音', icon: 'none' });
      return;
    }

    this.setData({ submitting: true });
    wx.showLoading({ title: '提交中...' });

    // 模拟提交
    setTimeout(() => {
      wx.hideLoading();
      this.setData({ submitting: false });

      // 创建模拟订单
      const newOrder = {
        id: 'MOCK' + Date.now(),
        type: selectedType || '其他',
        elderName: wx.getStorageSync('userInfo').name || '王奶奶',
        elderPhone: '138****1234',
        address: '幸福社区 3号楼 501室',
        distance: '0.3km',
        status: 'pending',
        createTime: app.formatTime(new Date()),
        description: description || voiceText
      };

      // 添加到全局数据
      app.globalData.mockOrders.unshift(newOrder);

      wx.showToast({
        title: '求助已发送！',
        icon: 'success'
      });

      setTimeout(() => {
        wx.showModal({
          title: '求助已发布',
          content: '附近的志愿者会很快收到您的求助，请耐心等待。您可以返回首页查看进度。',
          confirmText: '返回首页',
          showCancel: false,
          success: () => {
            wx.switchTab({ url: '/pages/index/index' });
          }
        });
      }, 1500);
    }, 1500);
  }
});
