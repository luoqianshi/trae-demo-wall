// pages/login/login.js - 登录/角色选择逻辑
Page({
  data: {
    selectedRole: '',
    name: '',
    age: '',
    phone: '',
    communityIndex: -1,
    communities: ['幸福社区', '阳光社区', '和谐社区', '康乐社区'],
    canLogin: false
  },

  selectRole(e) {
    const role = e.currentTarget.dataset.role;
    this.setData({ selectedRole: role });
    this.checkCanLogin();
  },

  onNameInput(e) {
    this.setData({ name: e.detail.value });
    this.checkCanLogin();
  },

  onAgeInput(e) {
    this.setData({ age: e.detail.value });
    this.checkCanLogin();
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
    this.checkCanLogin();
  },

  onCommunityChange(e) {
    this.setData({ communityIndex: e.detail.value });
    this.checkCanLogin();
  },

  checkCanLogin() {
    const { selectedRole, name, age, phone, communityIndex } = this.data;
    this.setData({
      canLogin: selectedRole && name.length > 0 && age.length > 0 && phone.length === 11 && communityIndex >= 0
    });
  },

  // 年龄校验
  validateAge() {
    const ageNum = parseInt(this.data.age);
    if (isNaN(ageNum) || ageNum < 0 || ageNum > 150) {
      wx.showToast({ title: '请输入有效的年龄', icon: 'none' });
      return false;
    }
    if (this.data.selectedRole === 'volunteer') {
      if (ageNum < 18) {
        wx.showToast({ title: '未满18岁，无法注册为志愿者', icon: 'none' });
        return false;
      }
      if (ageNum >= 70) {
        wx.showToast({ title: '年满70岁，无法注册为志愿者', icon: 'none' });
        return false;
      }
    }
    // 社区工作人员无年龄限制
    return true;
  },

  onLogin() {
    if (!this.data.canLogin) return;

    // 年龄校验
    if (!this.validateAge()) return;

    const { selectedRole, name, age, phone, communityIndex, communities } = this.data;
    const roleMap = {
      'elderly': '老人端用户',
      'volunteer': '志愿者',
      'staff': '社区工作人员'
    };
    const avatarMap = {
      'elderly': '👵',
      'volunteer': '👩',
      'staff': '🏢'
    };
    const userInfo = {
      name,
      age: parseInt(age),
      phone,
      role: roleMap[selectedRole],
      avatar: avatarMap[selectedRole],
      community: communities[communityIndex],
      serviceHours: 0,  // 服务时长（小时），初始为 0
      serviceMinutes: 0  // 服务分钟数，用于精确累计
    };

    wx.setStorageSync('userInfo', userInfo);
    wx.showToast({ title: '登录成功', icon: 'success' });

    setTimeout(() => {
      wx.switchTab({ url: '/pages/index/index' });
    }, 1000);
  }
});