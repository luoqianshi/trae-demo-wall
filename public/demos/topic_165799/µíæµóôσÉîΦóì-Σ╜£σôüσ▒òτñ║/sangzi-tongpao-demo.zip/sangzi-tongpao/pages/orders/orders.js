// pages/orders/orders.js - 订单/服务列表逻辑
const app = getApp();

Page({
  data: {
    isVolunteer: false,
    orders: [],
    displayOrders: [],
    statusText: {
      'pending': '等待接单',
      'accepted': '服务中',
      'completed': '已完成',
      'cancelled': '已取消'
    }
  },

  onShow() {
    this.refreshData();
  },

  refreshData() {
    const userInfo = wx.getStorageSync('userInfo') || {};
    const isVolunteer = userInfo.role === '志愿者';
    this.setData({ isVolunteer });

    this.setData({
      orders: app.globalData.mockOrders
    });
    this.filterOrders();
  },

  filterOrders() {
    const { orders, isVolunteer } = this.data;
    if (!isVolunteer) {
      // 老人端：显示发出的求助
      this.setData({ displayOrders: orders.slice(0, 5) });
    } else {
      // 志愿者端：显示接过的单
      const accepted = orders.filter(o => o.status === 'accepted' || o.status === 'completed');
      this.setData({ displayOrders: accepted.length > 0 ? accepted : orders.slice(0, 3) });
    }
  },

  getTypeIcon(type) {
    const icons = {
      '量血压': '🩺', '测血糖': '🩸', '按摩': '💆',
      '买药': '💊', '取快递': '📦', '代买菜': '🥬',
      '陪聊天': '💬', '其他': '📋'
    };
    return icons[type] || '📋';
  },

  confirmOrder(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认完成',
      content: '确认服务已完成吗？确认后将累计服务时长。',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(id, 'completed');
          // 完成一项任务，服务时长 + 1
          this.addServiceHours(1);
          wx.showToast({ title: '已确认完成！时长+1', icon: 'success' });
        }
      }
    });
  },

  // 增加服务时长
  addServiceHours(hours) {
    const userInfo = wx.getStorageSync('userInfo') || {};
    const currentHours = userInfo.serviceHours || 0;
    const newHours = Number(currentHours) + Number(hours);
    userInfo.serviceHours = newHours;
    wx.setStorageSync('userInfo', userInfo);
    console.log('服务时长增加：' + currentHours + ' -> ' + newHours);
  },

  updateOrderStatus(id, status) {
    const orders = this.data.orders.map(o => {
      if (o.id === id) return { ...o, status };
      return o;
    });
    this.setData({ orders });
    app.globalData.mockOrders = orders;
    this.filterOrders();
  }
});