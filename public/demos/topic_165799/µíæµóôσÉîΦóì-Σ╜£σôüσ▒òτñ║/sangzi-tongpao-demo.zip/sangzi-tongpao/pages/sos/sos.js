// pages/sos/sos.js - 紧急求助逻辑
Page({
  data: {
    sosActive: true,
    location: null
  },

  onLoad() {
    this.getLocation();
    this.triggerSosAlert();
  },

  onUnload() {
    // 页面卸载时可以做一些清理
  },

  // 获取位置
  getLocation() {
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        this.setData({
          location: {
            latitude: res.latitude,
            longitude: res.longitude,
            address: '正在解析地址...'
          }
        });
        // 模拟地址解析
        setTimeout(() => {
          this.setData({
            'location.address': '幸福社区 3号楼附近'
          });
        }, 1500);
      },
      fail: () => {
        this.setData({
          location: { address: '位置获取失败，请检查定位权限' }
        });
      }
    });
  },

  // 触发紧急通知
  triggerSosAlert() {
    wx.vibrateLong();
    wx.showModal({
      title: '紧急求助已触发',
      content: '已通知社区值班人员，请保持冷静，选择下方操作获取帮助。',
      confirmText: '我知道了',
      confirmColor: '#C0392B',
      showCancel: false
    });
  },

  // 联系社区
  onCallCommunity() {
    wx.showModal({
      title: '联系社区',
      content: '已向幸福社区值班人员发送紧急求助通知。\n值班电话：010-88881234\n是否拨打电话？',
      confirmText: '拨打电话',
      cancelText: '已通知即可',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({ phoneNumber: '01088881234' });
        }
      }
    });
  },

  // 拨打120
  onCallEmergency() {
    wx.showModal({
      title: '拨打急救电话',
      content: '即将拨打 120 急救电话，请确认。',
      confirmText: '确认拨打',
      confirmColor: '#C0392B',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({ phoneNumber: '120' });
        }
      }
    });
  },

  // 通知家人
  onCallFamily() {
    wx.showModal({
      title: '通知家人',
      content: '已向您的紧急联系人发送紧急求助消息（含当前位置）。\n联系人：女儿 138****1234\n是否拨打电话？',
      confirmText: '拨打电话',
      cancelText: '已通知即可',
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({ phoneNumber: '13800123456' });
        }
      }
    });
  },

  // 共享位置
  onShareLocation() {
    wx.showModal({
      title: '位置共享',
      content: '已将您的实时位置共享给社区值班人员和紧急联系人。',
      showCancel: false,
      confirmText: '好的'
    });
  },

  // 取消紧急求助
  onCancelSos() {
    wx.showModal({
      title: '取消求助',
      content: '确认取消紧急求助吗？如果情况已缓解，建议通知社区工作人员。',
      confirmText: '确认取消',
      confirmColor: '#C0392B',
      success: (res) => {
        if (res.confirm) {
          this.setData({ sosActive: false });
          wx.switchTab({ url: '/pages/index/index' });
        }
      }
    });
  }
});
