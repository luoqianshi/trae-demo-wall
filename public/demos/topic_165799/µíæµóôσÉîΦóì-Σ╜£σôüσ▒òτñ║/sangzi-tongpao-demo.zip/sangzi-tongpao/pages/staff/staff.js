// pages/staff/staff.js - 社区工作人员监督看板
const app = getApp();

Page({
  data: {
    allOrders: [],
    pendingCount: 0,
    acceptedCount: 0,
    completedCount: 0,
    statusText: {
      'pending': '等待接单',
      'accepted': '服务中',
      'completed': '已完成',
      'cancelled': '已取消'
    }
  },

  onLoad() {
    this.loadOrders();
  },

  onShow() {
    this.loadOrders();
  },

  loadOrders() {
    const orders = app.globalData.mockOrders;
    const pending = orders.filter(o => o.status === 'pending').length;
    const accepted = orders.filter(o => o.status === 'accepted').length;
    const completed = orders.filter(o => o.status === 'completed').length;
    this.setData({
      allOrders: orders,
      pendingCount: pending,
      acceptedCount: accepted,
      completedCount: completed
    });
  },

  getTypeIcon(type) {
    const icons = { '量血压': '🩺', '测血糖': '🩸', '按摩': '💆', '买药': '💊', '取快递': '📦', '代买菜': '🥬', '陪聊天': '💬', '其他': '📋' };
    return icons[type] || '📋';
  },

  isOverdue(item) {
    // 超过30分钟无人接单算超时
    const createTime = new Date(item.createTime).getTime();
    return (Date.now() - createTime) > 30 * 60 * 1000;
  },

  onEvaluate(e) {
    const order = e.currentTarget.dataset.order;
    wx.showModal({
      title: '评价服务',
      content: '服务者：' + (order.volunteerName || '无') + '\n请对本次服务进行评价：',
      confirmText: '好评',
      cancelText: '一般',
      success: (res) => {
        const rating = res.confirm ? '好评' : '一般';
        wx.showToast({ title: '已记录' + rating, icon: 'success' });
      }
    });
  },

  onRemind(e) {
    const id = e.currentTarget.dataset.id;
    wx.showToast({ title: '已发送催单提醒', icon: 'success' });
  },

  goToChat(e) {
    const order = e.currentTarget.dataset.order;
    wx.navigateTo({
      url: '/pages/chat/chat?elder=' + encodeURIComponent(order.elderName) + '&volunteer=' + encodeURIComponent(order.volunteerName || '')
    });
  }
});
