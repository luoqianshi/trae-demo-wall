// pages/index/index.js - 首页（三种身份共用）
const app = getApp();

Page({
  data: {
    userInfo: {},
    communityName: '幸福社区',
    greeting: '',
    isElderly: false,
    isVolunteer: false,
    isStaff: false,
    serviceHours: 0,
    completedOrders: 0,
    pendingCount: 0,
    completedCount: 0,
    allOrders: [],
    // 老人端数据
    serviceTypes: ['量血压', '测血糖', '按摩', '买药', '取快递', '代买菜', '陪聊天', '其他'],
    serviceIcons: ['🩺', '🩸', '💆', '💊', '📦', '🥬', '💬', '📋'],
    recentOrders: [],
    // 志愿者端数据
    pendingOrders: [],
    // 状态文字
    statusText: {
      'pending': '等待接单',
      'accepted': '服务中',
      'completed': '已完成',
      'cancelled': '已取消'
    },
    sosTimer: null,
    sosPressed: false
  },

  onLoad() {
    this.setGreeting();
    this.loadUserInfo();
  },

  onShow() {
    this.setGreeting();
    this.refreshData();
  },

  setGreeting() {
    const hour = new Date().getHours();
    let greeting = '您好';
    if (hour < 6) greeting = '夜深了';
    else if (hour < 9) greeting = '早上好';
    else if (hour < 12) greeting = '上午好';
    else if (hour < 14) greeting = '中午好';
    else if (hour < 18) greeting = '下午好';
    else greeting = '晚上好';
    this.setData({ greeting });
  },

  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo') || { name: '王奶奶', role: '老人端用户' };
    this.setData({
      userInfo,
      isElderly: userInfo.role === '老人端用户',
      isVolunteer: userInfo.role === '志愿者',
      isStaff: userInfo.role === '社区工作人员'
    });
  },

  refreshData() {
    this.loadUserInfo();
    if (this.data.isElderly) {
      this.loadRecentOrders();
    } else if (this.data.isVolunteer) {
      this.loadPendingOrders();
      this.calculateStats();
    } else if (this.data.isStaff) {
      this.loadAllOrders();
    }
  },

  loadRecentOrders() {
    this.setData({
      recentOrders: app.globalData.mockOrders.slice(0, 3)
    });
  },

  loadPendingOrders() {
    const pending = app.globalData.mockOrders.filter(o => o.status === 'pending');
    this.setData({
      pendingOrders: pending.slice(0, 3),
      pendingCount: pending.length
    });
  },

  loadAllOrders() {
    const orders = app.globalData.mockOrders;
    const pending = orders.filter(o => o.status === 'pending').length;
    const completed = orders.filter(o => o.status === 'completed').length;
    this.setData({
      allOrders: orders,
      pendingCount: pending,
      completedCount: completed
    });
  },

  calculateStats() {
    const completed = app.globalData.mockOrders.filter(o => o.status === 'completed' && o.volunteerName === this.data.userInfo.name);
    let hours = 0;
    completed.forEach(() => { hours += 0.5 + Math.random() * 0.5; });
    this.setData({
      serviceHours: Number(hours.toFixed(1)),
      completedOrders: completed.length
    });
  },

  sosStart(e) {
    this.setData({ sosPressed: true });
    this.data.sosTimer = setTimeout(() => { this.triggerSos(); }, 3000);
  },

  sosEnd(e) {
    this.setData({ sosPressed: false });
    if (this.data.sosTimer) {
      clearTimeout(this.data.sosTimer);
      this.data.sosTimer = null;
    }
  },

  triggerSos() {
    this.setData({ sosPressed: false });
    wx.showModal({
      title: '紧急求助',
      content: '即将通知社区工作者和紧急联系人，是否确认？',
      confirmText: '确认求助',
      confirmColor: '#C0392B',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({ url: '/pages/sos/sos' });
        }
      }
    });
  },

  onSosTap() {
    wx.showModal({
      title: '紧急求助说明',
      content: '请长按红色 SOS 按钮 3 秒触发紧急求助。松开可取消。',
      showCancel: false,
      confirmText: '我知道了'
    });
  },

  onVoiceTap() {
    wx.navigateTo({ url: '/pages/voice-help/voice-help' });
  },

  onServiceTap(e) {
    const type = e.currentTarget.dataset.type;
    wx.navigateTo({ url: '/pages/voice-help/voice-help?type=' + encodeURIComponent(type) });
  },

  onOrderTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/orders/orders?id=' + id });
  },

  onVolunteerOrderTap(e) {
    const order = e.currentTarget.dataset.order;
    wx.showModal({
      title: order.type + ' - ' + order.elderName,
      content: '地址：' + order.address + '\n描述：' + order.description + '\n距离：' + order.distance,
      confirmText: '接单',
      cancelText: '返回',
      success: (res) => {
        if (res.confirm) { this.acceptOrder(order.id); }
      }
    });
  },

  onAcceptOrder(e) {
    const id = typeof e === 'string' ? e : e.currentTarget.dataset.id;
    this.acceptOrder(id);
  },

  acceptOrder(id) {
    wx.showModal({
      title: '确认接单',
      content: '确认接下这个求助工单吗？接单后请在30分钟内到达。',
      confirmText: '确认接单',
      confirmColor: '#D4691E',
      success: (res) => {
        if (res.confirm) {
          const orders = app.globalData.mockOrders.map(o => {
            if (o.id === id) { return { ...o, status: 'accepted', volunteerName: this.data.userInfo.name }; }
            return o;
          });
          app.globalData.mockOrders = orders;
          this.refreshData();
          wx.showToast({ title: '接单成功！', icon: 'success' });
          setTimeout(() => {
            wx.showModal({
              title: '温馨提示',
              content: '已通知求助老人您正在前往，请准时到达。服务完成后请记得点击"确认完成"。',
              showCancel: false
            });
          }, 1500);
        }
      }
    });
  },

  onViewAllOrders() {
    wx.switchTab({ url: '/pages/orders/orders' });
  },

  goToStaffPage() {
    wx.navigateTo({ url: '/pages/staff/staff' });
  },

  goToChat() {
    wx.navigateTo({ url: '/pages/chat/chat' });
  },

  getTypeIcon(type) {
    const icons = { '量血压': '🩺', '测血糖': '🩸', '按摩': '💆', '买药': '💊', '取快递': '📦', '代买菜': '🥬', '陪聊天': '💬', '其他': '📋' };
    return icons[type] || '📋';
  }
});
