// pages/chat/chat.js - 社区群聊（模拟）
Page({
  data: {
    chatTitle: '幸福社区互助群',
    members: ['王奶奶', '李阿姨', '张伯'],
    inputValue: '',
    scrollToId: '',
    messages: [
      {
        id: 1,
        name: '系统通知',
        avatar: '📢',
        text: '欢迎来到幸福社区互助群！老人、志愿者和社区工作人员可以在此沟通。',
        time: '09:00',
        isSelf: false
      },
      {
        id: 2,
        name: '王奶奶',
        avatar: '👵',
        text: '请问有人可以帮我量一下血压吗？',
        time: '09:05',
        isSelf: false
      },
      {
        id: 3,
        name: '李阿姨',
        avatar: '👩',
        text: '王奶奶，我这就过去，大概10分钟到。',
        time: '09:06',
        isSelf: false
      },
      {
        id: 4,
        name: '张伯',
        avatar: '🏢',
        text: '好的，我已收到工单，请准时到达，到达后请记得确认完成。如有问题随时联系我。',
        time: '09:07',
        isSelf: false
      }
    ],
    nextId: 5
  },

  onLoad(options) {
    const userInfo = wx.getStorageSync('userInfo') || { name: '我', avatar: '👤' };
    let chatTitle = '幸福社区互助群';
    if (options.elder && options.volunteer) {
      chatTitle = options.elder + ' · ' + options.volunteer;
    }
    this.setData({
      myName: userInfo.name,
      myAvatar: userInfo.avatar,
      chatTitle: chatTitle
    });
    this.scrollToBottom();
  },

  onInput(e) {
    this.setData({ inputValue: e.detail.value });
  },

  onSend() {
    const text = this.data.inputValue.trim();
    if (!text) return;

    const newMsg = {
      id: this.data.nextId,
      name: this.data.myName,
      avatar: this.data.myAvatar,
      text: text,
      time: this.formatTime(),
      isSelf: true
    };

    const messages = [...this.data.messages, newMsg];
    this.setData({
      messages: messages,
      inputValue: '',
      nextId: this.data.nextId + 1
    });
    this.scrollToBottom();

    // 模拟对方回复
    this.simulateReply();
  },

  simulateReply() {
    setTimeout(() => {
      const replies = [
        { name: '张伯', avatar: '🏢', text: '收到，正在跟进中。' },
        { name: '李阿姨', avatar: '👩', text: '好的，马上到！' },
        { name: '王奶奶', avatar: '👵', text: '谢谢大家的帮忙！' }
      ];
      const reply = replies[Math.floor(Math.random() * replies.length)];
      const newMsg = {
        id: this.data.nextId,
        ...reply,
        time: this.formatTime(),
        isSelf: false
      };
      const messages = [...this.data.messages, newMsg];
      this.setData({
        messages: messages,
        nextId: this.data.nextId + 1
      });
      this.scrollToBottom();
    }, 2000);
  },

  scrollToBottom() {
    const lastId = this.data.messages[this.data.messages.length - 1]?.id || 0;
    this.setData({ scrollToId: 'msg-' + lastId });
  },

  formatTime() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    return h + ':' + m;
  }
});
