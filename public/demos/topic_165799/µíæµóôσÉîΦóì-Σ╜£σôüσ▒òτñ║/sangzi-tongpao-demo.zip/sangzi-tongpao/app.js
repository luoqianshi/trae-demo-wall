// app.js - 桑梓同袍全局应用逻辑
App({
  onLaunch() {
    // 兼容：清除旧缓存中的"王奶奶"
    const cachedUserInfo = wx.getStorageSync('userInfo');
    if (cachedUserInfo && cachedUserInfo.name === '王某某') {
      cachedUserInfo.name = '王奶奶';
      wx.setStorageSync('userInfo', cachedUserInfo);
      console.log('已更新缓存中的旧用户名为王奶奶');
    }
    if (!cachedUserInfo) {
      console.log('用户未登录，将跳转到登录页');
    }
    // 检查位置权限
    this.checkLocationPermission();
  },

  // 全局数据
  globalData: {
    userInfo: null,
    userType: null, // 'elderly' 老人端 / 'volunteer' 志愿者端
    communityId: null,
    location: null,
    // 模拟数据（初始为空，用户发布求助后才有数据）
    mockOrders: [],
    // 服务类型列表
    serviceTypes: ['量血压', '测血糖', '按摩', '买药', '取快递', '代买菜', '陪聊天', '其他']
  },

  // 检查位置权限
  checkLocationPermission() {
    wx.getSetting({
      success: (res) => {
        if (res.authSetting['scope.userLocation'] === false) {
          wx.showModal({
            title: '位置授权',
            content: '需要获取您的位置信息以便匹配附近志愿者',
            confirmText: '去设置',
            success: (modalRes) => {
              if (modalRes.confirm) {
                wx.openSetting();
              }
            }
          });
        } else {
          this.getLocation();
        }
      }
    });
  },

  // 获取位置
  getLocation() {
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        this.globalData.location = {
          latitude: res.latitude,
          longitude: res.longitude
        };
        console.log('位置获取成功:', this.globalData.location);
      },
      fail: (err) => {
        console.log('位置获取失败:', err);
      }
    });
  },

  // 格式化时间
  formatTime(date) {
    const d = date || new Date();
    const year = d.getFullYear();
    const month = this.padZero(d.getMonth() + 1);
    const day = this.padZero(d.getDate());
    const hour = this.padZero(d.getHours());
    const minute = this.padZero(d.getMinutes());
    return year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
  },

  padZero(n) {
    return n < 10 ? '0' + n : '' + n;
  }
});
