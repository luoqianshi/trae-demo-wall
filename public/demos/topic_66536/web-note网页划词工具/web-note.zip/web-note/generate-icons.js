/**
 * 图标生成脚本
 * 需要先安装依赖: npm install canvas
 * 运行: node generate-icons.js
 */

const { createCanvas } = require('canvas');
const fs = require('fs');

// 生成指定尺寸的图标
function generateIcon(size, filename) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  
  // 背景圆角矩形
  ctx.fillStyle = '#ff69b4';
  const radius = size * 0.15;
  ctx.beginPath();
  ctx.roundRect(0, 0, size, size, radius);
  ctx.fill();
  
  // 绘制铅笔emoji
  ctx.fillStyle = 'white';
  ctx.font = `${size * 0.5}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('✏️', size / 2, size * 0.55);
  
  // 绘制文字
  if (size >= 48) {
    ctx.font = `bold ${size * 0.12}px Arial`;
    ctx.fillText('批注', size / 2, size * 0.8);
  }
  
  // 保存为PNG
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(filename, buffer);
  console.log(`✓ 已生成 ${filename}`);
}

// 生成所有需要的图标尺寸
console.log('开始生成图标...');
generateIcon(16, 'icon16.png');
generateIcon(48, 'icon48.png');
generateIcon(128, 'icon128.png');
console.log('图标生成完成！');