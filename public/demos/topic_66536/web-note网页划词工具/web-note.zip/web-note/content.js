// 防止重复注入（扩展重新加载后会再次注入）
// 使用 DOM 属性标记，因为 content script 的隔离世界共享 DOM
(function() {
  const INJECTED_MARKER = 'data-web-note-injected';
  if (document.documentElement.hasAttribute(INJECTED_MARKER)) {
    console.log('web-note content script already injected, cleaning up old instance...');
    // 触发自定义事件通知旧实例清理
    document.dispatchEvent(new CustomEvent('web-note-reinject'));
  }
  document.documentElement.setAttribute(INJECTED_MARKER, 'true');
})();

console.log('web-note content script loaded successfully');

// 全局变量
let selectedText = '';
let selectedRange = null;
let floatingIcon = null;
let tooltip = null; // 批注气泡弹窗
let sidebar = null;
let annotationData = {};
let currentUrl = getBaseUrl(); // 使用URL的base部分（去掉hash）
let selectedColor = '#667eea';
let currentAnnotationId = null;
let isSidePanelOpen = false; // 跟踪 Chrome sidePanel 是否打开

// 获取URL的标识部分（用于区分不同页面）
// 支持 hash 路由（如 Vue hash mode: /#/page）和 history 路由
function getBaseUrl() {
  try {
    const url = new URL(window.location.href);
    const hash = url.hash;
    
    // 判断是否是 hash 路由：hash 以 #/ 开头表示是路由路径
    if (hash && hash.startsWith('#/')) {
      // hash 路由模式：保留 origin + pathname + hash路径部分（去掉hash中的query）
      const hashPath = hash.split('?')[0];
      return url.origin + url.pathname + hashPath;
    }
    
    // history 路由模式：只保留 origin + pathname（去掉 query 和 hash）
    return url.origin + url.pathname;
  } catch (e) {
    // 兜底：直接返回 href 去掉 query
    return window.location.origin + window.location.pathname;
  }
}
let isSelecting = false;
let isRestoringAnnotations = false;
let isLoadingAnnotations = false; // 防止并发加载
let pendingDomChange = false; // 数据加载期间是否有DOM变化

// 颜色选项
const colorOptions = ['#667eea', '#f6ad55', '#68d391', '#63b3ed', '#fc8181', '#b794f4'];

// 初始化
function init() {
  console.log('Initializing web-note extension...');
  console.log('Current URL (base):', currentUrl);
  
  // 启动URL变化监听（处理SPA应用）
  monitorUrlChanges();
  
  // 滚动时隐藏气泡弹窗的处理函数
  const handleScroll = () => { hideTooltip(); };
  
  // 使用selectionchange事件捕获选区变化
  document.addEventListener('selectionchange', handleSelectionChange);
  
  // 使用click事件处理图标点击和空白处点击
  document.addEventListener('click', handleClick);
  
  // 使用mouseover事件处理高亮文本悬浮
  document.addEventListener('mouseover', handleMouseOver);
  
  // 使用mouseout事件处理离开高亮文本
  document.addEventListener('mouseout', handleMouseOut);
  
  // 滚动时隐藏气泡弹窗
  window.addEventListener('scroll', handleScroll, { passive: true });
  
  // 监听URL变化（hash变化）
  window.addEventListener('hashchange', handleUrlChange);
  
  // 监听浏览器前进/后退按钮
  window.addEventListener('popstate', handleUrlChange);
  
  // 监听页面可见性变化（处理切换标签页回来的情况）
  document.addEventListener('visibilitychange', handleVisibilityChange);
  
  // 监听pageshow事件（处理BFCache恢复的情况）
  window.addEventListener('pageshow', handlePageShow);
  
  // 注册清理函数（供重复注入时调用）
  window.__webNoteCleanup = function() {
    console.log('Cleaning up old web-note instance...');
    document.removeEventListener('selectionchange', handleSelectionChange);
    document.removeEventListener('click', handleClick);
    document.removeEventListener('mouseover', handleMouseOver);
    document.removeEventListener('mouseout', handleMouseOut);
    window.removeEventListener('scroll', handleScroll);
    window.removeEventListener('hashchange', handleUrlChange);
    window.removeEventListener('popstate', handleUrlChange);
    document.removeEventListener('visibilitychange', handleVisibilityChange);
    window.removeEventListener('pageshow', handlePageShow);
    
    // 清理DOM元素（悬浮图标、气泡弹窗等，但保留高亮）
    if (floatingIcon && floatingIcon.parentNode) {
      floatingIcon.parentNode.removeChild(floatingIcon);
      floatingIcon = null;
    }
    if (tooltip && tooltip.parentNode) {
      tooltip.parentNode.removeChild(tooltip);
      tooltip = null;
    }
    // 移除旧的消息监听器
    if (window.__webNoteMessageHandler) {
      try {
        chrome.runtime.onMessage.removeListener(window.__webNoteMessageHandler);
      } catch (e) {
        // 旧的扩展上下文可能已失效，忽略
      }
    }
    // 不清理 sidebar，因为它可能正在使用
  };
  
  // 监听重新注入事件（当新的 content script 被注入时，旧实例会收到此事件并自行清理）
  document.addEventListener('web-note-reinject', window.__webNoteCleanup, { once: true });
  
  // 等待页面完全加载后再加载批注
  const loadAnnotationsWhenReady = () => {
    // 如果页面已经完全加载，立即执行
    if (document.readyState === 'complete') {
      console.log('Page already complete, loading annotations...');
      setTimeout(() => loadAnnotations(), 100);
    } else {
      // 等待 load 事件（所有资源加载完成）
      console.log('Waiting for page load...');
      window.addEventListener('load', () => {
        console.log('Page load event fired, loading annotations...');
        setTimeout(() => loadAnnotations(), 100);
      });
      // 同时设置一个兜底超时，防止 load 事件不触发
      setTimeout(() => {
        if (Object.keys(annotationData).length === 0) {
          console.log('Fallback: loading annotations after timeout...');
          loadAnnotations();
        }
      }, 3000);
    }
  };
  
  // 如果DOM已经加载完成，直接执行
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    loadAnnotationsWhenReady();
  } else {
    document.addEventListener('DOMContentLoaded', loadAnnotationsWhenReady);
  }
  
  // 通知 sidePanel（如果已打开）content script 已就绪，需要重新建立端口连接
  // 这处理了插件重新加载后旧端口失效的情况
  chrome.storage.local.set({ contentScriptReady: Date.now() });
}

// 处理URL变化
function handleUrlChange() {
  const newUrl = getBaseUrl();
  console.log('URL changed from:', currentUrl, 'to:', newUrl);
  
  if (newUrl !== currentUrl) {
    currentUrl = newUrl;
    console.log('Reloading annotations for new URL...');
    
    // 清除现有高亮（旧页面的高亮）
    clearAllHighlights();
    
    // 立即后台加载数据（不等延迟），数据加载和DOM渲染并行
    annotationData = {};
    isLoadingAnnotations = true;
    getAnnotationsFromGitee(currentUrl).then(data => {
      annotationData = data;
      isLoadingAnnotations = false;
      console.log('Background loaded annotations for URL:', currentUrl, ', count:', Object.keys(data).length);
      if (Object.keys(data).length > 0) {
        console.log('Annotation texts:', Object.values(data).map(a => a.text?.substring(0, 30)).join(' | '));
        // 数据加载完成后，尝试恢复高亮（如果DOM已准备好）
        restoreAnnotations();
        // SPA页面切换后DOM可能还在渲染，持续轮询确保高亮恢复
        schedulePostNavigationRetry(data);
      }
      // 如果数据加载期间有DOM变化被忽略了，延迟后再尝试一次
      if (pendingDomChange) {
        pendingDomChange = false;
        setTimeout(() => {
          const existingHighlights = document.querySelectorAll('.web-note-highlight');
          if (existingHighlights.length < Object.keys(annotationData).length) {
            console.log('Pending DOM change detected, restoring...');
            restoreAnnotations();
          }
        }, 500);
      }
    }).catch(err => {
      console.error('后台加载批注失败:', err);
      isLoadingAnnotations = false;
    });
  } else {
    // URL相同但可能是SPA页面切换回来，DOM已被重建
    // 延迟检查，等待DOM渲染完成
    setTimeout(() => {
      checkAndRestoreHighlights();
    }, 300);
  }
}

// SPA页面切换后持续轮询检查（确保DOM渲染完成后高亮能恢复）
function schedulePostNavigationRetry(data) {
  const expectedCount = Object.keys(data).length;
  if (expectedCount === 0) return;
  
  let elapsed = 0;
  const interval = 500; // 每500ms检查一次
  const maxTime = 15000; // 最多轮询15秒
  
  const timer = setInterval(() => {
    elapsed += interval;
    
    // 超时停止
    if (elapsed > maxTime) {
      clearInterval(timer);
      console.log('Post-navigation retry timeout, giving up');
      return;
    }
    
    // URL已变化，停止（用户已切换到其他页面）
    if (getBaseUrl() !== currentUrl) {
      clearInterval(timer);
      return;
    }
    
    // 检查高亮是否已全部恢复
    const existingHighlights = document.querySelectorAll('.web-note-highlight');
    if (existingHighlights.length >= expectedCount) {
      clearInterval(timer);
      console.log('Post-navigation: all highlights restored');
      return;
    }
    
    // 尝试恢复
    const bodyTextLen = document.body?.innerText?.length || 0;
    console.log(`Post-navigation retry at ${elapsed}ms: found ${existingHighlights.length}/${expectedCount} highlights, body text length: ${bodyTextLen}`);
    restoreAnnotations();
  }, interval);
}

// 处理页面可见性变化（切换标签页回来）
function handleVisibilityChange() {
  if (document.visibilityState === 'visible') {
    console.log('Page became visible, checking highlights...');
    // 更新当前URL（可能在不可见期间URL发生了变化）
    const newUrl = getBaseUrl();
    if (newUrl !== currentUrl) {
      currentUrl = newUrl;
      clearAllHighlights();
      annotationData = {};
      // URL变了，后台加载新数据
      isLoadingAnnotations = true;
      getAnnotationsFromGitee(currentUrl).then(data => {
        annotationData = data;
        isLoadingAnnotations = false;
        if (Object.keys(data).length > 0) {
          restoreAnnotations();
          // 多次延迟重试确保高亮恢复
          schedulePostNavigationRetry(data);
        }
      }).catch(err => {
        console.error('后台加载批注失败:', err);
        isLoadingAnnotations = false;
      });
    } else {
      // URL没变，立即检查并恢复高亮（无延迟）
      checkAndRestoreHighlights();
    }
  }
}

// 处理pageshow事件（BFCache恢复）
function handlePageShow(event) {
  if (event.persisted) {
    // 页面是从BFCache恢复的，后台静默加载
    console.log('Page restored from BFCache, background loading annotations...');
    currentUrl = getBaseUrl();
    annotationData = {};
    isLoadingAnnotations = true;
    getAnnotationsFromGitee(currentUrl).then(data => {
      annotationData = data;
      isLoadingAnnotations = false;
      if (Object.keys(data).length > 0) {
        restoreAnnotations();
      }
    }).catch(err => {
      console.error('BFCache恢复加载批注失败:', err);
      isLoadingAnnotations = false;
    });
  }
}

// 检查并恢复高亮（如果DOM中的高亮已丢失）
function checkAndRestoreHighlights() {
  const existingHighlights = document.querySelectorAll('.web-note-highlight');
  const annotationCount = Object.keys(annotationData).length;
  
  console.log('Checking highlights: existing=', existingHighlights.length, ', expected=', annotationCount);
  
  if (annotationCount > 0 && existingHighlights.length < annotationCount) {
    // 有批注数据但DOM中高亮不够，说明部分或全部DOM被重建了
    console.log('Some highlights lost, restoring...');
    restoreAnnotations();
  } else if (annotationCount === 0 && !isLoadingAnnotations) {
    // 没有批注数据且没有正在加载，后台静默加载
    console.log('No annotation data, background loading...');
    isLoadingAnnotations = true;
    getAnnotationsFromGitee(currentUrl).then(data => {
      annotationData = data;
      isLoadingAnnotations = false;
      if (Object.keys(data).length > 0) {
        restoreAnnotations();
      }
    }).catch(err => {
      console.error('后台加载批注失败:', err);
      isLoadingAnnotations = false;
    });
  }
}

// 清除所有高亮
function clearAllHighlights() {
  hideTooltip(); // 清除气泡
  const highlights = document.querySelectorAll('.web-note-highlight');
  highlights.forEach(highlight => {
    const parent = highlight.parentNode;
    if (!parent) return;
    while (highlight.firstChild) {
      parent.insertBefore(highlight.firstChild, highlight);
    }
    parent.removeChild(highlight);
    // 合并相邻文本节点，确保后续文本查找能正常工作
    parent.normalize();
  });
}

// 监听pushState和replaceState（处理SPA应用的页面切换）
function monitorUrlChanges() {
  // 保存原始的pushState和replaceState方法
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  
  // 重写pushState
  history.pushState = function(...args) {
    originalPushState.apply(this, args);
    console.log('pushState detected');
    handleUrlChange();
  };
  
  // 重写replaceState
  history.replaceState = function(...args) {
    originalReplaceState.apply(this, args);
    console.log('replaceState detected');
    handleUrlChange();
  };
  
  // URL轮询：定期检查URL是否变化（兜底机制，处理Next.js等框架绕过pushState重写的情况）
  let lastPolledUrl = getBaseUrl();
  setInterval(() => {
    const nowUrl = getBaseUrl();
    if (nowUrl !== lastPolledUrl) {
      console.log('URL change detected by polling:', lastPolledUrl, '->', nowUrl);
      lastPolledUrl = nowUrl;
      handleUrlChange();
    }
  }, 500);
  
  // 使用MutationObserver监听DOM变化（处理SPA异步内容加载）
  let mutationTimer = null;
  let isObserverPaused = false;
  
  const startObserver = () => {
    const observer = new MutationObserver((mutations) => {
      // 如果正在恢复批注或暂停中，忽略（避免自己触发自己）
      if (isRestoringAnnotations || isObserverPaused) return;
      
      // 如果正在加载数据，记录DOM有变化，等加载完后再检查
      if (isLoadingAnnotations) {
        pendingDomChange = true;
        return;
      }
      
      // 只在有批注数据但没有足够高亮时才处理
      const annotationCount = Object.keys(annotationData).length;
      if (annotationCount === 0) return;
      
      const existingHighlights = document.querySelectorAll('.web-note-highlight');
      if (existingHighlights.length >= annotationCount) return;
      
      // 检查mutations是否是由我们自己的高亮操作引起的
      const isOwnMutation = mutations.some(m => {
        for (const node of m.addedNodes) {
          if (node.nodeType === 1 && node.classList && node.classList.contains('web-note-highlight')) {
            return true;
          }
        }
        return false;
      });
      if (isOwnMutation) return;
      
      // 防抖：DOM变化频繁时只在最后一次变化后执行
      if (mutationTimer) clearTimeout(mutationTimer);
      mutationTimer = setTimeout(() => {
        console.log('DOM changed, checking if highlights need to be restored...');
        isObserverPaused = true;
        checkAndRestoreHighlights();
        // 短暂延迟后恢复observer
        setTimeout(() => { isObserverPaused = false; }, 300);
      }, 300);
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  };
  
  // 确保 document.body 存在后再启动 observer
  if (document.body) {
    startObserver();
  } else {
    // body 还不存在，等待 DOMContentLoaded
    const waitForBody = () => {
      if (document.body) {
        startObserver();
      } else {
        document.addEventListener('DOMContentLoaded', startObserver);
      }
    };
    waitForBody();
  }
}

// 检查扩展上下文是否有效
function isExtensionContextValid() {
  try {
    return !!chrome.runtime?.id;
  } catch (e) {
    return false;
  }
}

// 通过background调用Gitee API（避免CORS问题）
async function getAnnotationsFromGitee(url) {
  try {
    const response = await sendMessageToBackground('loadAnnotations', { url: url });
    return response.annotations || {};
  } catch (error) {
    console.error('通过background获取批注失败:', error);
    return {};
  }
}

// 通过background保存批注到Gitee
async function saveAnnotationToGitee(annotation, url) {
  const response = await sendMessageToBackground('saveAnnotation', { 
    annotation: annotation,
    url: url
  });
  
  if (!response.success) {
    throw new Error(response.error || '保存失败');
  }
}

// 通过background删除批注
async function deleteAnnotationFromGitee(annotationId, url) {
  const response = await sendMessageToBackground('deleteAnnotation', { 
    annotationId: annotationId,
    url: url
  });
  
  if (!response.success) {
    throw new Error(response.error || '删除失败');
  }
}

// 安全发送消息到后台（保留用于其他功能）
async function sendMessageToBackground(action, data = {}) {
  if (!isExtensionContextValid()) {
    throw new Error('Extension context invalidated. Please refresh the page.');
  }
  
  const request = { action, ...data };
  
  try {
    const response = await chrome.runtime.sendMessage(request);
    return response;
  } catch (error) {
    await new Promise(resolve => setTimeout(resolve, 200));
    try {
      const response = await chrome.runtime.sendMessage(request);
      return response;
    } catch (retryError) {
      throw new Error('Extension context invalidated. Please refresh the page.');
    }
  }
}

// 加载批注数据（带并发保护）
async function loadAnnotations() {
  // 防止并发加载
  if (isLoadingAnnotations) {
    console.log('Already loading annotations, skipping...');
    return;
  }
  
  isLoadingAnnotations = true;
  try {
    console.log('Loading annotations from Gitee...');
    console.log('Current URL:', currentUrl);
    
    annotationData = await getAnnotationsFromGitee(currentUrl);
    
    console.log('Loaded annotations count:', Object.keys(annotationData).length);
    console.log('Loaded annotations data:', JSON.stringify(annotationData, null, 2));
    
    restoreAnnotations();
    
    // 检查是否有从个人空间跳转过来需要定位的批注
    checkPendingScrollToAnnotation();
  } catch (error) {
    console.error('加载批注失败:', error);
    if (error.message.includes('Extension context invalidated')) {
      alert('扩展上下文已失效，请刷新页面后重试。');
    }
  } finally {
    isLoadingAnnotations = false;
  }
}

// 检查是否有从个人空间跳转过来需要定位的批注
function checkPendingScrollToAnnotation() {
  chrome.storage.local.get('pendingScrollToAnnotation', (result) => {
    const pending = result.pendingScrollToAnnotation;
    if (!pending) return;
    
    // 检查是否是当前页面的批注，且时间戳在30秒内（防止过期数据）
    if (pending.url === currentUrl && (Date.now() - pending.timestamp) < 30000) {
      console.log('[WebNote Content] 检测到待定位批注:', pending.annotationId);
      // 清除待定位信息（只执行一次）
      chrome.storage.local.remove('pendingScrollToAnnotation');
      
      // 延迟执行定位，确保高亮已渲染到DOM
      const scrollToTarget = (retryCount) => {
        const highlight = document.querySelector(`.web-note-highlight[data-annotation-id="${pending.annotationId}"]`);
        if (highlight) {
          // 滚动到可视区域
          highlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
          // 闪烁效果
          highlight.style.transition = 'outline 0.3s, box-shadow 0.3s';
          highlight.style.outline = '3px solid #ff1493';
          highlight.style.boxShadow = '0 0 16px rgba(255, 20, 147, 0.6)';
          setTimeout(() => {
            highlight.style.outline = 'none';
            highlight.style.boxShadow = 'none';
          }, 3000);
          console.log('[WebNote Content] 已定位到批注:', pending.annotationId);
        } else if (retryCount < 10) {
          // 高亮可能还没渲染完，重试
          setTimeout(() => scrollToTarget(retryCount + 1), 500);
        } else {
          console.warn('[WebNote Content] 定位批注失败，未找到高亮元素:', pending.annotationId);
        }
      };
      
      // 首次延迟500ms，等待高亮渲染
      setTimeout(() => scrollToTarget(0), 500);
    } else {
      // 不是当前页面的或已过期，清除
      if ((Date.now() - pending.timestamp) >= 30000) {
        chrome.storage.local.remove('pendingScrollToAnnotation');
      }
    }
  });
}

// 恢复批注样式
function restoreAnnotations() {
  console.log('Restoring annotations...');
  const annotationIds = Object.keys(annotationData);
  console.log('Total annotations to restore:', annotationIds.length);
  
  if (annotationIds.length === 0) return;
  
  isRestoringAnnotations = true;
  
  // 按文本长度从长到短排序，避免短文本先高亮导致长文本被分割找不到
  const sortedIds = annotationIds.sort((a, b) => {
    const textA = annotationData[a]?.text || '';
    const textB = annotationData[b]?.text || '';
    return textB.length - textA.length;
  });
  
  // 记录未成功恢复的批注
  const failedAnnotations = [];
  
  sortedIds.forEach(annotationId => {
    const annotation = annotationData[annotationId];
    // 检查是否已经高亮（避免重复高亮）
    const existing = document.querySelector(`.web-note-highlight[data-annotation-id="${annotationId}"]`);
    if (existing) {
      // 如果颜色有变化，更新高亮颜色
      if (existing.style.backgroundColor !== annotation.color) {
        document.querySelectorAll(`.web-note-highlight[data-annotation-id="${annotationId}"]`).forEach(el => {
          el.style.backgroundColor = annotation.color;
        });
        console.log('Annotation color updated:', annotationId);
      }
      return;
    }
    
    console.log('Restoring annotation:', annotationId, '- Text:', annotation.text.substring(0, 30));
    const success = highlightExistingText(annotation);
    if (!success) {
      failedAnnotations.push(annotation);
    }
  });
  
  isRestoringAnnotations = false;
  
  // 如果有失败的批注，延迟重试（页面内容可能还在加载）
  if (failedAnnotations.length > 0) {
    console.log(`${failedAnnotations.length} annotations failed to restore, will retry...`);
    scheduleRetry(failedAnnotations, 1);
  }
  
  // 后台延迟校验：等待页面完全稳定后，校验高亮位置是否准确，如有更好的位置则自动迁移
  scheduleHighlightVerification();
}

// 延迟重试恢复失败的批注
function scheduleRetry(failedAnnotations, attempt) {
  if (attempt > 5) {
    console.warn('Max retry attempts reached, giving up on', failedAnnotations.length, 'annotations');
    return;
  }
  
  const delay = attempt === 1 ? 500 : attempt * 1000; // 首次500ms快速重试，之后递增：2s, 3s, 4s, 5s
  setTimeout(() => {
    console.log(`Retry attempt ${attempt} for ${failedAnnotations.length} annotations...`);
    isRestoringAnnotations = true;
    
    const stillFailed = [];
    failedAnnotations.forEach(annotation => {
      // 再次检查是否已经高亮
      const existing = document.querySelector(`.web-note-highlight[data-annotation-id="${annotation.id}"]`);
      if (existing) return;
      
      const success = highlightExistingText(annotation);
      if (!success) {
        stillFailed.push(annotation);
      }
    });
    
    isRestoringAnnotations = false;
    
    if (stillFailed.length > 0) {
      scheduleRetry(stillFailed, attempt + 1);
    } else {
      console.log('All annotations restored successfully on retry');
    }
  }, delay);
}

// 后台校验定时器（防抖）
let verificationTimer = null;

// 调度后台校验（防抖，多次调用只执行最后一次）
function scheduleHighlightVerification() {
  if (verificationTimer) clearTimeout(verificationTimer);
  verificationTimer = setTimeout(() => {
    verifyAndCorrectHighlights();
  }, 2000);
}

// 后台校验并修正高亮位置
// 对有上下文信息的批注，检查当前高亮位置是否是最佳匹配，如果有更好的位置则自动迁移
function verifyAndCorrectHighlights() {
  const annotationIds = Object.keys(annotationData);
  if (annotationIds.length === 0) return;
  
  // 收集所有文本节点并拼接全文（只做一次，所有批注共用）
  const textNodes = collectTextNodes();
  if (textNodes.length === 0) return;
  
  let concatenated = '';
  const nodeOffsets = [];
  for (const textNode of textNodes) {
    nodeOffsets.push({ node: textNode, start: concatenated.length });
    concatenated += textNode.textContent;
  }
  
  let correctedCount = 0;
  
  annotationIds.forEach(annotationId => {
    const annotation = annotationData[annotationId];
    if (!annotation) return;
    
    // 只校验有上下文信息的批注
    if (!annotation.contextBefore && !annotation.contextAfter) return;
    
    const searchText = annotation.text;
    
    // 找到全文中所有匹配位置
    const allMatches = [];
    let searchStart = 0;
    while (true) {
      const index = concatenated.indexOf(searchText, searchStart);
      if (index === -1) break;
      allMatches.push(index);
      searchStart = index + 1;
    }
    
    // 只有多个匹配时才需要校验（单个匹配不可能定位错误）
    if (allMatches.length <= 1) return;
    
    // 计算每个匹配位置的上下文得分
    let bestIndex = -1;
    let bestScore = -1;
    
    for (const matchIndex of allMatches) {
      let score = 0;
      
      if (annotation.contextBefore) {
        const beforeText = concatenated.substring(
          Math.max(0, matchIndex - annotation.contextBefore.length),
          matchIndex
        );
        score += calculateSimilarity(beforeText, annotation.contextBefore);
      }
      
      if (annotation.contextAfter) {
        const afterStart = matchIndex + searchText.length;
        const afterText = concatenated.substring(
          afterStart,
          afterStart + annotation.contextAfter.length
        );
        score += calculateSimilarity(afterText, annotation.contextAfter);
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestIndex = matchIndex;
      }
    }
    
    if (bestIndex === -1) return;
    
    // 检查当前高亮位置是否在最佳匹配位置
    const existingHighlight = document.querySelector(`.web-note-highlight[data-annotation-id="${annotationId}"]`);
    if (!existingHighlight) return;
    
    // 获取当前高亮在全文中的位置
    const highlightNode = existingHighlight.firstChild;
    if (!highlightNode) return;
    
    // 找到当前高亮的父节点在全文中的位置
    let currentPosition = -1;
    for (let i = 0; i < nodeOffsets.length; i++) {
      if (nodeOffsets[i].node === highlightNode || 
          nodeOffsets[i].node.parentNode === existingHighlight) {
        currentPosition = nodeOffsets[i].start;
        break;
      }
    }
    
    // 如果无法确定当前位置，通过文本内容在全文中查找当前高亮附近的位置
    if (currentPosition === -1) {
      // 尝试通过高亮元素的前一个兄弟节点来定位
      const prevSibling = existingHighlight.previousSibling;
      if (prevSibling && prevSibling.nodeType === 3) {
        for (let i = 0; i < nodeOffsets.length; i++) {
          if (nodeOffsets[i].node === prevSibling) {
            currentPosition = nodeOffsets[i].start + prevSibling.textContent.length;
            break;
          }
        }
      }
    }
    
    // 判断当前位置是否就是最佳位置（允许小偏差）
    if (currentPosition !== -1 && Math.abs(currentPosition - bestIndex) < 5) {
      return; // 当前位置已经是最佳的
    }
    
    // 计算当前位置的得分
    let currentScore = 0;
    if (currentPosition !== -1) {
      if (annotation.contextBefore) {
        const beforeText = concatenated.substring(
          Math.max(0, currentPosition - annotation.contextBefore.length),
          currentPosition
        );
        currentScore += calculateSimilarity(beforeText, annotation.contextBefore);
      }
      if (annotation.contextAfter) {
        const afterStart = currentPosition + searchText.length;
        const afterText = concatenated.substring(
          afterStart,
          afterStart + annotation.contextAfter.length
        );
        currentScore += calculateSimilarity(afterText, annotation.contextAfter);
      }
    }
    
    // 只有当最佳位置的得分明显高于当前位置时才迁移（避免不必要的DOM操作）
    if (bestScore - currentScore < 0.3) return;
    
    // 迁移高亮：移除旧高亮，在新位置创建高亮
    console.log(`[WebNote] Correcting highlight position for ${annotationId}: score ${currentScore.toFixed(3)} → ${bestScore.toFixed(3)}`);
    
    // 移除旧高亮
    const allHighlights = document.querySelectorAll(`.web-note-highlight[data-annotation-id="${annotationId}"]`);
    allHighlights.forEach(el => {
      const parent = el.parentNode;
      while (el.firstChild) {
        parent.insertBefore(el.firstChild, el);
      }
      parent.removeChild(el);
      parent.normalize();
    });
    
    // 在新位置创建高亮（需要重新收集文本节点，因为DOM已变化）
    const newTextNodes = collectTextNodes();
    let newConcatenated = '';
    const newNodeOffsets = [];
    for (const tn of newTextNodes) {
      newNodeOffsets.push({ node: tn, start: newConcatenated.length });
      newConcatenated += tn.textContent;
    }
    
    // 在新的全文中找到最佳位置
    const newBestIndex = newConcatenated.indexOf(searchText, Math.max(0, bestIndex - 50));
    if (newBestIndex === -1) return;
    
    const endIdx = newBestIndex + searchText.length;
    const startInfo = findNodeAtPosition(newNodeOffsets, newBestIndex);
    const endInfo = findNodeAtPosition(newNodeOffsets, endIdx - 1);
    
    if (!startInfo || !endInfo) return;
    
    try {
      const range = document.createRange();
      range.setStart(startInfo.node, startInfo.offset);
      range.setEnd(endInfo.node, endInfo.offset + 1);
      
      if (startInfo.node === endInfo.node) {
        const span = createHighlightSpan(annotation);
        range.surroundContents(span);
      } else {
        const span = createHighlightSpan(annotation);
        const contents = range.extractContents();
        span.appendChild(contents);
        range.insertNode(span);
      }
      
      correctedCount++;
    } catch (e) {
      console.warn(`[WebNote] Failed to correct highlight for ${annotationId}:`, e.message);
    }
  });
  
  if (correctedCount > 0) {
    console.log(`[WebNote] Background verification corrected ${correctedCount} highlight(s)`);
  }
}

// 高亮已存在的文本（使用多种策略）
// 返回 true 表示成功，false 表示失败
function highlightExistingText(annotation) {
  const searchText = annotation.text;
  
  // 策略1：使用 TreeWalker 在单个文本节点中查找（最快）
  // 单个匹配直接高亮，多个匹配时利用上下文选择最佳位置
  if (highlightBySingleNodeSearch(annotation, searchText)) {
    return true;
  }
  
  // 策略2：使用跨节点文本搜索（处理文本跨越多个DOM元素的情况）
  if (highlightByCrossNodeSearch(annotation, searchText)) {
    return true;
  }
  
  // 策略3：使用模糊匹配（处理空白字符差异）
  if (highlightByFuzzySearch(annotation, searchText)) {
    return true;
  }
  
  // 策略4：基于上下文+相似度匹配（处理网站文本变化的情况）
  const contextResult = highlightByContextSimilarity(annotation);
  if (contextResult) {
    return true;
  }
  
  console.warn('All highlight methods failed for:', searchText.substring(0, 50) + '...');
  return false;
}

// 策略1：在单个文本节点中精确查找
function highlightBySingleNodeSearch(annotation, searchText) {
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: function(node) {
        // 跳过script、style、已高亮的元素内的文本
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tagName = parent.tagName.toLowerCase();
        if (tagName === 'script' || tagName === 'style' || tagName === 'noscript' || tagName === 'textarea' || tagName === 'input') {
          return NodeFilter.FILTER_REJECT;
        }
        if (parent.closest('.web-note-highlight') || 
            parent.closest('.web-note-sidebar') || 
            parent.closest('.web-note-floating-icon') ||
            parent.closest('#webNoteSidebarOverlay')) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  // 收集所有匹配的候选位置
  const candidates = [];
  let node;
  while (node = walker.nextNode()) {
    const text = node.textContent;
    if (!text) continue;
    
    // 找到该节点中所有匹配位置
    let startIndex = 0;
    while (true) {
      const index = text.indexOf(searchText, startIndex);
      if (index === -1) break;
      candidates.push({ node, index });
      startIndex = index + 1;
    }
  }
  
  if (candidates.length === 0) return false;
  
  // 如果只有一个匹配，直接使用（不需要上下文验证）
  // 如果有多个匹配且有上下文信息，通过上下文选择最佳匹配
  let bestCandidate = candidates[0];
  
  if (candidates.length > 1 && (annotation.contextBefore || annotation.contextAfter)) {
    let bestScore = -1;
    
    // 构建全文拼接和节点位置映射，用于跨节点获取上下文
    const textNodes = collectTextNodes();
    let concatenated = '';
    const nodePositions = new Map(); // node -> 在全文中的起始位置
    for (const tn of textNodes) {
      nodePositions.set(tn, concatenated.length);
      concatenated += tn.textContent;
    }
    
    for (const candidate of candidates) {
      let score = 0;
      
      // 计算该候选在全文中的绝对位置
      const nodeStart = nodePositions.get(candidate.node) || 0;
      const absIndex = nodeStart + candidate.index;
      
      // 从全文中获取跨节点的前后上下文
      if (annotation.contextBefore) {
        const beforeText = concatenated.substring(Math.max(0, absIndex - annotation.contextBefore.length), absIndex);
        score += calculateSimilarity(beforeText, annotation.contextBefore);
      }
      
      if (annotation.contextAfter) {
        const afterStart = absIndex + searchText.length;
        const afterText = concatenated.substring(afterStart, afterStart + annotation.contextAfter.length);
        score += calculateSimilarity(afterText, annotation.contextAfter);
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestCandidate = candidate;
      }
    }
  }
  
  try {
    const range = document.createRange();
    range.setStart(bestCandidate.node, bestCandidate.index);
    range.setEnd(bestCandidate.node, bestCandidate.index + searchText.length);
    
    const span = createHighlightSpan(annotation);
    range.surroundContents(span);
    console.log('Highlighted using single node search:', annotation.id, candidates.length > 1 ? `(selected from ${candidates.length} candidates)` : '');
    return true;
  } catch (e) {
    console.warn('Single node highlight failed:', e.message);
    // 如果最佳候选失败，尝试其他候选
    for (const candidate of candidates) {
      if (candidate === bestCandidate) continue;
      try {
        const range = document.createRange();
        range.setStart(candidate.node, candidate.index);
        range.setEnd(candidate.node, candidate.index + searchText.length);
        
        const span = createHighlightSpan(annotation);
        range.surroundContents(span);
        console.log('Highlighted using single node search (fallback candidate):', annotation.id);
        return true;
      } catch (e2) {
        continue;
      }
    }
  }
  
  return false;
}

// 策略2：跨节点文本搜索（处理文本分布在多个相邻节点的情况）
function highlightByCrossNodeSearch(annotation, searchText) {
  // 对于过长的文本，跨节点搜索可能性能不佳，限制搜索文本长度
  if (searchText.length > 1000) {
    console.warn('Text too long for cross-node search, skipping');
    return false;
  }
  
  // 收集所有文本节点及其位置信息
  const textNodes = collectTextNodes();
  if (textNodes.length === 0) return false;
  
  // 将相邻文本节点的内容拼接起来查找
  // 使用分段拼接避免为每个字符创建对象（性能优化）
  let concatenated = '';
  const nodeOffsets = []; // 记录每个节点在拼接字符串中的起始位置
  
  for (const textNode of textNodes) {
    nodeOffsets.push({ node: textNode, start: concatenated.length });
    concatenated += textNode.textContent;
  }
  
  // 找到所有匹配位置
  const allMatches = [];
  let searchStart = 0;
  while (true) {
    const index = concatenated.indexOf(searchText, searchStart);
    if (index === -1) break;
    allMatches.push(index);
    searchStart = index + 1;
  }
  
  if (allMatches.length === 0) return false;
  
  // 选择最佳匹配位置
  let bestIndex = allMatches[0];
  let bestScore = -1;
  
  if (allMatches.length > 1 && (annotation.contextBefore || annotation.contextAfter)) {
    for (const matchIndex of allMatches) {
      let score = 0;
      
      // 检查前文上下文
      if (annotation.contextBefore) {
        const beforeText = concatenated.substring(
          Math.max(0, matchIndex - annotation.contextBefore.length), 
          matchIndex
        );
        score += calculateSimilarity(beforeText, annotation.contextBefore);
      }
      
      // 检查后文上下文
      if (annotation.contextAfter) {
        const afterStart = matchIndex + searchText.length;
        const afterText = concatenated.substring(
          afterStart, 
          afterStart + annotation.contextAfter.length
        );
        score += calculateSimilarity(afterText, annotation.contextAfter);
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestIndex = matchIndex;
      }
    }
  }
  
  // 找到了，通过二分查找确定起始和结束的节点及偏移
  const endIndex = bestIndex + searchText.length;
  
  const startNodeInfo = findNodeAtPosition(nodeOffsets, bestIndex);
  const endNodeInfo = findNodeAtPosition(nodeOffsets, endIndex - 1);
  
  if (!startNodeInfo || !endNodeInfo) return false;
  
  // 如果起始和结束在同一个节点，使用简单方法
  if (startNodeInfo.node === endNodeInfo.node) {
    try {
      const range = document.createRange();
      range.setStart(startNodeInfo.node, startNodeInfo.offset);
      range.setEnd(endNodeInfo.node, endNodeInfo.offset + 1);
      
      const span = createHighlightSpan(annotation);
      range.surroundContents(span);
      console.log('Highlighted using cross-node search (same node):', annotation.id, allMatches.length > 1 ? `(selected from ${allMatches.length} candidates)` : '');
      return true;
    } catch (e) {
      console.warn('Cross-node same-node highlight failed:', e.message);
    }
  }
  
  // 跨节点情况：使用 extractContents + insertNode
  try {
    const range = document.createRange();
    range.setStart(startNodeInfo.node, startNodeInfo.offset);
    range.setEnd(endNodeInfo.node, endNodeInfo.offset + 1);
    
    const span = createHighlightSpan(annotation);
    const contents = range.extractContents();
    span.appendChild(contents);
    range.insertNode(span);
    console.log('Highlighted using cross-node search (multi-node):', annotation.id);
    return true;
  } catch (e) {
    console.warn('Cross-node multi-node highlight failed:', e.message);
    return false;
  }
}

// 根据字符位置找到对应的节点和节点内偏移
function findNodeAtPosition(nodeOffsets, position) {
  // 二分查找
  let low = 0, high = nodeOffsets.length - 1;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (nodeOffsets[mid].start <= position) {
      low = mid;
    } else {
      high = mid - 1;
    }
  }
  
  const entry = nodeOffsets[low];
  const offset = position - entry.start;
  
  // 验证偏移是否在节点范围内
  if (offset < 0 || offset >= entry.node.textContent.length) return null;
  
  return { node: entry.node, offset: offset };
}

// 收集所有有效的文本节点（公共方法，避免重复代码）
function collectTextNodes() {
  const textNodes = [];
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: function(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tagName = parent.tagName.toLowerCase();
        if (tagName === 'script' || tagName === 'style' || tagName === 'noscript' || tagName === 'textarea' || tagName === 'input') {
          return NodeFilter.FILTER_REJECT;
        }
        if (parent.closest('.web-note-highlight') || 
            parent.closest('.web-note-sidebar') || 
            parent.closest('.web-note-floating-icon') ||
            parent.closest('#webNoteSidebarOverlay')) {
          return NodeFilter.FILTER_REJECT;
        }
        if (node.textContent.length === 0) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );
  
  let node;
  while (node = walker.nextNode()) {
    textNodes.push(node);
  }
  return textNodes;
}

// 策略3：模糊匹配（处理空白字符差异，如换行、多空格等）
function highlightByFuzzySearch(annotation, searchText) {
  // 将搜索文本中的连续空白替换为灵活匹配模式
  const normalizedSearch = searchText.replace(/\s+/g, ' ').trim();
  if (normalizedSearch === searchText) return false; // 没有空白差异，不需要模糊匹配
  
  // 收集所有文本节点
  const textNodes = collectTextNodes();
  if (textNodes.length === 0) return false;
  
  // 拼接并标准化空白
  let concatenated = '';
  const nodeOffsets = [];
  
  for (const textNode of textNodes) {
    nodeOffsets.push({ node: textNode, start: concatenated.length });
    concatenated += textNode.textContent;
  }
  
  // 标准化后查找
  // 构建一个映射：标准化字符串的每个位置对应原始字符串的位置
  const normalizedConcat = [];
  const normalizedToOriginal = [];
  let lastWasSpace = false;
  
  for (let i = 0; i < concatenated.length; i++) {
    const ch = concatenated[i];
    if (/\s/.test(ch)) {
      if (!lastWasSpace) {
        normalizedConcat.push(' ');
        normalizedToOriginal.push(i);
        lastWasSpace = true;
      }
    } else {
      normalizedConcat.push(ch);
      normalizedToOriginal.push(i);
      lastWasSpace = false;
    }
  }
  
  const normalizedStr = normalizedConcat.join('');
  const searchIndex = normalizedStr.indexOf(normalizedSearch);
  if (searchIndex === -1) return false;
  
  // 映射回原始位置
  const originalStart = normalizedToOriginal[searchIndex];
  const originalEnd = normalizedToOriginal[searchIndex + normalizedSearch.length - 1];
  
  if (originalStart === undefined || originalEnd === undefined) return false;
  
  const startInfo = findNodeAtPosition(nodeOffsets, originalStart);
  const endInfo = findNodeAtPosition(nodeOffsets, originalEnd);
  
  if (!startInfo || !endInfo) return false;
  
  try {
    const range = document.createRange();
    range.setStart(startInfo.node, startInfo.offset);
    range.setEnd(endInfo.node, endInfo.offset + 1);
    
    const span = createHighlightSpan(annotation);
    const contents = range.extractContents();
    span.appendChild(contents);
    range.insertNode(span);
    console.log('Highlighted using fuzzy search:', annotation.id);
    return true;
  } catch (e) {
    console.warn('Fuzzy highlight failed:', e.message);
    return false;
  }
}

// 创建高亮span元素
function createHighlightSpan(annotation) {
  const span = document.createElement('span');
  span.className = 'web-note-highlight';
  span.style.backgroundColor = annotation.color;
  span.setAttribute('data-annotation-id', annotation.id);
  span.setAttribute('data-annotation-text', annotation.text);
  return span;
}

// 获取选中文本的前后上下文
function getTextContext(range, text) {
  const contextLen = 40;
  let before = '';
  let after = '';
  
  try {
    // 收集所有文本节点并拼接
    const textNodes = collectTextNodes();
    let concatenated = '';
    const nodeOffsets = [];
    for (const node of textNodes) {
      nodeOffsets.push({ node: node, start: concatenated.length });
      concatenated += node.textContent;
    }
    
    let targetIndex = -1;
    
    // 如果有range信息，通过range精确定位文本位置
    if (range) {
      try {
        const startContainer = range.startContainer;
        const startOffset = range.startOffset;
        
        // 找到startContainer在nodeOffsets中的位置
        for (let i = 0; i < nodeOffsets.length; i++) {
          if (nodeOffsets[i].node === startContainer || 
              nodeOffsets[i].node.parentNode === startContainer) {
            targetIndex = nodeOffsets[i].start + startOffset;
            break;
          }
        }
      } catch (e) {
        // range定位失败，回退到indexOf
      }
    }
    
    // 如果range定位失败，使用indexOf（但尝试找到最接近当前选区的匹配）
    if (targetIndex === -1) {
      // 找到所有匹配位置
      const allMatches = [];
      let searchStart = 0;
      while (true) {
        const idx = concatenated.indexOf(text, searchStart);
        if (idx === -1) break;
        allMatches.push(idx);
        searchStart = idx + 1;
      }
      
      if (allMatches.length === 1) {
        targetIndex = allMatches[0];
      } else if (allMatches.length > 1 && range) {
        // 多个匹配时，尝试通过range的容器节点来确定最接近的匹配
        try {
          const startContainer = range.startContainer;
          let closestNodeStart = 0;
          for (let i = 0; i < nodeOffsets.length; i++) {
            if (nodeOffsets[i].node === startContainer || 
                (startContainer.nodeType === 1 && startContainer.contains(nodeOffsets[i].node))) {
              closestNodeStart = nodeOffsets[i].start;
              break;
            }
          }
          // 选择距离最近的匹配
          let minDist = Infinity;
          for (const idx of allMatches) {
            const dist = Math.abs(idx - closestNodeStart);
            if (dist < minDist) {
              minDist = dist;
              targetIndex = idx;
            }
          }
        } catch (e) {
          targetIndex = allMatches[0];
        }
      } else if (allMatches.length > 0) {
        targetIndex = allMatches[0];
      }
    }
    
    if (targetIndex !== -1) {
      before = concatenated.substring(Math.max(0, targetIndex - contextLen), targetIndex);
      after = concatenated.substring(targetIndex + text.length, targetIndex + text.length + contextLen);
    }
  } catch (e) {
    console.warn('Failed to get text context:', e);
  }
  
  return { before, after };
}

// 策略4：基于上下文+相似度匹配（处理网站文本变化的情况）
// 当原始文本找不到时，通过上下文定位区域，再用相似度找到最接近的文本
function highlightByContextSimilarity(annotation) {
  // 如果没有上下文信息，无法使用此策略
  if (!annotation.contextBefore && !annotation.contextAfter) {
    return false;
  }
  
  const searchText = annotation.text;
  const textNodes = collectTextNodes();
  if (textNodes.length === 0) return false;
  
  // 拼接所有文本
  let concatenated = '';
  const nodeOffsets = [];
  for (const textNode of textNodes) {
    nodeOffsets.push({ node: textNode, start: concatenated.length });
    concatenated += textNode.textContent;
  }
  
  // 步骤1：通过上下文定位大致区域
  const candidateRegion = findRegionByContext(concatenated, annotation.contextBefore, annotation.contextAfter, searchText.length);
  
  if (!candidateRegion) {
    console.warn('Context-based region not found for:', annotation.id);
    return false;
  }
  
  // 步骤2：在候选区域内找到最相似的文本片段
  const bestMatch = findBestMatch(concatenated, candidateRegion, searchText);
  
  if (!bestMatch) {
    console.warn('No similar text found in region for:', annotation.id);
    return false;
  }
  
  // 步骤3：高亮匹配到的文本
  const startInfo = findNodeAtPosition(nodeOffsets, bestMatch.start);
  const endInfo = findNodeAtPosition(nodeOffsets, bestMatch.end - 1);
  
  if (!startInfo || !endInfo) return false;
  
  try {
    const range = document.createRange();
    range.setStart(startInfo.node, startInfo.offset);
    range.setEnd(endInfo.node, endInfo.offset + 1);
    
    const span = createHighlightSpan(annotation);
    const contents = range.extractContents();
    span.appendChild(contents);
    range.insertNode(span);
    
    const newText = bestMatch.text;
    console.log('Highlighted using context similarity:', annotation.id, '| Old:', searchText.substring(0, 30), '| New:', newText.substring(0, 30));
    
    // 步骤4：自动更新存储的批注文本
    if (newText !== searchText) {
      updateAnnotationText(annotation, newText, concatenated, bestMatch.start);
    }
    
    return true;
  } catch (e) {
    console.warn('Context similarity highlight failed:', e.message);
    return false;
  }
}

// 通过上下文定位文本所在的大致区域
function findRegionByContext(fullText, contextBefore, contextAfter, originalLength) {
  // 搜索窗口：原始文本长度的3倍范围
  const searchWindow = Math.max(originalLength * 3, 200);
  
  let bestPosition = -1;
  let bestScore = 0;
  
  // 优先尝试精确查找上下文（最快）
  if (contextBefore && contextBefore.length > 5) {
    const exactIdx = fullText.indexOf(contextBefore);
    if (exactIdx !== -1) {
      bestPosition = exactIdx + contextBefore.length;
      bestScore = 1.0;
    }
  }
  
  if (bestScore < 0.9 && contextAfter && contextAfter.length > 5) {
    const exactIdx = fullText.indexOf(contextAfter);
    if (exactIdx !== -1) {
      const pos = exactIdx - originalLength;
      if (pos >= 0) {
        bestPosition = pos;
        bestScore = 1.0;
      }
    }
  }
  
  // 如果精确查找失败，尝试部分匹配（取上下文的子串）
  if (bestScore < 0.9 && contextBefore && contextBefore.length > 10) {
    // 尝试上下文的后半部分（更靠近目标文本的部分更可靠）
    const halfBefore = contextBefore.substring(Math.floor(contextBefore.length / 2));
    const partialIdx = fullText.indexOf(halfBefore);
    if (partialIdx !== -1) {
      bestPosition = partialIdx + halfBefore.length;
      bestScore = 0.8;
    }
  }
  
  if (bestScore < 0.8 && contextAfter && contextAfter.length > 10) {
    const halfAfter = contextAfter.substring(0, Math.floor(contextAfter.length / 2));
    const partialIdx = fullText.indexOf(halfAfter);
    if (partialIdx !== -1) {
      bestPosition = partialIdx - originalLength;
      if (bestPosition < 0) bestPosition = 0;
      bestScore = 0.8;
    }
  }
  
  // 如果部分匹配也失败，使用滑动窗口相似度搜索（最慢但最灵活）
  if (bestScore < 0.6 && contextBefore && contextBefore.length > 5) {
    const beforeLen = contextBefore.length;
    const step = Math.max(3, Math.floor(beforeLen / 3));
    for (let i = 0; i <= fullText.length - beforeLen; i += step) {
      const candidate = fullText.substring(i, i + beforeLen);
      const score = calculateSimilarity(contextBefore, candidate);
      if (score > bestScore && score > 0.5) {
        bestScore = score;
        bestPosition = i + beforeLen;
      }
    }
  }
  
  if (bestPosition === -1) return null;
  
  // 返回候选区域（以定位点为中心，扩展 searchWindow）
  const regionStart = Math.max(0, bestPosition - searchWindow / 2);
  const regionEnd = Math.min(fullText.length, bestPosition + searchWindow / 2 + originalLength);
  
  return { start: Math.floor(regionStart), end: Math.floor(regionEnd) };
}

// 在候选区域内找到与原始文本最相似的片段
function findBestMatch(fullText, region, originalText) {
  const regionText = fullText.substring(region.start, region.end);
  const originalLen = originalText.length;
  
  // 搜索不同长度的窗口（原始长度的 0.5 ~ 1.5 倍）
  const minLen = Math.max(5, Math.floor(originalLen * 0.5));
  const maxLen = Math.min(regionText.length, Math.ceil(originalLen * 1.5));
  
  let bestMatch = null;
  let bestScore = 0;
  const threshold = 0.55; // 相似度阈值
  
  // 优先尝试与原始长度相近的窗口
  const lengths = [];
  for (let len = originalLen; len >= minLen; len--) lengths.push(len);
  for (let len = originalLen + 1; len <= maxLen; len++) lengths.push(len);
  
  for (const windowLen of lengths) {
    // 步长：窗口越大步长越大，避免过多计算
    const step = Math.max(1, Math.floor(windowLen / 10));
    
    for (let i = 0; i <= regionText.length - windowLen; i += step) {
      const candidate = regionText.substring(i, i + windowLen);
      const score = calculateSimilarity(originalText, candidate);
      
      if (score > bestScore) {
        bestScore = score;
        bestMatch = {
          text: candidate,
          start: region.start + i,
          end: region.start + i + windowLen,
          score: score
        };
      }
      
      // 如果找到非常高的相似度，提前退出
      if (bestScore > 0.9) break;
    }
    if (bestScore > 0.9) break;
  }
  
  if (bestScore >= threshold) {
    console.log(`Context similarity match: score=${bestScore.toFixed(3)}, text="${bestMatch.text.substring(0, 40)}..."`);
    return bestMatch;
  }
  
  return null;
}

// 计算两个字符串的相似度（基于最长公共子序列 LCS）
function calculateSimilarity(str1, str2) {
  if (!str1 || !str2) return 0;
  if (str1 === str2) return 1;
  
  const len1 = str1.length;
  const len2 = str2.length;
  
  // 对于过长的字符串，使用采样比较以提高性能
  if (len1 > 200 || len2 > 200) {
    return calculateSimilaritySampled(str1, str2);
  }
  
  // 使用空间优化的 LCS（只保留两行）
  const prev = new Array(len2 + 1).fill(0);
  const curr = new Array(len2 + 1).fill(0);
  
  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      if (str1[i - 1] === str2[j - 1]) {
        curr[j] = prev[j - 1] + 1;
      } else {
        curr[j] = Math.max(prev[j], curr[j - 1]);
      }
    }
    // 复制 curr 到 prev
    for (let j = 0; j <= len2; j++) {
      prev[j] = curr[j];
      curr[j] = 0;
    }
  }
  
  const lcsLength = prev[len2];
  return (2 * lcsLength) / (len1 + len2);
}

// 采样比较（用于长字符串）
function calculateSimilaritySampled(str1, str2) {
  const sampleSize = 100;
  const len1 = str1.length;
  const len2 = str2.length;
  
  // 取首尾和中间的采样
  const sample1Start = str1.substring(0, sampleSize);
  const sample1End = str1.substring(Math.max(0, len1 - sampleSize));
  const sample2Start = str2.substring(0, sampleSize);
  const sample2End = str2.substring(Math.max(0, len2 - sampleSize));
  
  // 计算首尾的相似度
  const startSim = calculateSimilarity(sample1Start, sample2Start);
  const endSim = calculateSimilarity(sample1End, sample2End);
  
  // 长度相似度
  const lenSim = 1 - Math.abs(len1 - len2) / Math.max(len1, len2);
  
  return (startSim + endSim + lenSim) / 3;
}

// 自动更新批注文本（异步，不阻塞高亮显示）
function updateAnnotationText(annotation, newText, fullText, matchStart) {
  // 更新本地数据
  const oldText = annotation.text;
  annotation.text = newText;
  annotationData[annotation.id] = annotation;
  
  // 更新上下文
  const contextLen = 40;
  annotation.contextBefore = fullText.substring(Math.max(0, matchStart - contextLen), matchStart);
  annotation.contextAfter = fullText.substring(matchStart + newText.length, matchStart + newText.length + contextLen);
  annotation.updatedAt = new Date().toISOString();
  
  // 更新高亮元素的 data-annotation-text 属性
  const highlightEl = document.querySelector(`.web-note-highlight[data-annotation-id="${annotation.id}"]`);
  if (highlightEl) {
    highlightEl.setAttribute('data-annotation-text', newText);
  }
  
  // 异步保存到远程（不阻塞）
  saveAnnotationToGitee(annotation, currentUrl).then(() => {
    console.log(`Annotation ${annotation.id} text auto-updated: "${oldText.substring(0, 20)}..." → "${newText.substring(0, 20)}..."`);
  }).catch(err => {
    console.warn('Failed to auto-update annotation text:', err.message);
    // 回滚本地数据
    annotation.text = oldText;
    annotationData[annotation.id] = annotation;
  });
}

// 处理选区变化
function handleSelectionChange() {
  // 如果正在恢复批注，不处理选区变化
  if (isRestoringAnnotations) return;
  
  console.log('Selection changed');
  
  const selection = window.getSelection();
  const text = selection.toString().trim();
  
  if (text.length > 0 && text.length <= 500) {
    console.log('Selected text:', text.substring(0, 50) + '...');
    selectedText = text;
    
    try {
      selectedRange = selection.getRangeAt(0).cloneRange();
    } catch (e) {
      console.warn('Failed to get range:', e);
      return;
    }
    
    // 立即计算上下文信息（此时selectedRange有效，能精确定位）
    const context = getTextContext(selectedRange, text);
    
    currentAnnotationId = null;
    
    if (isSidePanelOpen) {
      // 侧栏已打开：直接同步文本并展开编辑面板，不显示浮动图标
      hideFloatingIcon();
      chrome.storage.local.set({
        currentSelectedText: text,
        currentAnnotationId: '',
        currentUrl: currentUrl,
        currentContextBefore: context.before,
        currentContextAfter: context.after,
        triggerEditor: Date.now()  // 使用时间戳确保每次都触发 onChanged
      });
    } else {
      // 侧栏未打开：显示浮动图标，预存文本
      chrome.storage.local.set({
        currentSelectedText: text,
        currentAnnotationId: '',
        currentUrl: currentUrl,
        currentContextBefore: context.before,
        currentContextAfter: context.after,
        triggerEditor: false
      });
      
      // 获取选区位置
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top - 60;
      
      showFloatingIcon(x, y);
    }
  }
}

// 处理点击事件
function handleClick(e) {
  console.log('Click event');
  
  // 检查是否点击了图标
  if (floatingIcon && floatingIcon.contains(e.target)) {
    console.log('Clicked on floating icon');
    handleIconClick();
    return;
  }
  
  // 检查是否点击了气泡弹窗内部
  if (tooltip && tooltip.contains(e.target)) {
    return; // 不处理气泡内部的点击
  }
  
  // 检查是否点击了高亮文本
  const highlight = e.target.closest('.web-note-highlight');
  if (highlight) {
    e.preventDefault();
    e.stopPropagation();
    const annotationId = highlight.getAttribute('data-annotation-id');
    if (annotationId && annotationData[annotationId]) {
      showTooltip(annotationData[annotationId], e.clientX, e.clientY, highlight);
    }
    return;
  }
  
  // 点击空白处隐藏图标和气泡
  const selection = window.getSelection();
  if (!selection || selection.toString().trim() === '') {
    hideFloatingIcon();
  }
  hideTooltip();
}

// 处理鼠标悬浮事件（保留用于未来扩展）
function handleMouseOver(e) {
  // 不再在悬浮时显示图标，改为点击高亮文本直接弹出气泡
}

// 处理鼠标离开事件
function handleMouseOut(e) {
  // 不再需要处理图标隐藏
}

// 显示悬浮图标（新建批注）
function showFloatingIcon(x, y) {
  console.log('Showing floating icon at:', x, y);
  
  if (!floatingIcon) {
    createFloatingIcon();
  }
  
  floatingIcon.style.left = `${x}px`;
  floatingIcon.style.top = `${y}px`;
  floatingIcon.classList.add('web-note-icon-visible');
  
  floatingIcon.removeAttribute('data-annotation-id');
  floatingIcon.removeAttribute('data-annotation-text');
}

// 创建悬浮图标
function createFloatingIcon() {
  console.log('Creating floating icon');
  
  const icon = document.createElement('div');
  icon.className = 'web-note-floating-icon';
  icon.innerHTML = '✏️';
  // 移除内联样式中的display:none，让CSS类来控制显示/隐藏
  icon.style.cssText = `
    position: fixed;
    z-index: 99998;
    width: 38px;
    height: 38px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 14px rgba(102, 126, 234, 0.4);
    font-size: 16px;
    user-select: none;
    pointer-events: auto;
  `;
  
  icon.addEventListener('click', handleIconClick);
  
  document.body.appendChild(icon);
  floatingIcon = icon;
  console.log('Floating icon created and appended to body');
  console.log('Icon element:', icon);
  console.log('Icon computed styles:', window.getComputedStyle(icon));
  return icon;
}

// 处理图标点击
function handleIconClick() {
  console.log('Icon clicked');
  
  const annotationId = floatingIcon?.getAttribute('data-annotation-id');
  const annotationText = floatingIcon?.getAttribute('data-annotation-text');
  
  if (annotationId && annotationText) {
    console.log('Editing existing annotation:', annotationId);
    currentAnnotationId = annotationId;
    selectedText = annotationText;
    
    const annotation = annotationData[annotationId];
    if (annotation) {
      selectedColor = annotation.color;
    }
  } else {
    console.log('Creating new annotation');
    currentAnnotationId = null;
  }
  
  // 统一使用 Chrome sidePanel，不再使用内嵌侧栏
  chrome.runtime.sendMessage({
    action: 'openSidebar',
    selectedText: selectedText,
    annotationId: currentAnnotationId || '',
    url: currentUrl,
    triggerEditor: true  // 明确要求展开编辑面板
  }).catch(err => {
    console.warn('发送openSidebar消息失败:', err);
  });
  
  hideFloatingIcon();
}

// 隐藏悬浮图标
function hideFloatingIcon() {
  if (floatingIcon) {
    floatingIcon.classList.remove('web-note-icon-visible');
    floatingIcon.removeAttribute('data-annotation-id');
    floatingIcon.removeAttribute('data-annotation-text');
  }
}

// 显示批注气泡弹窗
function showTooltip(annotation, mouseX, mouseY, highlightEl) {
  // 先隐藏之前的气泡和图标
  hideTooltip();
  hideFloatingIcon();
  
  // 创建气泡元素
  const tooltipEl = document.createElement('div');
  tooltipEl.className = 'web-note-tooltip';
  
  // 格式化时间
  const timeStr = annotation.createdAt 
    ? new Date(annotation.createdAt).toLocaleString('zh-CN', { 
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit'
      })
    : '';
  
  tooltipEl.innerHTML = `
    <div class="web-note-tooltip-arrow web-note-tooltip-arrow-bottom"></div>
    <div class="web-note-tooltip-header">
      <span class="web-note-tooltip-header-title">批注</span>
      <div class="web-note-tooltip-actions">
        <button class="web-note-tooltip-btn web-note-tooltip-btn-edit" title="编辑批注">✏️</button>
        <button class="web-note-tooltip-btn web-note-tooltip-btn-close" title="关闭">✕</button>
      </div>
    </div>
    <div class="web-note-tooltip-body">
      <div class="web-note-tooltip-text">${escapeHtml(annotation.text)}</div>
      <div class="web-note-tooltip-content markdown-body">${renderMarkdown(annotation.content || '')}</div>
      ${timeStr ? `<div class="web-note-tooltip-time">${timeStr}</div>` : ''}
    </div>
  `;
  
  document.body.appendChild(tooltipEl);
  tooltip = tooltipEl;
  
  // 绑定按钮事件
  const editBtn = tooltipEl.querySelector('.web-note-tooltip-btn-edit');
  const closeBtn = tooltipEl.querySelector('.web-note-tooltip-btn-close');
  
  editBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    hideTooltip();
    // 通过 Chrome sidePanel 编辑
    currentAnnotationId = annotation.id;
    selectedText = annotation.text;
    selectedColor = annotation.color;
    chrome.runtime.sendMessage({
      action: 'openSidebar',
      selectedText: annotation.text,
      annotationId: annotation.id,
      url: currentUrl,
      triggerEditor: true  // 明确要求展开编辑面板
    }).catch(err => {
      console.warn('发送openSidebar消息失败:', err);
    });
  });
  
  closeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    hideTooltip();
  });
  
  // 计算位置：优先显示在鼠标上方，空间不够则显示在下方
  positionTooltip(tooltipEl, mouseX, mouseY, highlightEl);
  
  // 延迟添加可见类以触发动画
  requestAnimationFrame(() => {
    tooltipEl.classList.add('web-note-tooltip-visible');
  });
}

// 定位气泡弹窗
function positionTooltip(tooltipEl, mouseX, mouseY, highlightEl) {
  // 先让元素渲染以获取尺寸
  tooltipEl.style.visibility = 'hidden';
  tooltipEl.style.display = 'block';
  
  const tooltipRect = tooltipEl.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const margin = 10; // 距离边缘的最小间距
  const gap = 12; // 气泡与鼠标的间距
  
  let left, top;
  let arrowPosition = 'bottom'; // 箭头在底部（气泡在上方）
  
  // 水平位置：以鼠标为中心，确保不超出视口
  left = mouseX - tooltipRect.width / 2;
  if (left < margin) left = margin;
  if (left + tooltipRect.width > viewportWidth - margin) {
    left = viewportWidth - margin - tooltipRect.width;
  }
  
  // 垂直位置：优先显示在鼠标上方
  top = mouseY - tooltipRect.height - gap;
  
  if (top < margin) {
    // 上方空间不够，显示在下方
    top = mouseY + gap;
    arrowPosition = 'top'; // 箭头在顶部（气泡在下方）
  }
  
  // 确保不超出底部
  if (top + tooltipRect.height > viewportHeight - margin) {
    top = viewportHeight - margin - tooltipRect.height;
  }
  
  tooltipEl.style.left = `${left}px`;
  tooltipEl.style.top = `${top}px`;
  tooltipEl.style.visibility = 'visible';
  
  // 更新箭头位置
  const arrow = tooltipEl.querySelector('.web-note-tooltip-arrow');
  if (arrow) {
    arrow.className = `web-note-tooltip-arrow web-note-tooltip-arrow-${arrowPosition}`;
    // 箭头水平位置对准鼠标
    const arrowLeft = mouseX - left;
    arrow.style.left = `${Math.max(16, Math.min(arrowLeft, tooltipRect.width - 16))}px`;
    arrow.style.marginLeft = '0';
  }
}

// 隐藏气泡弹窗
function hideTooltip() {
  if (tooltip) {
    tooltip.classList.remove('web-note-tooltip-visible');
    // 等动画结束后移除元素
    const el = tooltip;
    setTimeout(() => {
      if (el && el.parentNode) {
        el.parentNode.removeChild(el);
      }
    }, 200);
    tooltip = null;
  }
}

// HTML转义（防止XSS）
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Markdown渲染
function renderMarkdown(text) {
  if (!text) return '';
  try {
    if (typeof marked !== 'undefined') {
      marked.setOptions({
        breaks: true,
        gfm: true
      });
      return marked.parse(text);
    }
  } catch (e) {
    console.warn('Markdown渲染失败:', e);
  }
  // 如果marked未加载，使用简单的换行处理
  return escapeHtml(text).replace(/\n/g, '<br>');
}

// 创建侧边栏
function createSidebar() {
  console.log('Creating sidebar');
  
  const sidebarHTML = `
    <div class="web-note-sidebar-overlay" id="webNoteSidebarOverlay"></div>
    <div class="web-note-sidebar" id="webNoteSidebar">
      <div class="web-note-sidebar-header">
        <h2>划词批注</h2>
        <button class="web-note-close-btn" id="webNoteCloseBtn">×</button>
      </div>
      <div class="web-note-sidebar-content">
        <div class="web-note-color-section">
          <label class="web-note-section-label">选择颜色：</label>
          <div class="web-note-color-picker" id="webNoteColorPicker">
            ${colorOptions.map(color => 
              `<div class="web-note-color-option" data-color="${color}" style="background-color: ${color};"></div>`
            ).join('')}
          </div>
        </div>
        
        <div class="web-note-selected-text-section">
          <label class="web-note-section-label">选中的文本：</label>
          <div class="web-note-selected-text" id="webNoteSelectedText">请先在页面上选择文本</div>
        </div>
        
        <div class="web-note-annotation-section">
          <label class="web-note-section-label">批注内容：</label>
          <textarea class="web-note-annotation-input" id="webNoteAnnotationInput" placeholder="输入批注内容...&#10;Shift+Enter 换行，Enter 提交"></textarea>
          <div class="web-note-button-group">
            <button class="web-note-submit-btn" id="webNoteSubmitBtn">提交批注</button>
            <button class="web-note-delete-btn" id="webNoteDeleteBtn" style="display: none;">删除批注</button>
          </div>
        </div>
        
        <div class="web-note-annotations-list-section">
          <label class="web-note-section-label">页面所有批注：</label>
          <div class="web-note-annotations-list" id="webNoteAnnotationsList">
            <div class="web-note-empty-state">暂无批注</div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  const container = document.createElement('div');
  container.innerHTML = sidebarHTML;
  document.body.appendChild(container);
  
  sidebar = document.getElementById('webNoteSidebar');
  
  document.getElementById('webNoteCloseBtn').addEventListener('click', closeSidebar);
  document.getElementById('webNoteSidebarOverlay').addEventListener('click', closeSidebar);
  document.getElementById('webNoteColorPicker').addEventListener('click', handleColorSelect);
  document.getElementById('webNoteSubmitBtn').addEventListener('click', submitAnnotation);
  document.getElementById('webNoteDeleteBtn').addEventListener('click', deleteAnnotation);
  document.getElementById('webNoteAnnotationInput').addEventListener('keydown', handleKeyDown);
  
  return sidebar;
}

// 打开侧边栏
function openSidebar() {
  console.log('Opening sidebar');
  
  if (!sidebar) {
    createSidebar();
  }
  
  const selectedTextElement = document.getElementById('webNoteSelectedText');
  const annotationInput = document.getElementById('webNoteAnnotationInput');
  const deleteBtn = document.getElementById('webNoteDeleteBtn');
  
  if (selectedText) {
    selectedTextElement.textContent = selectedText;
  }
  
  if (currentAnnotationId) {
    const annotation = annotationData[currentAnnotationId];
    if (annotation) {
      annotationInput.value = annotation.content;
      selectedColor = annotation.color;
      deleteBtn.style.display = 'block';
    }
  } else {
    annotationInput.value = '';
    deleteBtn.style.display = 'none';
  }
  
  updateColorSelection();
  
  document.getElementById('webNoteSidebarOverlay').style.display = 'block';
  sidebar.style.transform = 'translateX(0)';
  
  setTimeout(() => {
    annotationInput.focus();
  }, 300);
  
  updateSidebarAnnotationsList();
}

// 关闭侧边栏
function closeSidebar() {
  if (!sidebar) return;
  
  document.getElementById('webNoteSidebarOverlay').style.display = 'none';
  sidebar.style.transform = 'translateX(100%)';
}

// 处理颜色选择
function handleColorSelect(e) {
  const colorOption = e.target.closest('.web-note-color-option');
  if (colorOption) {
    selectedColor = colorOption.getAttribute('data-color');
    updateColorSelection();
  }
}

// 更新颜色选择状态
function updateColorSelection() {
  document.querySelectorAll('.web-note-color-option').forEach(option => {
    option.classList.remove('web-note-color-option-selected');
    if (option.getAttribute('data-color') === selectedColor) {
      option.classList.add('web-note-color-option-selected');
    }
  });
}

// 处理键盘事件
function handleKeyDown(e) {
  if (e.key === 'Enter') {
    if (e.shiftKey) {
      return;
    } else {
      e.preventDefault();
      submitAnnotation();
    }
  }
}

// 提交批注
async function submitAnnotation() {
  const annotationInput = document.getElementById('webNoteAnnotationInput');
  const content = annotationInput.value.trim();
  
  if (!content) {
    alert('请输入批注内容');
    return;
  }
  
  if (!selectedText) {
    alert('请先在页面上选择文本');
    return;
  }
  
  // 获取选中文本的前后上下文（用于文本变化后的模糊定位）
  const context = getTextContext(selectedRange || null, selectedText);
  
  const annotation = {
    id: currentAnnotationId || Date.now().toString(),
    text: selectedText,
    content: content,
    color: selectedColor,
    url: currentUrl,
    contextBefore: context.before,
    contextAfter: context.after,
    createdAt: currentAnnotationId ? annotationData[currentAnnotationId]?.createdAt : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  try {
    await saveAnnotationToGitee(annotation, currentUrl);
    
    annotationData[annotation.id] = annotation;
    
    if (!currentAnnotationId) {
      highlightSelectedText(selectedColor, annotation.id);
    } else {
      updateHighlightColor(currentAnnotationId, selectedColor);
    }
    
    updateSidebarAnnotationsList();
    
    annotationInput.value = '';
    currentAnnotationId = null;
    selectedText = '';
    selectedRange = null;
    document.getElementById('webNoteDeleteBtn').style.display = 'none';
    document.getElementById('webNoteSelectedText').textContent = '请先在页面上选择文本';
    
    closeSidebar();
  } catch (error) {
    console.error('提交批注失败:', error);
    alert('保存失败: ' + error.message);
  }
}

// 更新高亮颜色
function updateHighlightColor(annotationId, color) {
  const highlights = document.querySelectorAll('.web-note-highlight');
  highlights.forEach(highlight => {
    if (highlight.getAttribute('data-annotation-id') === annotationId) {
      highlight.style.backgroundColor = color;
    }
  });
}

// 删除批注
async function deleteAnnotation() {
  if (!currentAnnotationId) return;
  
  if (!confirm('确定要删除这条批注吗？')) return;
  
  try {
    await deleteAnnotationFromGitee(currentAnnotationId, currentUrl);
    
    const highlights = document.querySelectorAll('.web-note-highlight');
    highlights.forEach(highlight => {
      if (highlight.getAttribute('data-annotation-id') === currentAnnotationId) {
        const parent = highlight.parentNode;
        const text = document.createTextNode(highlight.textContent);
        parent.replaceChild(text, highlight);
        parent.normalize(); // 合并相邻文本节点
      }
    });
    
    delete annotationData[currentAnnotationId];
    updateSidebarAnnotationsList();
    
    document.getElementById('webNoteAnnotationInput').value = '';
    document.getElementById('webNoteDeleteBtn').style.display = 'none';
    document.getElementById('webNoteSelectedText').textContent = '请先在页面上选择文本';
    currentAnnotationId = null;
    selectedText = '';
    
    closeSidebar();
  } catch (error) {
    console.error('删除批注失败:', error);
    alert('删除失败: ' + error.message);
  }
}

// 更新侧边栏批注列表
function updateSidebarAnnotationsList() {
  const listElement = document.getElementById('webNoteAnnotationsList');
  if (!listElement) return;
  
  const annotations = Object.values(annotationData);
  
  if (annotations.length === 0) {
    listElement.innerHTML = '<div class="web-note-empty-state">暂无批注</div>';
    return;
  }
  
  listElement.innerHTML = annotations.map(annotation => `
    <div class="web-note-annotation-item" data-annotation-id="${annotation.id}">
      <div class="web-note-annotation-item-text" style="background-color: ${annotation.color}">${escapeHtml(annotation.text)}</div>
      <div class="web-note-annotation-item-content markdown-body">${renderMarkdown(annotation.content)}</div>
      <div class="web-note-annotation-item-time">${new Date(annotation.createdAt).toLocaleString()}</div>
    </div>
  `).join('');
  
  document.querySelectorAll('.web-note-annotation-item').forEach(item => {
    item.addEventListener('click', () => {
      const annotationId = item.getAttribute('data-annotation-id');
      const annotation = annotationData[annotationId];
      
      if (annotation) {
        currentAnnotationId = annotationId;
        selectedText = annotation.text;
        selectedColor = annotation.color;
        
        document.getElementById('webNoteSelectedText').textContent = annotation.text;
        document.getElementById('webNoteAnnotationInput').value = annotation.content;
        document.getElementById('webNoteDeleteBtn').style.display = 'block';
        
        updateColorSelection();
        
        document.getElementById('webNoteAnnotationInput').scrollIntoView({ behavior: 'smooth' });
        document.getElementById('webNoteAnnotationInput').focus();
      }
    });
  });
}

// 高亮选中的文本
function highlightSelectedText(color, annotationId) {
  if (!selectedRange) return;
  
  const span = document.createElement('span');
  span.className = 'web-note-highlight';
  span.style.backgroundColor = color;
  span.setAttribute('data-annotation-id', annotationId || Date.now().toString());
  span.setAttribute('data-annotation-text', selectedText);
  
  try {
    selectedRange.surroundContents(span);
  } catch (e) {
    console.warn('无法高亮文本:', e);
    // 备选方法：提取内容再包裹
    try {
      const extractedContent = selectedRange.extractContents();
      span.appendChild(extractedContent);
      selectedRange.insertNode(span);
    } catch (e2) {
      console.error('备选方法也失败:', e2);
    }
  }
  
  selectedRange = null;
  selectedText = '';
}

// 监听来自 sidePanel 的端口连接（用于可靠检测 sidePanel 关闭）
// 监听storage变化（个人空间编辑/删除批注后通知）
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.annotationsUpdated && changes.annotationsUpdated.newValue) {
    console.log('[WebNote Content] 批注数据已在外部更新，重新加载...');
    // 重新从远程加载批注数据并刷新高亮
    isLoadingAnnotations = true;
    getAnnotationsFromGitee(currentUrl).then(data => {
      annotationData = data;
      isLoadingAnnotations = false;
      // 清除现有高亮并重新恢复
      clearAllHighlights();
      if (Object.keys(data).length > 0) {
        restoreAnnotations();
      }
    }).catch(err => {
      console.error('[WebNote Content] 重新加载批注失败:', err);
      isLoadingAnnotations = false;
    });
  }
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'sidePanelPort') {
    console.log('[WebNote Content] sidePanel 端口已连接');
    isSidePanelOpen = true;
    hideFloatingIcon();
    
    port.onDisconnect.addListener(() => {
      console.log('[WebNote Content] sidePanel 端口已断开（侧栏关闭）');
      isSidePanelOpen = false;
    });
  }
});

// 监听来自sidebar或background的消息
function handleRuntimeMessage(request, sender, sendResponse) {
  if (request.action === 'highlightText') {
    // 从sidebar提交批注后，更新高亮
    console.log('[WebNote Content] 收到highlightText消息');
    const annotation = request.annotation;
    if (annotation && annotation.id) {
      // 先用消息中的数据直接更新本地，确保颜色立即生效
      annotationData[annotation.id] = annotation;
      // 如果页面上已有该批注的高亮，直接更新颜色
      const existingHighlights = document.querySelectorAll(`.web-note-highlight[data-annotation-id="${annotation.id}"]`);
      if (existingHighlights.length > 0) {
        existingHighlights.forEach(el => {
          el.style.backgroundColor = annotation.color;
        });
        console.log('[WebNote Content] 已更新高亮颜色:', annotation.id);
      } else {
        // 新批注，尝试高亮
        highlightExistingText(annotation);
      }
    } else {
      // 兜底：重新加载所有批注
      loadAnnotations();
    }
    sendResponse({ success: true });
  } else if (request.action === 'removeHighlight') {
    // 从sidebar删除批注后，移除对应的高亮
    console.log('[WebNote Content] 收到removeHighlight消息, annotationId:', request.annotationId);
    const highlights = document.querySelectorAll('.web-note-highlight');
    highlights.forEach(highlight => {
      if (highlight.getAttribute('data-annotation-id') === request.annotationId) {
        const parent = highlight.parentNode;
        while (highlight.firstChild) {
          parent.insertBefore(highlight.firstChild, highlight);
        }
        parent.removeChild(highlight);
        parent.normalize(); // 合并相邻文本节点
      }
    });
    delete annotationData[request.annotationId];
    sendResponse({ success: true });
  } else if (request.action === 'getTextContext') {
    // sidebar请求获取文本的上下文信息（用于精确定位）
    console.log('[WebNote Content] 收到getTextContext消息');
    const context = getTextContext(selectedRange, request.text);
    sendResponse({ contextBefore: context.before, contextAfter: context.after });
  } else if (request.action === 'scrollToAnnotation') {
    // 从sidebar定位批注，滚动到对应位置并闪烁高亮
    console.log('[WebNote Content] 收到scrollToAnnotation消息, annotationId:', request.annotationId);
    const highlight = document.querySelector(`.web-note-highlight[data-annotation-id="${request.annotationId}"]`);
    if (highlight) {
      // 滚动到可视区域
      highlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // 闪烁效果
      highlight.style.transition = 'outline 0.2s, box-shadow 0.2s';
      highlight.style.outline = '3px solid #ff1493';
      highlight.style.boxShadow = '0 0 12px rgba(255, 20, 147, 0.5)';
      setTimeout(() => {
        highlight.style.outline = 'none';
        highlight.style.boxShadow = 'none';
      }, 2000);
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: '未找到对应的高亮文本' });
    }
  }
  return true;
}

// 注册消息监听器（如果有旧的先移除）
if (window.__webNoteMessageHandler) {
  chrome.runtime.onMessage.removeListener(window.__webNoteMessageHandler);
}
window.__webNoteMessageHandler = handleRuntimeMessage;
chrome.runtime.onMessage.addListener(handleRuntimeMessage);

// 启动插件
console.log('Calling init()');

// 确保DOM完全加载后再初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}