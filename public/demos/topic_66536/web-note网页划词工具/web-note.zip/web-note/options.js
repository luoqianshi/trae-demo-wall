// ===== 路由管理 =====
function getCurrentRoute() {
  const hash = window.location.hash;
  if (hash === '#settings') return 'settings';
  return 'home'; // 默认显示个人空间
}

function navigateTo(route) {
  window.location.hash = '#' + route;
}

function updateView() {
  const route = getCurrentRoute();
  
  // 隐藏所有视图
  document.getElementById('viewSiteList').classList.add('hidden');
  document.getElementById('viewSiteDetail').classList.add('hidden');
  document.getElementById('viewSettings').classList.add('hidden');
  
  // 更新导航按钮状态
  document.getElementById('navHomeBtn').style.opacity = route === 'home' ? '1' : '0.7';
  document.getElementById('navSettingsBtn').style.opacity = route === 'settings' ? '1' : '0.7';
  
  if (route === 'settings') {
    document.getElementById('viewSettings').classList.remove('hidden');
    document.title = '网页批注 - 设置';
  } else {
    // home 视图
    if (currentView === 'siteDetail') {
      document.getElementById('viewSiteDetail').classList.remove('hidden');
    } else {
      document.getElementById('viewSiteList').classList.remove('hidden');
    }
    document.title = '网页批注 - 个人空间';
  }
}

// ===== 设置功能 =====
function initSettings() {
  const giteeTokenInput = document.getElementById('giteeToken');
  const giteeOwnerInput = document.getElementById('giteeOwner');
  const giteeRepoInput = document.getElementById('giteeRepo');
  const saveBtn = document.getElementById('saveBtn');
  const testBtn = document.getElementById('testBtn');
  const statusMessage = document.getElementById('statusMessage');
  
  // 加载已保存的配置
  async function loadConfig() {
    const result = await chrome.storage.sync.get(['giteeToken', 'giteeOwner', 'giteeRepo']);
    if (result.giteeToken) giteeTokenInput.value = result.giteeToken;
    if (result.giteeOwner) giteeOwnerInput.value = result.giteeOwner;
    if (result.giteeRepo) giteeRepoInput.value = result.giteeRepo;
  }
  
  // 保存配置
  async function saveConfig() {
    const token = giteeTokenInput.value.trim();
    const owner = giteeOwnerInput.value.trim();
    const repo = giteeRepoInput.value.trim();
    
    if (!token || !owner || !repo) {
      showStatus('请填写所有配置项', 'error');
      return;
    }
    
    try {
      await chrome.storage.sync.set({
        giteeToken: token,
        giteeOwner: owner,
        giteeRepo: repo
      });
      showStatus('配置保存成功！', 'success');
      chrome.runtime.sendMessage({ action: 'reloadConfig' });
    } catch (error) {
      showStatus('保存失败: ' + error.message, 'error');
    }
  }
  
  // 测试连接
  async function testConnection() {
    const token = giteeTokenInput.value.trim();
    const owner = giteeOwnerInput.value.trim();
    const repo = giteeRepoInput.value.trim();
    
    if (!token || !owner || !repo) {
      showStatus('请填写所有配置项', 'error');
      return;
    }
    
    testBtn.disabled = true;
    testBtn.textContent = '测试中...';
    
    try {
      const response = await fetch(`https://gitee.com/api/v5/repos/${owner}/${repo}`, {
        headers: {
          'Authorization': `token ${token}`,
          'User-Agent': 'WebNote-Extension'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        showStatus(`连接成功！仓库: ${data.full_name}`, 'success');
      } else {
        const error = await response.json();
        showStatus(`连接失败: ${error.message || '未知错误'}`, 'error');
      }
    } catch (error) {
      showStatus('连接失败: ' + error.message, 'error');
    } finally {
      testBtn.disabled = false;
      testBtn.textContent = '测试连接';
    }
  }
  
  function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = 'status-message ' + type;
    statusMessage.style.display = 'block';
    setTimeout(() => { statusMessage.style.display = 'none'; }, 3000);
  }
  
  saveBtn.addEventListener('click', saveConfig);
  testBtn.addEventListener('click', testConnection);
  loadConfig();
}

// ===== 个人空间功能 =====
let allSiteData = {};
let allSitesFiltered = [];
let currentPage = 1;
const SITES_PER_PAGE = 12;
let currentView = 'siteList'; // 'siteList' | 'siteDetail'
let currentDomain = '';

function initHome() {
  document.getElementById('searchInput').addEventListener('input', handleSearch);
  document.getElementById('searchClear').addEventListener('click', clearSearch);
  document.getElementById('backBtn').addEventListener('click', () => {
    currentView = 'siteList';
    updateView();
  });
  
  loadAllData();
}

// 加载所有数据
async function loadAllData() {
  showLoading(true);
  
  try {
    const response = await chrome.runtime.sendMessage({ action: 'loadAllAnnotations' });
    if (response && response.annotations) {
      allSiteData = response.annotations;
    } else {
      allSiteData = {};
    }
    showLoading(false);
    renderSiteList();
  } catch (error) {
    console.error('加载数据失败:', error);
    showLoading(false);
    allSiteData = {};
    renderSiteList();
    showToast('加载失败: ' + (error.message || '请检查设置'));
  }
}

function showLoading(show) {
  document.getElementById('loadingState').classList.toggle('hidden', !show);
  document.getElementById('siteGrid').style.display = show ? 'none' : '';
  document.getElementById('pagination').style.display = show ? 'none' : '';
}

// 渲染网站列表
function renderSiteList(filterQuery = '') {
  const siteGrid = document.getElementById('siteGrid');
  const emptyState = document.getElementById('emptyState');
  const statSites = document.getElementById('statSites');
  const statAnnotations = document.getElementById('statAnnotations');
  
  // 按域名汇总
  const siteMap = {};
  let totalAnnotations = 0;
  
  for (const [url, annotations] of Object.entries(allSiteData)) {
    const annotationList = Object.values(annotations);
    if (annotationList.length === 0) continue;
    
    let domain;
    try {
      domain = new URL(url).hostname;
    } catch (e) {
      domain = url;
    }
    
    if (!siteMap[domain]) {
      siteMap[domain] = {
        domain: domain,
        urls: [],
        annotations: [],
        title: domain.replace(/^www\./, '')
      };
    }
    
    siteMap[domain].urls.push(url);
    siteMap[domain].annotations.push(...annotationList);
    totalAnnotations += annotationList.length;
    
    // 优先使用路径最短的页面的 pageTitle 作为网站标题（最接近首页）
    let urlPath;
    try {
      urlPath = new URL(url).pathname;
    } catch (e) {
      urlPath = url;
    }
    for (const a of annotationList) {
      if (a.pageTitle && a.pageTitle.trim()) {
        if (!siteMap[domain]._shortestPath || urlPath.length < siteMap[domain]._shortestPath.length) {
          siteMap[domain]._shortestPath = urlPath;
          siteMap[domain].title = a.pageTitle.trim();
        }
        break;
      }
    }
  }
  
  statSites.textContent = Object.keys(siteMap).length;
  statAnnotations.textContent = totalAnnotations;
  
  // 过滤
  let sites = Object.values(siteMap);
  if (filterQuery) {
    const q = filterQuery.toLowerCase();
    sites = sites.filter(s => 
      s.domain.toLowerCase().includes(q) || 
      s.title.toLowerCase().includes(q)
    );
  }
  
  // 按批注数量排序
  sites.sort((a, b) => b.annotations.length - a.annotations.length);
  allSitesFiltered = sites;
  
  if (sites.length === 0) {
    siteGrid.innerHTML = '';
    siteGrid.style.display = 'none';
    document.getElementById('pagination').innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }
  
  emptyState.classList.add('hidden');
  siteGrid.style.display = '';
  
  // 分页
  const totalPages = Math.ceil(sites.length / SITES_PER_PAGE);
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const startIdx = (currentPage - 1) * SITES_PER_PAGE;
  const endIdx = startIdx + SITES_PER_PAGE;
  const pageSites = sites.slice(startIdx, endIdx);
  
  siteGrid.innerHTML = pageSites.map((site, idx) => {
    const faviconUrl = `https://${site.domain}/favicon.ico`;
    const firstLetter = site.domain.charAt(0).toUpperCase();
    
    return `
      <div class="site-card" data-domain="${escapeHtml(site.domain)}" style="animation-delay: ${idx * 0.05}s">
        <img class="site-card-icon" src="${faviconUrl}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
        <div class="site-card-icon-placeholder" style="display:none;">${firstLetter}</div>
        <div class="site-card-info">
          <div class="site-card-title">${escapeHtml(site.title)}</div>
          <div class="site-card-domain">${escapeHtml(site.domain)}</div>
        </div>
        <div class="site-card-badge">${site.annotations.length} 条</div>
      </div>
    `;
  }).join('');
  
  // 绑定点击
  siteGrid.querySelectorAll('.site-card').forEach(card => {
    card.addEventListener('click', () => {
      const domain = card.getAttribute('data-domain');
      openSiteDetail(domain);
    });
  });
  
  renderPagination(totalPages);
}

// 渲染分页
function renderPagination(totalPages) {
  const pagination = document.getElementById('pagination');
  
  if (totalPages <= 1) {
    pagination.innerHTML = '';
    return;
  }
  
  let html = '';
  html += `<button class="page-btn page-prev ${currentPage <= 1 ? 'disabled' : ''}" data-page="prev">‹</button>`;
  
  const maxVisible = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
  let endPage = Math.min(totalPages, startPage + maxVisible - 1);
  if (endPage - startPage < maxVisible - 1) {
    startPage = Math.max(1, endPage - maxVisible + 1);
  }
  
  if (startPage > 1) {
    html += `<button class="page-btn page-num" data-page="1">1</button>`;
    if (startPage > 2) html += `<span class="page-ellipsis">…</span>`;
  }
  
  for (let i = startPage; i <= endPage; i++) {
    html += `<button class="page-btn page-num ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
  }
  
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) html += `<span class="page-ellipsis">…</span>`;
    html += `<button class="page-btn page-num" data-page="${totalPages}">${totalPages}</button>`;
  }
  
  html += `<button class="page-btn page-next ${currentPage >= totalPages ? 'disabled' : ''}" data-page="next">›</button>`;
  
  pagination.innerHTML = html;
  
  pagination.querySelectorAll('.page-btn:not(.disabled)').forEach(btn => {
    btn.addEventListener('click', () => {
      const page = btn.getAttribute('data-page');
      if (page === 'prev') currentPage--;
      else if (page === 'next') currentPage++;
      else currentPage = parseInt(page);
      
      renderSiteList(document.getElementById('searchInput').value.trim());
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });
}

// 搜索
function handleSearch() {
  const query = document.getElementById('searchInput').value.trim();
  document.getElementById('searchClear').classList.toggle('hidden', query.length === 0);
  currentPage = 1;
  renderSiteList(query);
}

function clearSearch() {
  document.getElementById('searchInput').value = '';
  document.getElementById('searchClear').classList.add('hidden');
  currentPage = 1;
  renderSiteList();
}

// 网站详情
function openSiteDetail(domain) {
  currentDomain = domain;
  currentView = 'siteDetail';
  updateView();
  
  const siteIcon = document.getElementById('siteIcon');
  const siteIconPlaceholder = document.getElementById('siteIconPlaceholder');
  const siteTitle = document.getElementById('siteTitle');
  const siteDomain = document.getElementById('siteDomain');
  const siteBadge = document.getElementById('siteBadge');
  
  const faviconUrl = `https://${domain}/favicon.ico`;
  siteIcon.src = faviconUrl;
  siteIcon.style.display = '';
  siteIconPlaceholder.classList.add('hidden');
  siteIcon.onerror = function() {
    this.style.display = 'none';
    siteIconPlaceholder.textContent = domain.charAt(0).toUpperCase();
    siteIconPlaceholder.classList.remove('hidden');
  };
  
  siteTitle.textContent = domain.replace(/^www\./, '');
  siteDomain.textContent = domain;
  
  // 收集该域名下所有页面的批注
  const pageAnnotations = {};
  let totalCount = 0;
  let detailPageTitle = '';
  let shortestPath = '';
  
  for (const [url, annotations] of Object.entries(allSiteData)) {
    let urlDomain;
    try {
      urlDomain = new URL(url).hostname;
    } catch (e) {
      continue;
    }
    
    if (urlDomain === domain) {
      const annotationList = Object.values(annotations);
      if (annotationList.length > 0) {
        pageAnnotations[url] = annotationList;
        totalCount += annotationList.length;
        // 提取路径最短的页面的 pageTitle（最接近首页）
        let urlPath;
        try {
          urlPath = new URL(url).pathname;
        } catch (e) {
          urlPath = url;
        }
        for (const a of annotationList) {
          if (a.pageTitle && a.pageTitle.trim()) {
            if (!shortestPath || urlPath.length < shortestPath.length) {
              shortestPath = urlPath;
              detailPageTitle = a.pageTitle.trim();
            }
            break;
          }
        }
      }
    }
  }
  
  // 使用 pageTitle 更新标题
  if (detailPageTitle) {
    siteTitle.textContent = detailPageTitle;
  }
  
  siteBadge.textContent = `${totalCount} 条批注`;
  renderDetailAnnotations(pageAnnotations);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 渲染详情批注
function renderDetailAnnotations(pageAnnotations) {
  const container = document.getElementById('detailAnnotations');
  const pages = Object.entries(pageAnnotations);
  
  if (pages.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-illustration">📋</div>
        <h3>该网站暂无批注</h3>
      </div>
    `;
    return;
  }
  
  container.innerHTML = pages.map(([url, annotations]) => {
    annotations.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const displayUrl = url.replace(/^https?:\/\//, '');
    
    return `
      <div class="page-group">
        <div class="page-group-header" title="${escapeHtml(url)}">${escapeHtml(displayUrl)}</div>
        <div class="page-group-list">
          ${annotations.map(a => `
            <div class="annotation-item" data-id="${a.id}" data-url="${escapeHtml(url)}">
              <div class="annotation-item-color" style="background-color: ${a.color || '#667eea'}"></div>
              <div class="annotation-item-text">${escapeHtml(a.text)}</div>
              ${a.content ? `<div class="annotation-item-content markdown-body">${renderMarkdown(a.content)}</div>` : ''}
              <div class="annotation-item-footer">
                <span class="annotation-item-time">${formatTime(a.createdAt)}</span>
                <div class="annotation-item-actions">
                  <button class="annotation-item-btn btn-goto" data-id="${a.id}" data-url="${escapeHtml(url)}" title="跳转到原页面并定位">跳转</button>
                  <button class="annotation-item-btn btn-edit" data-id="${a.id}" data-url="${escapeHtml(url)}" data-text="${escapeHtml(a.text)}" data-content="${escapeHtml(a.content || '')}">编辑</button>
                  <button class="annotation-item-btn btn-delete" data-id="${a.id}" data-url="${escapeHtml(url)}" data-text="${escapeHtml(a.text)}">删除</button>
                  <button class="annotation-item-btn" data-text="${escapeHtml(a.text)}" data-content="${escapeHtml(a.content || '')}" data-action="copy">复制</button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
  
  // 绑定复制按钮
  container.querySelectorAll('.annotation-item-btn[data-action="copy"]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const text = btn.getAttribute('data-text');
      const content = btn.getAttribute('data-content');
      const copyText = `「${text}」\n${content}`;
      navigator.clipboard.writeText(copyText).then(() => {
        showToast('已复制到剪贴板');
      }).catch(() => {
        showToast('复制失败');
      });
    });
  });

  // 绑定编辑按钮
  container.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const url = btn.getAttribute('data-url');
      const text = btn.getAttribute('data-text');
      const content = btn.getAttribute('data-content');
      openEditModal(id, url, text, content);
    });
  });

  // 绑定删除按钮
  container.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const url = btn.getAttribute('data-url');
      const text = btn.getAttribute('data-text');
      openDeleteModal(id, url, text);
    });
  });

  // 绑定跳转按钮
  container.querySelectorAll('.btn-goto').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const url = btn.getAttribute('data-url');
      gotoAnnotation(id, url);
    });
  });
}

// ===== 工具函数 =====
function formatTime(isoStr) {
  if (!isoStr) return '';
  const date = new Date(isoStr);
  const now = new Date();
  const diff = now - date;
  
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  if (date.toDateString() === now.toDateString()) {
    return '今天 ' + date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) {
    return '昨天 ' + date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }
  return date.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' }) + ' ' + 
         date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Markdown渲染
function renderMarkdown(text) {
  if (!text) return '';
  try {
    if (typeof marked !== 'undefined') {
      marked.setOptions({
        breaks: true,
        gfm: true
      });
      return marked.parse(text);
    }
  } catch (e) {
    console.warn('Markdown渲染失败:', e);
  }
  return escapeHtml(text);
}

function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  requestAnimationFrame(() => {
    toast.classList.add('visible');
  });
  
  setTimeout(() => {
    toast.classList.remove('visible');
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

// ===== 编辑弹窗功能 =====
let editingAnnotationId = '';
let editingAnnotationUrl = '';

function openEditModal(id, url, text, content) {
  editingAnnotationId = id;
  editingAnnotationUrl = url;
  document.getElementById('editText').value = text;
  document.getElementById('editContent').value = content;
  const modal = document.getElementById('editModal');
  modal.classList.add('visible');
}

function closeEditModal() {
  const modal = document.getElementById('editModal');
  modal.classList.remove('visible');
  editingAnnotationId = '';
  editingAnnotationUrl = '';
}

async function saveEdit() {
  const content = document.getElementById('editContent').value;
  const saveBtn = document.getElementById('editSaveBtn');
  
  if (!editingAnnotationId || !editingAnnotationUrl) return;
  
  // 从 allSiteData 中找到对应的批注
  const annotation = allSiteData[editingAnnotationUrl]?.[editingAnnotationId];
  if (!annotation) {
    showToast('批注数据未找到');
    closeEditModal();
    return;
  }
  
  // 更新内容
  const updatedAnnotation = {
    ...annotation,
    content: content,
    updatedAt: new Date().toISOString()
  };
  
  saveBtn.disabled = true;
  saveBtn.textContent = '保存中...';
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'saveAnnotation',
      annotation: updatedAnnotation,
      url: editingAnnotationUrl
    });
    
    if (response && response.success) {
      // 更新本地数据
      allSiteData[editingAnnotationUrl][editingAnnotationId] = updatedAnnotation;
      showToast('保存成功');
      closeEditModal();
      // 重新渲染详情页
      openSiteDetail(currentDomain);
      // 通知其他组件（content.js、sidebar.js）刷新数据
      chrome.storage.local.set({ annotationsUpdated: Date.now() });
    } else {
      showToast('保存失败: ' + (response?.error || '未知错误'));
    }
  } catch (error) {
    showToast('保存失败: ' + error.message);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = '保存';
  }
}

// ===== 删除确认弹窗功能 =====
let deletingAnnotationId = '';
let deletingAnnotationUrl = '';

function openDeleteModal(id, url, text) {
  deletingAnnotationId = id;
  deletingAnnotationUrl = url;
  document.getElementById('deletePreview').textContent = text;
  const modal = document.getElementById('deleteModal');
  modal.classList.add('visible');
}

function closeDeleteModal() {
  const modal = document.getElementById('deleteModal');
  modal.classList.remove('visible');
  deletingAnnotationId = '';
  deletingAnnotationUrl = '';
}

async function confirmDelete() {
  if (!deletingAnnotationId || !deletingAnnotationUrl) return;
  
  const deleteBtn = document.getElementById('deleteConfirmBtn');
  deleteBtn.disabled = true;
  deleteBtn.textContent = '删除中...';
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'deleteAnnotation',
      annotationId: deletingAnnotationId,
      url: deletingAnnotationUrl
    });
    
    if (response && response.success) {
      // 更新本地数据
      if (allSiteData[deletingAnnotationUrl]) {
        delete allSiteData[deletingAnnotationUrl][deletingAnnotationId];
        // 如果该URL下没有批注了，删除该URL条目
        if (Object.keys(allSiteData[deletingAnnotationUrl]).length === 0) {
          delete allSiteData[deletingAnnotationUrl];
        }
      }
      showToast('删除成功');
      closeDeleteModal();
      // 重新渲染详情页
      openSiteDetail(currentDomain);
      // 通知其他组件（content.js、sidebar.js）刷新数据
      chrome.storage.local.set({ annotationsUpdated: Date.now() });
    } else {
      showToast('删除失败: ' + (response?.error || '未知错误'));
    }
  } catch (error) {
    showToast('删除失败: ' + error.message);
  } finally {
    deleteBtn.disabled = false;
    deleteBtn.textContent = '删除';
  }
}

// ===== 跳转到原页面并定位批注 =====
function gotoAnnotation(annotationId, url) {
  // 先存储待定位的批注信息，content.js 加载完成后会读取并定位
  chrome.storage.local.set({ 
    pendingScrollToAnnotation: {
      annotationId: annotationId,
      url: url,
      timestamp: Date.now()
    }
  }).then(() => {
    // 打开新标签页
    chrome.tabs.create({ url: url });
    showToast('正在打开页面并定位...');
  }).catch(err => {
    // fallback: 直接打开页面
    window.open(url, '_blank');
    showToast('已打开页面');
  });
}

function initModals() {
  // 编辑弹窗事件
  document.getElementById('editCancelBtn').addEventListener('click', closeEditModal);
  document.getElementById('editSaveBtn').addEventListener('click', saveEdit);
  document.getElementById('editModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeEditModal();
  });
  
  // 删除弹窗事件
  document.getElementById('deleteCancelBtn').addEventListener('click', closeDeleteModal);
  document.getElementById('deleteConfirmBtn').addEventListener('click', confirmDelete);
  document.getElementById('deleteModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeDeleteModal();
  });
  
  // ESC 关闭弹窗
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeEditModal();
      closeDeleteModal();
    }
  });
}

// ===== 初始化 =====
function init() {
  // 导航按钮
  document.getElementById('navHomeBtn').addEventListener('click', () => navigateTo('home'));
  document.getElementById('navSettingsBtn').addEventListener('click', () => navigateTo('settings'));
  
  // 监听 hash 变化
  window.addEventListener('hashchange', updateView);
  
  // 初始化设置功能
  initSettings();
  
  // 初始化个人空间功能
  initHome();
  
  // 初始化弹窗功能
  initModals();
  
  // 根据当前 hash 显示对应视图
  updateView();
}

init();