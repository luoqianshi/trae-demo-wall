// Gitee API配置
let giteeConfig = {
  token: '',
  owner: '',
  repo: '',
  filePath: 'web-note-annotations.json'
};

// 内存缓存：避免每次都请求Gitee API
let annotationsCache = null; // 缓存的全部批注数据
let cacheTimestamp = 0; // 缓存时间戳
const CACHE_TTL = 5 * 60 * 1000; // 缓存有效期5分钟

// 加载配置
async function loadConfig() {
  const result = await chrome.storage.sync.get(['giteeToken', 'giteeOwner', 'giteeRepo']);
  giteeConfig.token = result.giteeToken || '';
  giteeConfig.owner = result.giteeOwner || '';
  giteeConfig.repo = result.giteeRepo || '';
}

// 获取Gitee文件内容
async function getGiteeFile() {
  if (!giteeConfig.token || !giteeConfig.owner || !giteeConfig.repo) {
    throw new Error('Gitee配置不完整，请在插件设置中配置Token、仓库所有者和仓库名称');
  }

  const url = `https://gitee.com/api/v5/repos/${giteeConfig.owner}/${giteeConfig.repo}/contents/${giteeConfig.filePath}`;
  
  console.log('[WebNote Background] 获取Gitee文件:', url);
  
  const response = await fetch(url, {
    headers: {
      'Authorization': `token ${giteeConfig.token}`,
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
    },
    mode: 'cors',
    cache: 'no-cache'
  });

  if (response.ok) {
    const data = await response.json();
    const content = base64ToUtf8(data.content);
    console.log('[WebNote Background] 获取Gitee文件成功');
    const parsed = JSON.parse(content);
    // 更新内存缓存
    annotationsCache = parsed;
    cacheTimestamp = Date.now();
    // 更新持久化缓存（异步，不阻塞）
    chrome.storage.local.set({ 
      annotationsLocalCache: parsed, 
      annotationsCacheTime: cacheTimestamp 
    }).catch(() => {});
    return parsed;
  } else if (response.status === 404) {
    console.log('[WebNote Background] Gitee文件不存在，返回空对象');
    annotationsCache = {};
    cacheTimestamp = Date.now();
    chrome.storage.local.set({ 
      annotationsLocalCache: {}, 
      annotationsCacheTime: cacheTimestamp 
    }).catch(() => {});
    return {};
  }
  
  const errorText = await response.text();
  console.error('[WebNote Background] Gitee API失败，状态码:', response.status, ', 响应:', errorText);
  throw new Error(`获取文件失败: ${response.status}`);
}

// 从缓存获取数据（如果缓存有效），否则从Gitee获取
// 采用 stale-while-revalidate 策略：优先返回缓存数据，后台异步刷新
async function getCachedAnnotations() {
  // 一级缓存：内存缓存（最快）
  if (annotationsCache !== null && (Date.now() - cacheTimestamp) < CACHE_TTL) {
    console.log('[WebNote Background] 使用内存缓存');
    return annotationsCache;
  }
  
  // 二级缓存：chrome.storage.local（Service Worker重启后内存缓存丢失时使用）
  try {
    const stored = await chrome.storage.local.get(['annotationsLocalCache', 'annotationsCacheTime']);
    if (stored.annotationsLocalCache) {
      // 恢复到内存缓存
      annotationsCache = stored.annotationsLocalCache;
      cacheTimestamp = stored.annotationsCacheTime || 0;
      
      if ((Date.now() - cacheTimestamp) < CACHE_TTL) {
        // 缓存未过期，直接使用
        console.log('[WebNote Background] 使用本地存储缓存（未过期）');
        return annotationsCache;
      } else {
        // 缓存已过期，但先返回旧数据（让高亮立即显示），后台异步刷新
        console.log('[WebNote Background] 使用本地存储缓存（已过期，后台刷新）');
        // 后台异步刷新缓存（不阻塞当前返回）
        getGiteeFile().catch(err => {
          console.warn('[WebNote Background] 后台刷新缓存失败:', err.message);
        });
        return annotationsCache;
      }
    }
  } catch (e) {
    console.warn('[WebNote Background] 读取本地缓存失败:', e);
  }
  
  // 完全没有缓存，从Gitee获取（首次使用）
  return await getGiteeFile();
}

// UTF-8字符串转Base64（使用Uint8Array）
function utf8ToBase64(str) {
  const encoder = new TextEncoder();
  const bytes = encoder.encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Base64转UTF-8字符串
function base64ToUtf8(str) {
  // Gitee API返回的base64内容可能包含换行符，需要先去除
  const cleanStr = str.replace(/[\s\n\r]/g, '');
  const binary = atob(cleanStr);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const decoder = new TextDecoder('utf-8');
  return decoder.decode(bytes);
}

// 保存到Gitee（不使用本地存储回退）
async function saveToGitee(annotations) {
  console.log('[WebNote Background] saveToGitee called, config:', {
    token: giteeConfig.token ? '***' : '',
    owner: giteeConfig.owner,
    repo: giteeConfig.repo,
    filePath: giteeConfig.filePath
  });
  
  if (!giteeConfig.token || !giteeConfig.owner || !giteeConfig.repo) {
    throw new Error('Gitee配置不完整，请在插件设置中配置Token、仓库所有者和仓库名称');
  }

  const url = `https://gitee.com/api/v5/repos/${giteeConfig.owner}/${giteeConfig.repo}/contents/${giteeConfig.filePath}`;
  console.log('[WebNote Background] Gitee API URL:', url);
  
  // 先获取文件信息（如果存在）
  let sha = '';
  try {
    const response = await fetch(url, {
      headers: {
        'Authorization': `token ${giteeConfig.token}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
      },
      mode: 'cors',
      cache: 'no-cache'
    });

    if (response.ok) {
      const data = await response.json();
      sha = data.sha;
      console.log('[WebNote Background] 文件已存在，SHA:', sha);
    } else if (response.status === 404) {
      console.log('[WebNote Background] 文件不存在，将创建新文件');
    } else {
      const errorText = await response.text();
      console.error('[WebNote Background] 获取文件信息失败，状态码:', response.status, ', 响应:', errorText);
      throw new Error(`获取文件信息失败: ${response.status}`);
    }
  } catch (error) {
    console.error('[WebNote Background] 获取文件信息异常:', error.message);
    throw new Error('获取文件信息失败: ' + error.message);
  }

  // 准备内容 - 使用UTF-8安全的base64编码
  const content = utf8ToBase64(JSON.stringify(annotations, null, 2));
  console.log('[WebNote Background] 准备保存的内容长度:', content.length);
  
  // 创建请求体
  const body = {
    content: content,
    message: `Update annotations ${new Date().toISOString()}`,
    branch: 'master'
  };
  
  // 只有文件存在时才添加sha字段
  if (sha) {
    body.sha = sha;
  }
  
  console.log('[WebNote Background] 请求体:', JSON.stringify(body));

  // 发送保存请求
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `token ${giteeConfig.token}`,
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
      'Accept': 'application/json'
    },
    body: JSON.stringify(body),
    mode: 'cors',
    cache: 'no-cache'
  });

  console.log('[WebNote Background] 保存响应状态:', response.status);
  
  if (response.ok) {
    const result = await response.json();
    console.log('[WebNote Background] 保存成功:', result);
    return result;
  }

  // 处理HTTP错误响应
  const responseText = await response.text();
  console.error('[WebNote Background] 保存失败，原始响应:', responseText);
  
  let errorMessage = '保存失败';
  try {
    const error = JSON.parse(responseText);
    if (error.message) {
      errorMessage = error.message;
    } else if (error.error) {
      errorMessage = error.error;
    } else if (error.messages && Array.isArray(error.messages)) {
      errorMessage = error.messages.join(', ');
    } else {
      errorMessage = JSON.stringify(error);
    }
  } catch (e) {
    errorMessage = responseText.substring(0, 200);
  }
  
  throw new Error(errorMessage);
}

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openSidebar') {
    console.log('[WebNote Background] 收到打开侧边栏请求:', request);
    
    const tabId = sender.tab ? sender.tab.id : request.tabId;
    
    // 先存储选中的文本信息（如果sidePanel已打开，它会通过onChanged监听器自动接收）
    chrome.storage.local.set({
      currentSelectedText: request.selectedText,
      currentAnnotationId: request.annotationId,
      currentUrl: request.url,
      triggerEditor: request.triggerEditor !== false ? Date.now() : false  // 使用时间戳确保每次触发
    }, () => {
      // 尝试打开侧边栏（如果已打开则会忽略错误）
      chrome.sidePanel.open({ tabId: tabId })
        .then(() => {
          console.log('[WebNote Background] 侧边栏打开成功');
          sendResponse({ success: true });
        })
        .catch(error => {
          // sidePanel.open 可能因为缺少用户手势而失败，但数据已经存储
          // 如果 sidePanel 已经打开，数据会通过 storage.onChanged 自动同步
          console.warn('[WebNote Background] 打开侧边栏失败(可能已打开):', error.message);
          sendResponse({ success: true }); // 数据已存储，视为成功
        });
    });
    
    return true; // 异步响应
  } else if (request.action === 'reloadConfig') {
    loadConfig().then(() => {
      console.log('[WebNote Background] 配置已重新加载');
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'getAnnotationData') {
    loadConfig().then(() => getGiteeFile()).then(allAnnotations => {
      // 在所有URL的批注中查找指定ID的批注
      let foundAnnotation = null;
      for (const url of Object.keys(allAnnotations || {})) {
        if (allAnnotations[url][request.annotationId]) {
          foundAnnotation = allAnnotations[url][request.annotationId];
          break;
        }
      }
      sendResponse({ annotation: foundAnnotation });
    }).catch(error => {
      console.error('[WebNote Background] 获取批注数据失败:', error);
      sendResponse({ annotation: null, error: error.message });
    });
    return true;
  } else if (request.action === 'saveAnnotation') {
    saveAnnotationHandler(request.annotation, request.url)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // 异步响应
  } else if (request.action === 'loadAnnotations') {
    loadAnnotationsHandler(request.url)
      .then(annotations => sendResponse({ annotations }))
      .catch(error => sendResponse({ annotations: {}, error: error.message }));
    return true; // 异步响应
  } else if (request.action === 'deleteAnnotation') {
    deleteAnnotationHandler(request.annotationId, request.url)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // 异步响应
  } else if (request.action === 'openHomePage') {
    // 打开个人空间页面（复用 options.html，通过 hash 路由）
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html#home') });
    // 关闭侧栏：sidePanel 发送的消息 sender.tab 为 undefined，需要获取当前窗口
    chrome.windows.getCurrent().then(window => {
      if (window && window.id) {
        chrome.sidePanel.close({ windowId: window.id }).catch(err => {
          console.warn('[WebNote Background] 关闭侧栏失败:', err.message);
        });
      }
    }).catch(() => {});
    sendResponse({ success: true });
    return false;
  } else if (request.action === 'loadAllAnnotations') {
    // 加载所有网站的批注数据（个人空间使用）
    loadConfig().then(() => getGiteeFile()).then(allAnnotations => {
      sendResponse({ annotations: allAnnotations || {} });
    }).catch(error => {
      console.error('[WebNote Background] 加载所有批注失败:', error);
      sendResponse({ annotations: {}, error: error.message });
    });
    return true; // 异步响应
  }
});

// 保存批注处理器
async function saveAnnotationHandler(annotation, url) {
  await loadConfig();
  let allAnnotations = await getCachedAnnotations() || {};
  
  if (!allAnnotations[url]) {
    allAnnotations[url] = {};
  }
  
  allAnnotations[url][annotation.id] = annotation;
  // 先更新缓存（确保后续读取立即生效）
  annotationsCache = allAnnotations;
  cacheTimestamp = Date.now();
  chrome.storage.local.set({ 
    annotationsLocalCache: allAnnotations, 
    annotationsCacheTime: cacheTimestamp 
  }).catch(() => {});
  await saveToGitee(allAnnotations);
}

// 加载批注处理器
async function loadAnnotationsHandler(url) {
  await loadConfig();
  let allAnnotations = await getCachedAnnotations() || {};
  return allAnnotations[url] || {};
}

// 删除批注处理器
async function deleteAnnotationHandler(annotationId, url) {
  await loadConfig();
  let allAnnotations = await getCachedAnnotations() || {};
  
  if (allAnnotations[url] && allAnnotations[url][annotationId]) {
    delete allAnnotations[url][annotationId];
    // 先更新缓存
    annotationsCache = allAnnotations;
    cacheTimestamp = Date.now();
    chrome.storage.local.set({ 
      annotationsLocalCache: allAnnotations, 
      annotationsCacheTime: cacheTimestamp 
    }).catch(() => {});
    await saveToGitee(allAnnotations);
  }
}

// 插件安装/更新/重新加载时，向所有已打开的标签页重新注入 content script
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[WebNote Background] onInstalled, reason:', details.reason);
  
  // 设置点击扩展图标时自动打开侧边栏
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .then(() => console.log('[WebNote Background] 已设置点击图标打开侧边栏'))
    .catch(err => console.error('[WebNote Background] setPanelBehavior失败:', err));
  
  // 首次安装时打开配置页面
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
  
  // 向所有已打开的标签页重新注入 content script（处理扩展重新加载后旧脚本失效的问题）
  await reinjectContentScripts();
});

// 重新注入 content script 到所有标签页
async function reinjectContentScripts() {
  try {
    const tabs = await chrome.tabs.query({});
    
    // 过滤出可注入的标签页
    const injectableTabs = tabs.filter(tab => {
      return tab.url && 
        !tab.url.startsWith('chrome://') && 
        !tab.url.startsWith('chrome-extension://') &&
        !tab.url.startsWith('edge://') &&
        !tab.url.startsWith('about:') &&
        !tab.url.startsWith('devtools://') &&
        !tab.url.startsWith('view-source:');
    });
    
    // 优先注入当前活动标签页（让用户最快看到高亮）
    const activeTabs = injectableTabs.filter(tab => tab.active);
    const otherTabs = injectableTabs.filter(tab => !tab.active);
    
    // 注入单个标签页的函数
    const injectTab = async (tab) => {
      try {
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['styles.css']
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
        console.log('[WebNote Background] 成功注入 content script 到标签页:', tab.id, tab.url?.substring(0, 50));
      } catch (err) {
        console.warn('[WebNote Background] 注入失败(可忽略):', tab.id, err.message);
      }
    };
    
    // 先注入活动标签页（串行，确保最快完成）
    for (const tab of activeTabs) {
      await injectTab(tab);
    }
    
    // 然后并行注入其他标签页（不阻塞）
    await Promise.allSettled(otherTabs.map(tab => injectTab(tab)));
    
  } catch (error) {
    console.error('[WebNote Background] reinjectContentScripts 失败:', error);
  }
}

// 确保每次service worker启动时都设置行为（防止重启后丢失）
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch(() => {});