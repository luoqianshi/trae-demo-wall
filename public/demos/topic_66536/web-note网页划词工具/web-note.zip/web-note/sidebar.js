// 全局变量
let selectedColor = '#667eea';
let currentAnnotationId = null;
let currentUrl = '';
let allAnnotations = {};
let filteredAnnotations = [];
let isEditorCollapsed = true;

// DOM元素
const annotationCount = document.getElementById('annotationCount');
const pageUrl = document.getElementById('pageUrl');
const searchInput = document.getElementById('searchInput');
const searchClear = document.getElementById('searchClear');
const annotationsList = document.getElementById('annotationsList');
const emptyState = document.getElementById('emptyState');
const editorPanel = document.getElementById('editorPanel');
const editorPanelHeader = document.getElementById('editorPanelHeader');
const editorPanelTitle = document.getElementById('editorPanelTitle');
const editorPanelBody = document.getElementById('editorPanelBody');
const editorToggleBtn = document.getElementById('editorToggleBtn');
const colorPicker = document.getElementById('colorPicker');
const selectedTextElement = document.getElementById('selectedText');
const annotationInput = document.getElementById('annotationInput');
const submitBtn = document.getElementById('submitBtn');
const deleteBtn = document.getElementById('deleteBtn');
const cancelBtn = document.getElementById('cancelBtn');
const refreshBtn = document.getElementById('refreshBtn');
const homeBtn = document.getElementById('homeBtn');

// 初始化
async function init() {
  setupEventListeners();
  await resolveCurrentUrl();
  await loadAnnotationsList();
  const hasPendingEdit = await checkForPendingEdit();
  
  if (!hasPendingEdit) {
    collapseEditor();
  }
}

// 获取当前页面URL
async function resolveCurrentUrl() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].url) {
      currentUrl = getBaseUrl(tabs[0].url);
    } else {
      const result = await chrome.storage.local.get(['currentUrl']);
      currentUrl = result.currentUrl ? getBaseUrl(result.currentUrl) : '';
    }
  } catch (e) {
    const result = await chrome.storage.local.get(['currentUrl']);
    currentUrl = result.currentUrl ? getBaseUrl(result.currentUrl) : '';
  }
  
  updatePageInfo();
}

// 获取URL的标识部分（与content.js保持一致）
function getBaseUrl(href) {
  try {
    const url = new URL(href);
    const hash = url.hash;
    if (hash && hash.startsWith('#/')) {
      const hashPath = hash.split('?')[0];
      return url.origin + url.pathname + hashPath;
    }
    return url.origin + url.pathname;
  } catch (e) {
    return href;
  }
}

// 检查是否有待编辑的批注
async function checkForPendingEdit() {
  const result = await chrome.storage.local.get(['currentSelectedText', 'currentAnnotationId']);
  
  if (result.currentSelectedText) {
    selectedTextElement.textContent = result.currentSelectedText;
    expandEditor();
    editorPanelTitle.textContent = '新建批注';
    
    if (result.currentAnnotationId) {
      currentAnnotationId = result.currentAnnotationId;
      await loadExistingAnnotation(result.currentAnnotationId);
      editorPanelTitle.textContent = '编辑批注';
      deleteBtn.style.display = 'block';
    }
    
    await chrome.storage.local.set({ currentSelectedText: '', currentAnnotationId: '' });
    return true;
  }
  return false;
}

// 设置事件监听
function setupEventListeners() {
  // 搜索
  searchInput.addEventListener('input', handleSearch);
  searchClear.addEventListener('click', clearSearch);
  
  // 编辑面板
  editorPanelHeader.addEventListener('click', toggleEditor);
  colorPicker.addEventListener('click', handleColorSelect);
  submitBtn.addEventListener('click', submitAnnotation);
  deleteBtn.addEventListener('click', deleteAnnotation);
  cancelBtn.addEventListener('click', cancelEdit);
  annotationInput.addEventListener('keydown', handleKeyDown);
  
  // 头部按钮
  refreshBtn.addEventListener('click', refreshAnnotations);
  homeBtn.addEventListener('click', openHomePage);
  
  // 监听标签页切换
  chrome.tabs.onActivated.addListener(handleTabChange);
  chrome.tabs.onUpdated.addListener(handleTabUpdated);
  
  // 监听storage变化
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      // content script 重新注入后通知，需要重新建立端口连接
      if (changes.contentScriptReady && changes.contentScriptReady.newValue) {
        console.log('[WebNote Sidebar] content script 已就绪，重新建立端口连接');
        notifySidePanelOpened();
      }
      
      // 个人空间编辑/删除批注后通知，重新加载列表
      if (changes.annotationsUpdated && changes.annotationsUpdated.newValue) {
        console.log('[WebNote Sidebar] 批注数据已更新，重新加载列表');
        loadAnnotationsList();
      }
      
      if (changes.currentSelectedText && changes.currentSelectedText.newValue) {
        const newText = changes.currentSelectedText.newValue;
        selectedTextElement.textContent = newText;
      }
      
      if (changes.triggerEditor && changes.triggerEditor.newValue) {
        const newAnnotationId = changes.currentAnnotationId ? changes.currentAnnotationId.newValue : '';
        
        expandEditor();
        
        if (newAnnotationId && allAnnotations[newAnnotationId]) {
          currentAnnotationId = newAnnotationId;
          const annotation = allAnnotations[newAnnotationId];
          annotationInput.value = annotation.content;
          selectedColor = annotation.color;
          updateColorSelection();
          deleteBtn.style.display = 'block';
          editorPanelTitle.textContent = '编辑批注';
        } else {
          currentAnnotationId = null;
          deleteBtn.style.display = 'none';
          annotationInput.value = '';
          editorPanelTitle.textContent = '新建批注';
          selectedColor = '#667eea';
          updateColorSelection();
        }
        
        annotationInput.focus();
      }
    }
  });
}

// 打开个人空间页面（新标签页）
function openHomePage() {
  // 通过 background.js 打开个人空间页面
  chrome.runtime.sendMessage({ action: 'openHomePage' });
}

// 处理标签页切换
async function handleTabChange(activeInfo) {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab && tab.url) {
      const newUrl = getBaseUrl(tab.url);
      try {
        chrome.tabs.connect(activeInfo.tabId, { name: 'sidePanelPort' });
      } catch (e) {}
      
      if (newUrl !== currentUrl) {
        currentUrl = newUrl;
        updatePageInfo();
        cancelEdit();
        searchInput.value = '';
        searchClear.classList.remove('visible');
        allAnnotations = {};
        filteredAnnotations = [];
        annotationCount.textContent = '0';
        renderAnnotationsList();
        await loadAnnotationsList();
      }
    }
  } catch (e) {
    console.warn('处理标签页切换失败:', e);
  }
}

// 处理标签页URL更新
async function handleTabUpdated(tabId, changeInfo, tab) {
  if (changeInfo.status !== 'complete') return;
  
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].id === tabId && tabs[0].url) {
      const newUrl = getBaseUrl(tabs[0].url);
      if (newUrl !== currentUrl) {
        currentUrl = newUrl;
        updatePageInfo();
        cancelEdit();
        searchInput.value = '';
        searchClear.classList.remove('visible');
        allAnnotations = {};
        filteredAnnotations = [];
        annotationCount.textContent = '0';
        renderAnnotationsList();
        await loadAnnotationsList();
      }
    }
  } catch (e) {
    console.warn('处理标签页更新失败:', e);
  }
}

// 更新页面信息显示
function updatePageInfo() {
  if (currentUrl) {
    const displayUrl = currentUrl.replace(/^https?:\/\//, '');
    pageUrl.textContent = displayUrl;
    pageUrl.title = currentUrl;
  } else {
    pageUrl.textContent = '未检测到页面';
  }
}

// 搜索处理
function handleSearch() {
  const query = searchInput.value.trim().toLowerCase();
  searchClear.classList.toggle('visible', query.length > 0);
  
  if (query) {
    filteredAnnotations = Object.values(allAnnotations).filter(a => 
      a.text.toLowerCase().includes(query) || 
      a.content.toLowerCase().includes(query)
    );
  } else {
    filteredAnnotations = Object.values(allAnnotations);
  }
  
  renderAnnotationsList();
}

// 清除搜索
function clearSearch() {
  searchInput.value = '';
  searchClear.classList.remove('visible');
  filteredAnnotations = Object.values(allAnnotations);
  renderAnnotationsList();
}

// 加载批注列表
async function loadAnnotationsList() {
  if (!currentUrl) {
    annotationCount.textContent = '0';
    renderEmptyState();
    return;
  }
  
  try {
    const response = await chrome.runtime.sendMessage({ 
      action: 'loadAnnotations',
      url: currentUrl
    });
    
    allAnnotations = response.annotations || {};
    filteredAnnotations = Object.values(allAnnotations);
    filteredAnnotations.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    annotationCount.textContent = filteredAnnotations.length.toString();
    renderAnnotationsList();
  } catch (error) {
    console.error('加载批注列表失败:', error);
    showToast('加载失败，请重试');
  }
}

// 渲染批注列表
function renderAnnotationsList() {
  if (filteredAnnotations.length === 0) {
    renderEmptyState();
    return;
  }
  
  annotationsList.innerHTML = filteredAnnotations.map(annotation => `
    <div class="annotation-card ${annotation.id === currentAnnotationId ? 'active' : ''}" data-id="${annotation.id}">
      <div class="annotation-card-color" style="background-color: ${annotation.color}"></div>
      <div class="annotation-card-header">
        <div class="annotation-card-text">${escapeHtml(annotation.text)}</div>
        <div class="annotation-card-actions">
          <button class="card-action-btn btn-locate" data-action="locate" data-id="${annotation.id}" title="定位到页面">📍</button>
          <button class="card-action-btn btn-edit" data-action="edit" data-id="${annotation.id}" title="编辑">✏️</button>
          <button class="card-action-btn btn-delete" data-action="delete" data-id="${annotation.id}" title="删除">🗑️</button>
        </div>
      </div>
      <div class="annotation-card-content markdown-body">${renderMarkdown(annotation.content)}</div>
      <div class="annotation-card-footer">
        <span class="annotation-card-time">${formatTime(annotation.createdAt)}</span>
        <span class="annotation-card-copy" data-action="copy" data-id="${annotation.id}">复制内容</span>
      </div>
    </div>
  `).join('');
  
  annotationsList.querySelectorAll('.annotation-card').forEach(card => {
    card.addEventListener('click', handleCardClick);
  });
}

// 渲染空状态
function renderEmptyState() {
  const query = searchInput.value.trim();
  if (query) {
    annotationsList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <div class="empty-text">未找到匹配的批注</div>
        <div class="empty-hint">尝试其他关键词</div>
      </div>
    `;
  } else {
    annotationsList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <div class="empty-text">暂无批注</div>
        <div class="empty-hint">在页面上选中文本，点击图标即可创建批注</div>
      </div>
    `;
  }
}

// 处理卡片点击
function handleCardClick(e) {
  const actionBtn = e.target.closest('[data-action]');
  if (actionBtn) {
    e.stopPropagation();
    const action = actionBtn.getAttribute('data-action');
    const id = actionBtn.getAttribute('data-id');
    
    switch (action) {
      case 'locate': locateAnnotation(id); break;
      case 'edit': editAnnotation(id); break;
      case 'delete': deleteAnnotationById(id); break;
      case 'copy': copyAnnotationContent(id); break;
    }
    return;
  }
  
  const card = e.currentTarget;
  const id = card.getAttribute('data-id');
  editAnnotation(id);
}

// 定位到页面中的批注
async function locateAnnotation(id) {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) {
      await chrome.tabs.sendMessage(tabs[0].id, {
        action: 'scrollToAnnotation',
        annotationId: id
      });
      showToast('已定位到批注位置');
    }
  } catch (e) {
    showToast('定位失败，请刷新页面重试');
  }
}

// 编辑批注
function editAnnotation(id) {
  const annotation = allAnnotations[id];
  if (!annotation) return;
  
  currentAnnotationId = id;
  selectedTextElement.textContent = annotation.text;
  annotationInput.value = annotation.content;
  selectedColor = annotation.color;
  updateColorSelection();
  deleteBtn.style.display = 'block';
  editorPanelTitle.textContent = '编辑批注';
  
  expandEditor();
  annotationInput.focus();
  
  document.querySelectorAll('.annotation-card').forEach(card => {
    card.classList.toggle('active', card.getAttribute('data-id') === id);
  });
}

// 删除批注（通过卡片按钮）
async function deleteAnnotationById(id) {
  if (!confirm('确定要删除这条批注吗？')) return;
  
  try {
    await chrome.runtime.sendMessage({ 
      action: 'deleteAnnotation',
      annotationId: id,
      url: currentUrl
    });
    
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        await chrome.tabs.sendMessage(tabs[0].id, {
          action: 'removeHighlight',
          annotationId: id
        });
      }
    } catch (e) {}
    
    delete allAnnotations[id];
    filteredAnnotations = filteredAnnotations.filter(a => a.id !== id);
    annotationCount.textContent = Object.keys(allAnnotations).length.toString();
    renderAnnotationsList();
    
    if (currentAnnotationId === id) {
      cancelEdit();
    }
    
    showToast('批注已删除');
  } catch (error) {
    showToast('删除失败: ' + error.message);
  }
}

// 复制批注内容
function copyAnnotationContent(id) {
  const annotation = allAnnotations[id];
  if (!annotation) return;
  
  const text = `「${annotation.text}」\n${annotation.content}`;
  navigator.clipboard.writeText(text).then(() => {
    showToast('已复制到剪贴板');
  }).catch(() => {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    showToast('已复制到剪贴板');
  });
}

// 加载现有批注
async function loadExistingAnnotation(annotationId) {
  const annotation = allAnnotations[annotationId];
  if (annotation) {
    annotationInput.value = annotation.content;
    selectedColor = annotation.color;
    updateColorSelection();
    selectedTextElement.textContent = annotation.text;
    return;
  }
  
  try {
    const response = await chrome.runtime.sendMessage({ 
      action: 'getAnnotationData',
      annotationId: annotationId
    });
    
    if (response.annotation) {
      annotationInput.value = response.annotation.content;
      selectedColor = response.annotation.color;
      updateColorSelection();
      selectedTextElement.textContent = response.annotation.text;
    }
  } catch (error) {
    console.error('加载批注失败:', error);
  }
}

// 编辑面板：展开/折叠
function toggleEditor() {
  if (isEditorCollapsed) {
    expandEditor();
  } else {
    collapseEditor();
  }
}

function expandEditor() {
  isEditorCollapsed = false;
  editorPanel.classList.remove('collapsed');
  editorToggleBtn.textContent = '▼';
}

function collapseEditor() {
  isEditorCollapsed = true;
  editorPanel.classList.add('collapsed');
  editorToggleBtn.textContent = '▲';
}

// 取消编辑
function cancelEdit() {
  currentAnnotationId = null;
  annotationInput.value = '';
  selectedTextElement.textContent = '请先在页面上选择文本';
  deleteBtn.style.display = 'none';
  editorPanelTitle.textContent = '新建批注';
  selectedColor = '#667eea';
  updateColorSelection();
  collapseEditor();
  
  document.querySelectorAll('.annotation-card').forEach(card => {
    card.classList.remove('active');
  });
}

// 处理颜色选择
function handleColorSelect(e) {
  if (e.target.classList.contains('color-option')) {
    selectedColor = e.target.getAttribute('data-color');
    updateColorSelection();
  }
}

// 更新颜色选择状态
function updateColorSelection() {
  document.querySelectorAll('.color-option').forEach(option => {
    option.classList.remove('selected');
    if (option.getAttribute('data-color') === selectedColor) {
      option.classList.add('selected');
    }
  });
}

// 处理键盘事件
function handleKeyDown(e) {
  if (e.key === 'Enter') {
    if (e.shiftKey) {
      return;
    } else {
      e.preventDefault();
      submitAnnotation();
    }
  }
}

// 提交批注
async function submitAnnotation() {
  const content = annotationInput.value.trim();
  const text = selectedTextElement.textContent.trim();
  
  if (!content) {
    showToast('请输入批注内容');
    return;
  }
  
  if (!text || text === '请先在页面上选择文本') {
    showToast('请先在页面上选择文本');
    return;
  }
  
  // 获取当前标签页的 title 和上下文信息
  let pageTitle = '';
  let contextBefore = '';
  let contextAfter = '';
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].title) {
      pageTitle = tabs[0].title;
    }
  } catch (e) {}
  
  // 优先从storage中获取上下文（在选中文本时已精确计算并缓存）
  try {
    const stored = await chrome.storage.local.get(['currentContextBefore', 'currentContextAfter']);
    contextBefore = stored.currentContextBefore || '';
    contextAfter = stored.currentContextAfter || '';
  } catch (e) {
    console.warn('获取缓存上下文失败:', e);
  }
  
  // 如果storage中没有上下文，尝试从content script获取（兜底）
  if (!contextBefore && !contextAfter) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        const contextResult = await chrome.tabs.sendMessage(tabs[0].id, {
          action: 'getTextContext',
          text: text
        });
        if (contextResult) {
          contextBefore = contextResult.contextBefore || '';
          contextAfter = contextResult.contextAfter || '';
        }
      }
    } catch (e) {
      console.warn('获取文本上下文失败:', e);
    }
  }
  
  const annotation = {
    id: currentAnnotationId || Date.now().toString(),
    text: text,
    content: content,
    color: selectedColor,
    url: currentUrl,
    pageTitle: pageTitle,
    contextBefore: contextBefore,
    contextAfter: contextAfter,
    createdAt: currentAnnotationId ? (allAnnotations[currentAnnotationId]?.createdAt || new Date().toISOString()) : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  try {
    await chrome.runtime.sendMessage({ 
      action: 'saveAnnotation',
      annotation: annotation,
      url: currentUrl
    });
    
    allAnnotations[annotation.id] = annotation;
    filteredAnnotations = Object.values(allAnnotations);
    filteredAnnotations.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    annotationCount.textContent = Object.keys(allAnnotations).length.toString();
    renderAnnotationsList();
    
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        await chrome.tabs.sendMessage(tabs[0].id, { 
          action: 'highlightText',
          annotation: annotation
        });
      }
    } catch (e) {
      console.warn('通知content script失败:', e);
    }
    
    const isEditing = !!currentAnnotationId;
    cancelEdit();
    showToast(isEditing ? '批注已更新' : '批注已保存');
    
  } catch (error) {
    showToast('保存失败: ' + error.message);
  }
}

// 删除批注（通过编辑面板按钮）
async function deleteAnnotation() {
  if (!currentAnnotationId) return;
  await deleteAnnotationById(currentAnnotationId);
}

// 刷新批注
async function refreshAnnotations() {
  const refreshIcon = document.getElementById('refreshIcon');
  refreshIcon.classList.add('spinning');
  await resolveCurrentUrl();
  await loadAnnotationsList();
  setTimeout(() => { refreshIcon.classList.remove('spinning'); }, 600);
  showToast('已刷新');
}

// 格式化时间
function formatTime(isoStr) {
  if (!isoStr) return '';
  const date = new Date(isoStr);
  const now = new Date();
  const diff = now - date;
  
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  if (date.toDateString() === now.toDateString()) {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) {
    return '昨天 ' + date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }
  return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + 
         date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

// Toast提示
function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  requestAnimationFrame(() => {
    toast.classList.add('visible');
  });
  
  setTimeout(() => {
    toast.classList.remove('visible');
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

// HTML转义
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Markdown渲染
function renderMarkdown(text) {
  if (!text) return '';
  try {
    if (typeof marked !== 'undefined') {
      marked.setOptions({
        breaks: true,
        gfm: true
      });
      return marked.parse(text);
    }
  } catch (e) {
    console.warn('Markdown渲染失败:', e);
  }
  return escapeHtml(text);
}

// 启动
init();

// 通知 content script：sidePanel 已打开
async function notifySidePanelOpened() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) {
      chrome.tabs.connect(tabs[0].id, { name: 'sidePanelPort' });
    }
  } catch (e) {
    console.warn('建立端口连接失败:', e);
  }
}

notifySidePanelOpened();