# TradeHunter Pro

> 多Agent协作的外贸智能获客SaaS平台

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Tech Stack](https://img.shields.io/badge/tech-React%20%7C%20NestJS%20%7C%20FastAPI-green.svg)](docs/外贸获客项目规划.md)

---

## 目录

- [项目简介](#项目简介)
- [功能模块](#功能模块)
- [技术架构](#技术架构)
- [快速开始](#快速开始)
- [项目结构](#项目结构)
- [API文档](#api文档)
- [数据库](#数据库)
- [开发指南](#开发指南)
- [部署方式](#部署方式)
- [许可证](#许可证)

---

## 项目简介

**TradeHunter Pro** 是一个基于多Agent协作的外贸智能获客SaaS平台，旨在帮助外贸企业高效挖掘客户线索、自动化邮件营销、智能跟进转化，大幅提升获客效率和转化率。

### 核心价值

| 指标 | 传统方式 | TradeHunter Pro | 提升幅度 |
|------|---------|-----------------|---------|
| 每日挖掘线索数 | 20-50条 | 200-500条 | **10倍** |
| 开发信回复率 | <1% | 3-5% | **5倍** |
| 业务员人效 | 80%重复工作 | 80%跟进高意向客户 | **4倍** |
| 获客成本 | ¥200-500/线索 | ¥50-80/线索 | **降低60%** |

---

## 功能模块

### 已实现功能

| 模块 | 功能描述 |
|------|---------|
| **用户认证** | 注册/登录、JWT认证、个人信息管理 |
| **仪表盘** | 核心指标展示、数据趋势图表 |
| **市场配置** | 目标市场设置、产品管理、关键词配置 |
| **线索管理** | 线索列表、详情查看、搜索筛选 |
| **邮件营销** | 邮箱账户配置、邮件模板、批量发送 |
| **客户管理** | 商机管道、跟进记录、标签体系 |
| **数据分析** | 渠道效果分析、转化漏斗统计 |
| **地图搜索** | Google Places API地图获客搜索 |
| **任务管理** | 任务列表、状态管理 |

### AI Agent团队

- **线索挖掘Agent** - 多渠道搜索潜在客户
- **数据清洗Agent** - 去重、验证、信息补全
- **邮件撰写Agent** - 个性化开发信生成
- **邮件发送Agent** - 批量发送、追踪统计
- **回复处理Agent** - 自动分析客户回复
- **数据分析Agent** - 统计报表、优化建议

---

## 技术架构

### 前端技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| React | 18.x | UI框架 |
| TypeScript | 5.x | 类型安全 |
| Vite | 5.x | 构建工具 |
| Ant Design | 5.x | UI组件库 |
| Tailwind CSS | 3.x | CSS框架 |
| Zustand | 4.x | 状态管理 |
| React Router | 6.x | 路由管理 |

### 后端技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Node.js | 20.x | 运行环境 |
| NestJS | 10.x | 后端框架 |
| TypeORM | 0.3.x | ORM |
| SQLite | - | 数据库 (better-sqlite3) |
| JWT | - | 认证 |
| Swagger | - | API文档 |

### AI服务技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Python | 3.x | 运行环境 |
| FastAPI | - | AI服务框架 |

---

## 快速开始

### 前提条件

- Node.js >= 20.x
- npm >= 10.x
- Python >= 3.8 (可选，AI服务)
- Docker (可选，容器化部署)

### 安装依赖

```bash
# 安装根目录依赖
npm install

# 安装前端依赖
cd frontend && npm install

# 安装后端依赖
cd ../backend && npm install

# 安装AI服务依赖 (可选)
cd ../ai && pip install -r requirements.txt
```

### 开发模式启动

```bash
# 方式1: 同时启动所有服务
npm run start

# 方式2: 分别启动
npm run start:frontend   # http://localhost:5173
npm run start:backend    # http://localhost:3000
npm run start:ai         # http://localhost:8001
```

### 默认登录账号

| 项 | 值 |
|----|----|
| 邮箱 | `admin@example.com` |
| 密码 | `123456` |

---

## 项目结构

```
tradeHunterPro/
├── ai/                      # AI服务 (Python + FastAPI)
│   ├── app.py               # AI服务入口
│   └── requirements.txt     # Python依赖
├── backend/                 # 后端服务 (NestJS)
│   ├── src/
│   │   ├── config/          # 配置文件
│   │   ├── database/        # 数据库实体
│   │   ├── modules/         # 业务模块
│   │   │   ├── auth/        # 认证模块
│   │   │   ├── dashboard/   # 仪表盘模块
│   │   │   ├── email/       # 邮件营销模块
│   │   │   ├── follow-up/   # 跟进记录模块
│   │   │   ├── leads/       # 线索管理模块
│   │   │   ├── map-search/  # 地图搜索模块
│   │   │   ├── market/      # 市场配置模块
│   │   │   ├── opportunities/ # 商机模块
│   │   │   └── tasks/       # 任务模块
│   │   ├── shared/          # 共享组件
│   │   ├── app.module.ts    # 应用模块
│   │   └── main.ts          # 入口文件
│   ├── data/                # SQLite数据库文件
│   └── dist/                # 编译输出
├── frontend/                # 前端应用 (React)
│   ├── src/
│   │   ├── layouts/         # 布局组件
│   │   ├── pages/           # 页面组件
│   │   ├── services/        # API服务
│   │   ├── store/           # 状态管理
│   │   ├── types/           # 类型定义
│   │   └── utils/           # 工具函数
│   └── dist/                # 构建输出
├── docs/                    # 项目文档
├── docker-compose.yml       # Docker Compose配置
└── package.json             # 项目配置
```

---

## API文档

后端服务启动后，访问以下地址查看API文档：

- **Swagger UI**: http://localhost:3000/docs

### API端点概览

| 模块 | 前缀 | 描述 |
|------|------|------|
| 认证 | `/api/auth` | 注册、登录、用户信息 |
| 仪表盘 | `/api/dashboard` | 数据统计、核心指标 |
| 线索 | `/api/leads` | 线索CRUD操作 |
| 市场 | `/api/market` | 市场配置管理 |
| 邮件 | `/api/email` | 邮件账户、模板、发送 |
| 商机 | `/api/opportunities` | 商机管理 |
| 跟进 | `/api/follow-up` | 跟进记录 |
| 任务 | `/api/tasks` | 任务管理 |
| 地图搜索 | `/api/map-search` | 地图获客搜索 |

---

## 数据库

项目使用 SQLite 数据库，数据库文件位于：

```
backend/data/db.sqlite
```

### 数据库表结构

| 表名 | 说明 |
|------|------|
| `users` | 用户表 |
| `tenants` | 租户表 |
| `leads` | 线索表 |
| `email_accounts` | 邮箱账户表 |
| `email_templates` | 邮件模板表 |
| `email_campaigns` | 邮件活动表 |
| `email_records` | 邮件记录表 |
| `opportunities` | 商机表 |
| `follow_up_records` | 跟进记录表 |
| `tasks` | 任务表 |
| `market_configs` | 市场配置表 |
| `products` | 产品表 |
| `keywords` | 关键词表 |
| `target_countries` | 目标国家表 |

---

## 开发指南

### 环境变量

后端环境变量配置文件：`backend/.env`

```env
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=password
DB_DATABASE=tradehunter
JWT_SECRET=secret-key-change-in-production
JWT_EXPIRES_IN=1d
CORS_ORIGIN=http://localhost:5173
GOOGLE_PLACES_API_KEY=your-google-places-api-key
```

### 代码规范

- **前端**: ESLint + TypeScript类型检查
- **后端**: ESLint + TypeScript类型检查
- **提交规范**: 遵循Conventional Commits

### 测试

```bash
# 后端测试
cd backend && npm test

# 前端测试
cd frontend && npm test
```

---

## 部署方式

### Docker部署

```bash
# 构建并启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 停止服务
docker-compose down
```

### 生产部署

1. **前端构建**: `npm run build:frontend`
2. **后端构建**: `npm run build:backend`
3. **配置环境变量**: 设置生产环境变量
4. **启动服务**: `npm run start:prod`

---

## 许可证

MIT License - 详见 [LICENSE](LICENSE)

---

## 贡献

欢迎提交Issue和Pull Request！

---

## 联系我们

如有问题或建议，请通过以下方式联系：

- 项目文档: [docs/外贸获客项目规划.md](docs/外贸获客项目规划.md)
- 需求文档: [docs/需求细分文档.md](docs/需求细分文档.md)