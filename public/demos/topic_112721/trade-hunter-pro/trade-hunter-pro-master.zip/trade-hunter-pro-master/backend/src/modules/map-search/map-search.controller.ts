import { Controller, Get, Post, Query, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { MapSearchService } from './map-search.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { SearchDto } from './dto/search.dto';
import { ImportDto } from './dto/import.dto';

@Controller('map-search')
@ApiTags('地图获客')
@UseGuards(JwtAuthGuard)
export class MapSearchController {
  constructor(private mapSearchService: MapSearchService) {}

  @Get()
  @ApiOperation({ summary: '搜索地图商家' })
  @ApiResponse({ status: 200, description: '搜索成功' })
  async search(@Query() dto: SearchDto) {
    const result = await this.mapSearchService.search(dto);
    return { success: true, message: '搜索成功', data: result };
  }

  @Post('import')
  @ApiOperation({ summary: '批量导入为线索' })
  @ApiResponse({ status: 200, description: '导入成功' })
  async import(@GetCurrentUser() user: User, @Body() dto: ImportDto) {
    const result = await this.mapSearchService.importPlaces(dto, user.tenantId);
    return { success: true, message: '导入完成', data: result };
  }
}
