import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

@Entity('market_configs')
export class MarketConfig {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  targetRegion: string;

  @Column('text', { default: '[]' })
  @ApiProperty()
  languages: string[];

  @Column()
  @ApiProperty()
  customerType: string;

  @Column({ nullable: true })
  @ApiProperty()
  customerSize: string;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}