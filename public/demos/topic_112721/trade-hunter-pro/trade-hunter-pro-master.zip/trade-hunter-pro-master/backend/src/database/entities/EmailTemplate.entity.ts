import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type TemplateType = 'cold' | 'follow-up' | 'quote' | 'custom';

@Entity('email_templates')
export class EmailTemplate {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  name: string;

  @Column()
  @ApiProperty()
  subject: string;

  @Column('text')
  @ApiProperty()
  body: string;

  @Column({ type: 'varchar', default: 'custom' })
  @ApiProperty()
  type: TemplateType;

  @Column('text', { default: '[]' })
  @ApiProperty()
  variables: string[];

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}