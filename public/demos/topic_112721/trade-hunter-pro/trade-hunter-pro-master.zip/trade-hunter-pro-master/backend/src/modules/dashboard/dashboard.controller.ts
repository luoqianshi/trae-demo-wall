import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DashboardService } from './dashboard.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';

@Controller('dashboard')
@ApiTags('数据看板')
@UseGuards(JwtAuthGuard)
export class DashboardController {
  constructor(private dashboardService: DashboardService) {}

  @Get('overview')
  @ApiOperation({ summary: '获取概览数据' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getOverview(@GetCurrentUser() user: User) {
    const result = await this.dashboardService.getOverview(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('lead-trend')
  @ApiOperation({ summary: '获取线索趋势' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getLeadTrend(
    @GetCurrentUser() user: User,
    @Query('days') days?: number,
  ) {
    const result = await this.dashboardService.getLeadTrend(user.tenantId, days);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('campaign-stats')
  @ApiOperation({ summary: '获取邮件营销统计' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getCampaignStats(@GetCurrentUser() user: User) {
    const result = await this.dashboardService.getCampaignStats(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }
}