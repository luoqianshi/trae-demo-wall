import { Controller, Get, Post, Put, Delete, Query, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { TasksService } from './tasks.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { Task } from '@/database/entities/Task.entity';

@Controller('tasks')
@ApiTags('任务管理')
@UseGuards(JwtAuthGuard)
export class TasksController {
  constructor(private tasksService: TasksService) {}

  @Get()
  @ApiOperation({ summary: '获取任务列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findAll(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number; status?: string },
  ) {
    const result = await this.tasksService.findAll(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }

  @Get(':id')
  @ApiOperation({ summary: '获取任务详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findOne(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.tasksService.findOne(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post()
  @ApiOperation({ summary: '创建任务' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async create(@GetCurrentUser() user: User, @Body() data: Partial<Task>) {
    const result = await this.tasksService.create(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put(':id')
  @ApiOperation({ summary: '更新任务' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async update(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<Task>) {
    const result = await this.tasksService.update(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete(':id')
  @ApiOperation({ summary: '删除任务' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async delete(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.tasksService.delete(id, user.tenantId);
  }
}