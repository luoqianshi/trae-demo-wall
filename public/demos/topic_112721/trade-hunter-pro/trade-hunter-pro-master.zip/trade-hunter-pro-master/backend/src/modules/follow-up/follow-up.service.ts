import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FollowUpRecord } from '@/database/entities/FollowUpRecord.entity';

@Injectable()
export class FollowUpService {
  constructor(
    @InjectRepository(FollowUpRecord) private followUpRepository: Repository<FollowUpRecord>,
  ) {}

  async findByLead(leadId: string, tenantId: string) {
    return this.followUpRepository.find({
      where: { leadId, tenantId },
      order: { createdAt: 'DESC' },
    });
  }

  async create(tenantId: string, data: Partial<FollowUpRecord>) {
    const record = this.followUpRepository.create({ ...data, tenantId });
    return this.followUpRepository.save(record);
  }

  async update(id: string, tenantId: string, data: Partial<FollowUpRecord>) {
    await this.followUpRepository.update({ id, tenantId }, data);
    return this.followUpRepository.findOne({ where: { id, tenantId } });
  }

  async delete(id: string, tenantId: string) {
    await this.followUpRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }
}