import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Task } from '@/database/entities/Task.entity';

@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task) private taskRepository: Repository<Task>,
  ) {}

  async findAll(tenantId: string, params: { page?: number; pageSize?: number; status?: string }) {
    const { page = 1, pageSize = 20, status } = params;
    const query = this.taskRepository.createQueryBuilder('task')
      .where('task.tenantId = :tenantId', { tenantId });

    if (status) {
      query.andWhere('task.status = :status', { status });
    }

    const [data, total] = await query
      .skip((page - 1) * pageSize)
      .take(pageSize)
      .orderBy('task.createdAt', 'DESC')
      .getManyAndCount();

    return { data, total, page, pageSize };
  }

  async findOne(id: string, tenantId: string) {
    return this.taskRepository.findOne({ where: { id, tenantId } });
  }

  async create(tenantId: string, data: Partial<Task>) {
    const task = this.taskRepository.create({ ...data, tenantId });
    return this.taskRepository.save(task);
  }

  async update(id: string, tenantId: string, data: Partial<Task>) {
    await this.taskRepository.update({ id, tenantId }, data);
    return this.findOne(id, tenantId);
  }

  async delete(id: string, tenantId: string) {
    await this.taskRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }
}