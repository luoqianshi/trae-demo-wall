import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { EmailTemplate } from '@/database/entities/EmailTemplate.entity';
import { EmailRecord } from '@/database/entities/EmailRecord.entity';

@Injectable()
export class EmailService {
  constructor(
    @InjectRepository(EmailCampaign) private campaignRepository: Repository<EmailCampaign>,
    @InjectRepository(EmailTemplate) private templateRepository: Repository<EmailTemplate>,
    @InjectRepository(EmailRecord) private sentEmailRepository: Repository<EmailRecord>,
  ) {}

  async getCampaigns(tenantId: string, params: { page?: number; pageSize?: number; status?: string }) {
    const { page = 1, pageSize = 20, status } = params;
    const query = this.campaignRepository.createQueryBuilder('campaign')
      .where('campaign.tenantId = :tenantId', { tenantId });

    if (status) {
      query.andWhere('campaign.status = :status', { status });
    }

    const [data, total] = await query
      .skip((page - 1) * pageSize)
      .take(pageSize)
      .orderBy('campaign.createdAt', 'DESC')
      .getManyAndCount();

    return { data, total, page, pageSize };
  }

  async getCampaign(id: string, tenantId: string) {
    return this.campaignRepository.findOne({ where: { id, tenantId } });
  }

  async createCampaign(tenantId: string, data: Partial<EmailCampaign>) {
    const campaign = this.campaignRepository.create({ ...data, tenantId });
    return this.campaignRepository.save(campaign);
  }

  async updateCampaign(id: string, tenantId: string, data: Partial<EmailCampaign>) {
    await this.campaignRepository.update({ id, tenantId }, data);
    return this.getCampaign(id, tenantId);
  }

  async deleteCampaign(id: string, tenantId: string) {
    await this.campaignRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }

  async getTemplates(tenantId: string) {
    return this.templateRepository.find({ where: { tenantId } });
  }

  async getTemplate(id: string, tenantId: string) {
    return this.templateRepository.findOne({ where: { id, tenantId } });
  }

  async createTemplate(tenantId: string, data: Partial<EmailTemplate>) {
    const template = this.templateRepository.create({ ...data, tenantId });
    return this.templateRepository.save(template);
  }

  async updateTemplate(id: string, tenantId: string, data: Partial<EmailTemplate>) {
    await this.templateRepository.update({ id, tenantId }, data);
    return this.getTemplate(id, tenantId);
  }

  async deleteTemplate(id: string, tenantId: string) {
    await this.templateRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }

  async getSentEmails(tenantId: string, params: { page?: number; pageSize?: number }) {
    const { page = 1, pageSize = 20 } = params;
    const [data, total] = await this.sentEmailRepository.findAndCount({
      where: { tenantId },
      skip: (page - 1) * pageSize,
      take: pageSize,
      order: { createdAt: 'DESC' },
    });
    return { data, total, page, pageSize };
  }
}