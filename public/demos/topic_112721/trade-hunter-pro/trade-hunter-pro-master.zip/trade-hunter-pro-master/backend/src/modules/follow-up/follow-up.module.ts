import { Module } from '@nestjs/common';
import { FollowUpService } from './follow-up.service';
import { FollowUpController } from './follow-up.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FollowUpRecord } from '@/database/entities/FollowUpRecord.entity';

@Module({
  imports: [TypeOrmModule.forFeature([FollowUpRecord])],
  providers: [FollowUpService],
  controllers: [FollowUpController],
})
export class FollowUpModule {}