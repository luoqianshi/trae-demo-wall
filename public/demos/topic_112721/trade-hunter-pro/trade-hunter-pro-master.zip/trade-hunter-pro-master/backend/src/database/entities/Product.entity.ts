import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  name: string;

  @Column()
  @ApiProperty()
  category: string;

  @Column()
  @ApiProperty()
  subCategory: string;

  @Column({ type: 'double' })
  @ApiProperty()
  priceMin: number;

  @Column({ type: 'double' })
  @ApiProperty()
  priceMax: number;

  @Column()
  @ApiProperty()
  moq: number;

  @Column({ nullable: true })
  @ApiProperty()
  description: string;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}