import { Controller, Get, Post, Put, Delete, Query, Body, Param, UseGuards, Res } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Response } from 'express';
import { LeadsService } from './leads.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { Lead } from '@/database/entities/Lead.entity';

@Controller('leads')
@ApiTags('线索管理')
@UseGuards(JwtAuthGuard)
export class LeadsController {
  constructor(private leadsService: LeadsService) {}

  @Get()
  @ApiOperation({ summary: '获取线索列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findAll(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number; status?: string; grade?: string; keyword?: string },
  ) {
    const result = await this.leadsService.findAll(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('export')
  @ApiOperation({ summary: '导出线索' })
  @ApiResponse({ status: 200, description: '导出成功' })
  async export(@GetCurrentUser() user: User, @Query() params: { status?: string }, @Res() res: Response) {
    const leads = await this.leadsService.export(user.tenantId, params);
    const csv = [
      ['公司名称', '邮箱', '联系人', '职位', '电话', '地址', '来源', '状态', '评分', '等级'].join(','),
      ...leads.map(l => [
        `"${l.companyName}"`,
        `"${l.email}"`,
        `"${l.contactPerson || ''}"`,
        `"${l.contactTitle || ''}"`,
        `"${l.phone || ''}"`,
        `"${l.address || ''}"`,
        `"${l.source}"`,
        `"${l.status}"`,
        l.score,
        `"${l.grade}"`,
      ].join(',')),
    ].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=leads.csv');
    res.send(`\uFEFF${csv}`);
  }

  @Get(':id')
  @ApiOperation({ summary: '获取线索详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findOne(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.leadsService.findOne(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post()
  @ApiOperation({ summary: '创建线索' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async create(@GetCurrentUser() user: User, @Body() data: Partial<Lead>) {
    const result = await this.leadsService.create(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put(':id')
  @ApiOperation({ summary: '更新线索' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async update(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<Lead>) {
    const result = await this.leadsService.update(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete(':id')
  @ApiOperation({ summary: '删除线索' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async delete(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.leadsService.delete(id, user.tenantId);
  }
}