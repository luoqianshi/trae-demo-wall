import { Controller, Get, Post, Put, Delete, Query, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { MarketService } from './market.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { MarketConfig } from '@/database/entities/MarketConfig.entity';
import { Product } from '@/database/entities/Product.entity';
import { Keyword } from '@/database/entities/Keyword.entity';
import { TargetCountry } from '@/database/entities/TargetCountry.entity';

@Controller('market')
@ApiTags('市场配置')
@UseGuards(JwtAuthGuard)
export class MarketController {
  constructor(private marketService: MarketService) {}

  @Get('config')
  @ApiOperation({ summary: '获取市场配置' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getConfig(@GetCurrentUser() user: User) {
    const result = await this.marketService.getConfig(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Put('config')
  @ApiOperation({ summary: '更新市场配置' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateConfig(@GetCurrentUser() user: User, @Body() data: Partial<MarketConfig>) {
    const result = await this.marketService.updateConfig(user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Get('products')
  @ApiOperation({ summary: '获取产品列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getProducts(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number },
  ) {
    const result = await this.marketService.getProducts(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('products/:id')
  @ApiOperation({ summary: '获取产品详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getProduct(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.marketService.getProduct(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post('products')
  @ApiOperation({ summary: '创建产品' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async createProduct(@GetCurrentUser() user: User, @Body() data: Partial<Product>) {
    const result = await this.marketService.createProduct(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put('products/:id')
  @ApiOperation({ summary: '更新产品' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateProduct(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<Product>) {
    const result = await this.marketService.updateProduct(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete('products/:id')
  @ApiOperation({ summary: '删除产品' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async deleteProduct(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.marketService.deleteProduct(id, user.tenantId);
  }

  @Get('keywords')
  @ApiOperation({ summary: '获取关键词列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getKeywords(@GetCurrentUser() user: User) {
    const result = await this.marketService.getKeywords(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post('keywords')
  @ApiOperation({ summary: '创建关键词' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async createKeyword(@GetCurrentUser() user: User, @Body() data: Partial<Keyword>) {
    const result = await this.marketService.createKeyword(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put('keywords/:id')
  @ApiOperation({ summary: '更新关键词' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateKeyword(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<Keyword>) {
    const result = await this.marketService.updateKeyword(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete('keywords/:id')
  @ApiOperation({ summary: '删除关键词' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async deleteKeyword(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.marketService.deleteKeyword(id, user.tenantId);
  }

  @Get('countries')
  @ApiOperation({ summary: '获取目标国家列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getCountries(@GetCurrentUser() user: User) {
    const result = await this.marketService.getCountries(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post('countries')
  @ApiOperation({ summary: '添加目标国家' })
  @ApiResponse({ status: 201, description: '添加成功' })
  async createCountry(@GetCurrentUser() user: User, @Body() data: Partial<TargetCountry>) {
    const result = await this.marketService.createCountry(user.tenantId, data);
    return { success: true, message: '添加成功', data: result };
  }

  @Delete('countries/:id')
  @ApiOperation({ summary: '删除目标国家' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async deleteCountry(@Param('id') id: string) {
    return this.marketService.deleteCountry(id);
  }
}