import { Controller, Post, Body, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';

class RegisterDto {
  email: string;
  password: string;
  name: string;
  companyName: string;
}

class LoginDto {
  email: string;
  password: string;
}

@Controller('auth')
@ApiTags('认证')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('register')
  @ApiOperation({ summary: '用户注册' })
  @ApiResponse({ status: 201, description: '注册成功' })
  async register(@Body() dto: RegisterDto) {
    return this.authService.register(dto.email, dto.password, dto.name, dto.companyName);
  }

  @Post('login')
  @ApiOperation({ summary: '用户登录' })
  @ApiResponse({ status: 200, description: '登录成功' })
  async login(@Body() dto: LoginDto) {
    const result = await this.authService.login(dto.email, dto.password);
    return { success: true, message: '登录成功', data: result };
  }

  @Get('profile')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: '获取用户信息' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async profile(@GetCurrentUser() user: User) {
    return {
      success: true,
      message: '获取成功',
      data: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        tenantId: user.tenantId,
        createdAt: user.createdAt,
      },
    };
  }
}