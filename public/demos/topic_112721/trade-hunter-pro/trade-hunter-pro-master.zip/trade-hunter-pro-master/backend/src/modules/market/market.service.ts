import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MarketConfig } from '@/database/entities/MarketConfig.entity';
import { Product } from '@/database/entities/Product.entity';
import { Keyword } from '@/database/entities/Keyword.entity';
import { TargetCountry } from '@/database/entities/TargetCountry.entity';

@Injectable()
export class MarketService {
  constructor(
    @InjectRepository(MarketConfig) private configRepository: Repository<MarketConfig>,
    @InjectRepository(Product) private productRepository: Repository<Product>,
    @InjectRepository(Keyword) private keywordRepository: Repository<Keyword>,
    @InjectRepository(TargetCountry) private countryRepository: Repository<TargetCountry>,
  ) {}

  async getConfig(tenantId: string) {
    return this.configRepository.findOne({ where: { tenantId } });
  }

  async updateConfig(tenantId: string, data: Partial<MarketConfig>) {
    let config = await this.configRepository.findOne({ where: { tenantId } });
    if (!config) {
      config = this.configRepository.create({ ...data, tenantId });
    } else {
      Object.assign(config, data);
    }
    return this.configRepository.save(config);
  }

  async getProducts(tenantId: string, params: { page?: number; pageSize?: number }) {
    const { page = 1, pageSize = 20 } = params;
    const [data, total] = await this.productRepository.findAndCount({
      where: { tenantId },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });
    return { data, total, page, pageSize };
  }

  async getProduct(id: string, tenantId: string) {
    return this.productRepository.findOne({ where: { id, tenantId } });
  }

  async createProduct(tenantId: string, data: Partial<Product>) {
    const product = this.productRepository.create({ ...data, tenantId });
    return this.productRepository.save(product);
  }

  async updateProduct(id: string, tenantId: string, data: Partial<Product>) {
    await this.productRepository.update({ id, tenantId }, data);
    return this.getProduct(id, tenantId);
  }

  async deleteProduct(id: string, tenantId: string) {
    await this.productRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }

  async getKeywords(tenantId: string) {
    return this.keywordRepository.find({ where: { tenantId } });
  }

  async createKeyword(tenantId: string, data: Partial<Keyword>) {
    const keyword = this.keywordRepository.create({ ...data, tenantId });
    return this.keywordRepository.save(keyword);
  }

  async updateKeyword(id: string, tenantId: string, data: Partial<Keyword>) {
    await this.keywordRepository.update({ id, tenantId }, data);
    return this.keywordRepository.findOne({ where: { id, tenantId } });
  }

  async deleteKeyword(id: string, tenantId: string) {
    await this.keywordRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }

  async getCountries(tenantId: string) {
    const config = await this.configRepository.findOne({ where: { tenantId } });
    if (!config) return [];
    return this.countryRepository.find({ where: { configId: config.id } });
  }

  async createCountry(tenantId: string, data: Partial<TargetCountry>) {
    const config = await this.configRepository.findOne({ where: { tenantId } });
    if (!config) {
      throw new Error('市场配置不存在');
    }
    const country = this.countryRepository.create({ ...data, configId: config.id });
    return this.countryRepository.save(country);
  }

  async deleteCountry(id: string) {
    await this.countryRepository.delete(id);
    return { success: true, message: '删除成功' };
  }
}