import { Module } from '@nestjs/common';
import { MarketService } from './market.service';
import { MarketController } from './market.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MarketConfig } from '@/database/entities/MarketConfig.entity';
import { Product } from '@/database/entities/Product.entity';
import { Keyword } from '@/database/entities/Keyword.entity';
import { TargetCountry } from '@/database/entities/TargetCountry.entity';

@Module({
  imports: [TypeOrmModule.forFeature([MarketConfig, Product, Keyword, TargetCountry])],
  providers: [MarketService],
  controllers: [MarketController],
})
export class MarketModule {}