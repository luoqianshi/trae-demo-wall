import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MapSearchController } from './map-search.controller';
import { MapSearchService } from './map-search.service';
import { Lead } from '@/database/entities/Lead.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Lead])],
  controllers: [MapSearchController],
  providers: [MapSearchService],
})
export class MapSearchModule {}
