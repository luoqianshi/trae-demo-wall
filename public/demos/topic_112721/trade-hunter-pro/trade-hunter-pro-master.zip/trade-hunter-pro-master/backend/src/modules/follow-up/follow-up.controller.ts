import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { FollowUpService } from './follow-up.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { FollowUpRecord } from '@/database/entities/FollowUpRecord.entity';

@Controller('follow-up')
@ApiTags('跟进管理')
@UseGuards(JwtAuthGuard)
export class FollowUpController {
  constructor(private followUpService: FollowUpService) {}

  @Get('lead/:leadId')
  @ApiOperation({ summary: '获取线索跟进记录' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findByLead(@GetCurrentUser() user: User, @Param('leadId') leadId: string) {
    const result = await this.followUpService.findByLead(leadId, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post()
  @ApiOperation({ summary: '创建跟进记录' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async create(@GetCurrentUser() user: User, @Body() data: Partial<FollowUpRecord>) {
    const result = await this.followUpService.create(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put(':id')
  @ApiOperation({ summary: '更新跟进记录' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async update(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<FollowUpRecord>) {
    const result = await this.followUpService.update(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete(':id')
  @ApiOperation({ summary: '删除跟进记录' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async delete(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.followUpService.delete(id, user.tenantId);
  }
}