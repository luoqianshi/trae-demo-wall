import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, Index } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type LeadStatus = 'new' | 'verified' | 'qualified' | 'contacted' | 'converted' | 'rejected';
export type LeadGrade = 'A' | 'B' | 'C';

@Entity('leads')
@Index(['placeId', 'tenantId'])
export class Lead {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  companyName: string;

  @Column({ nullable: true })
  @ApiProperty()
  companyDomain: string;

  @Column({ nullable: true })
  @ApiProperty()
  email: string;

  @Column({ nullable: true })
  @ApiProperty()
  phone: string;

  @Column({ nullable: true })
  @ApiProperty()
  address: string;

  @Column({ nullable: true })
  @ApiProperty()
  website: string;

  @Column({ nullable: true })
  @ApiProperty()
  placeId: string;

  @Column('double', { nullable: true })
  @ApiProperty()
  latitude: number;

  @Column('double', { nullable: true })
  @ApiProperty()
  longitude: number;

  @Column({ nullable: true })
  @ApiProperty()
  googleRating: number;

  @Column({ default: 0 })
  @ApiProperty()
  googleReviewCount: number;

  @Column({ nullable: true })
  @ApiProperty()
  contactPerson: string;

  @Column({ nullable: true })
  @ApiProperty()
  contactTitle: string;

  @Column()
  @ApiProperty()
  source: string;

  @Column({ type: 'varchar', default: 'new' })
  @ApiProperty()
  status: LeadStatus;

  @Column({ default: 0 })
  @ApiProperty()
  score: number;

  @Column({ type: 'varchar', default: 'C' })
  @ApiProperty()
  grade: LeadGrade;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}