import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type EmailStatus = 'pending' | 'sent' | 'delivered' | 'opened' | 'clicked' | 'replied' | 'failed';

@Entity('email_records')
export class EmailRecord {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  campaignId: string;

  @Column()
  @ApiProperty()
  leadId: string;

  @Column()
  @ApiProperty()
  emailAccountId: string;

  @Column()
  @ApiProperty()
  subject: string;

  @Column('text')
  @ApiProperty()
  body: string;

  @Column({ nullable: true })
  @ApiProperty()
  sentAt: Date;

  @Column({ nullable: true })
  @ApiProperty()
  openedAt: Date;

  @Column({ nullable: true })
  @ApiProperty()
  clickedAt: Date;

  @Column({ nullable: true })
  @ApiProperty()
  repliedAt: Date;

  @Column({ type: 'varchar', default: 'pending' })
  @ApiProperty()
  status: EmailStatus;

  @Column()
  @ApiProperty()
  tenantId: string;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}