import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

@Entity('opportunities')
export class Opportunity {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  leadId: string;

  @Column()
  @ApiProperty()
  name: string;

  @Column({ default: '初步接触' })
  @ApiProperty()
  stage: string;

  @Column({ nullable: true, type: 'double' })
  @ApiProperty()
  amount: number;

  @Column({ nullable: true })
  @ApiProperty()
  probability: number;

  @Column({ nullable: true })
  @ApiProperty()
  expectedCloseDate: Date;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}