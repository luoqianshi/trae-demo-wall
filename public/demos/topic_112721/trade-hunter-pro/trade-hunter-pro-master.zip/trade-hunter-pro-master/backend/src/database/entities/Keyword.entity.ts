import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type KeywordType = 'include' | 'exclude';

@Entity('keywords')
export class Keyword {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  keyword: string;

  @Column({ type: 'varchar', default: 'include' })
  @ApiProperty()
  type: KeywordType;

  @Column({ default: 1 })
  @ApiProperty()
  weight: number;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}