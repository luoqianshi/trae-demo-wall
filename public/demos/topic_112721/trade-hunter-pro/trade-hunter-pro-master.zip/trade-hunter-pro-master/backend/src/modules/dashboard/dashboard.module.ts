import { Module } from '@nestjs/common';
import { DashboardService } from './dashboard.service';
import { DashboardController } from './dashboard.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Lead } from '@/database/entities/Lead.entity';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { Opportunity } from '@/database/entities/Opportunity.entity';
import { Task } from '@/database/entities/Task.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Lead, EmailCampaign, Opportunity, Task])],
  providers: [DashboardService],
  controllers: [DashboardController],
})
export class DashboardModule {}