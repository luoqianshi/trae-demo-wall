import { IsString, IsOptional, IsNumber, Min, Max } from 'class-validator';

export class SearchDto {
  @IsString()
  keyword: string;

  @IsString()
  location: string;

  @IsNumber()
  @Min(1000)
  @Max(50000)
  radius: number;

  @IsString()
  @IsOptional()
  type?: string;

  @IsString()
  @IsOptional()
  pageToken?: string;
}
