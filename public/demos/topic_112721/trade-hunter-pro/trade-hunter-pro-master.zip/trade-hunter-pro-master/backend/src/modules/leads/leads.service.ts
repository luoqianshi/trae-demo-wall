import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Lead } from '@/database/entities/Lead.entity';

@Injectable()
export class LeadsService {
  constructor(
    @InjectRepository(Lead) private leadRepository: Repository<Lead>,
  ) {}

  async findAll(tenantId: string, params: { page?: number; pageSize?: number; status?: string; grade?: string; keyword?: string }) {
    const { page = 1, pageSize = 20, status, grade, keyword } = params;
    const query = this.leadRepository.createQueryBuilder('lead')
      .where('lead.tenantId = :tenantId', { tenantId });

    if (status) {
      query.andWhere('lead.status = :status', { status });
    }

    if (grade) {
      query.andWhere('lead.grade = :grade', { grade });
    }

    if (keyword) {
      query.andWhere('(lead.companyName LIKE :keyword OR lead.email LIKE :keyword)', {
        keyword: `%${keyword}%`,
      });
    }

    const [data, total] = await query
      .skip((page - 1) * pageSize)
      .take(pageSize)
      .orderBy('lead.createdAt', 'DESC')
      .getManyAndCount();

    return { data, total, page, pageSize };
  }

  async export(tenantId: string, params: { status?: string }) {
    const { status } = params;
    const query = this.leadRepository.createQueryBuilder('lead')
      .where('lead.tenantId = :tenantId', { tenantId });

    if (status) {
      query.andWhere('lead.status = :status', { status });
    }

    const leads = await query.orderBy('lead.createdAt', 'DESC').getMany();
    return leads;
  }

  async findOne(id: string, tenantId: string) {
    return this.leadRepository.findOne({ where: { id, tenantId } });
  }

  async create(tenantId: string, data: Partial<Lead>) {
    const lead = this.leadRepository.create({ ...data, tenantId });
    return this.leadRepository.save(lead);
  }

  async update(id: string, tenantId: string, data: Partial<Lead>) {
    await this.leadRepository.update({ id, tenantId }, data);
    return this.findOne(id, tenantId);
  }

  async delete(id: string, tenantId: string) {
    await this.leadRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }
}