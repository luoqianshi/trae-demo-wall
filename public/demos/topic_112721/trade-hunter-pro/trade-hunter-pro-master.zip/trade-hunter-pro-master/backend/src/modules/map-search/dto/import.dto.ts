import { IsArray, IsString, ArrayMinSize } from 'class-validator';

export class ImportDto {
  @IsArray()
  @ArrayMinSize(1)
  @IsString({ each: true })
  placeIds: string[];
}
