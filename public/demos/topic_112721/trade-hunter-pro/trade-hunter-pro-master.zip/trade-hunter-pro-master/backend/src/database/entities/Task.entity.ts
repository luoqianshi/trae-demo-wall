import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type TaskType = 'mining' | 'cleaning' | 'email-sending';
export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed';
export type TaskPriority = 'low' | 'medium' | 'high';

@Entity('tasks')
export class Task {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column({ type: 'varchar' })
  @ApiProperty()
  type: TaskType;

  @Column()
  @ApiProperty()
  name: string;

  @Column({ type: 'varchar', default: 'pending' })
  @ApiProperty()
  status: TaskStatus;

  @Column({ type: 'varchar', default: 'medium' })
  @ApiProperty()
  priority: TaskPriority;

  @Column({ default: 0 })
  @ApiProperty()
  progress: number;

  @Column({ nullable: true })
  @ApiProperty()
  scheduledAt: Date;

  @Column({ nullable: true })
  @ApiProperty()
  startedAt: Date;

  @Column({ nullable: true })
  @ApiProperty()
  completedAt: Date;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}