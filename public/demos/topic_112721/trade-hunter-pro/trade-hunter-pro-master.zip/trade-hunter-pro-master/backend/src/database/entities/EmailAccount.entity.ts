import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type EncryptionType = 'ssl' | 'tls' | 'none';

@Entity('email_accounts')
export class EmailAccount {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  smtpHost: string;

  @Column()
  @ApiProperty()
  smtpPort: number;

  @Column()
  @ApiProperty()
  smtpUser: string;

  @Column()
  smtpPassword: string;

  @Column({ type: 'varchar', default: 'tls' })
  @ApiProperty()
  encryptionType: EncryptionType;

  @Column({ default: 100 })
  @ApiProperty()
  dailyLimit: number;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}