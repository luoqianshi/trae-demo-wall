import { Module } from '@nestjs/common';
import { EmailService } from './email.service';
import { EmailController } from './email.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { EmailTemplate } from '@/database/entities/EmailTemplate.entity';
import { EmailRecord } from '@/database/entities/EmailRecord.entity';

@Module({
  imports: [TypeOrmModule.forFeature([EmailCampaign, EmailTemplate, EmailRecord])],
  providers: [EmailService],
  controllers: [EmailController],
})
export class EmailModule {}