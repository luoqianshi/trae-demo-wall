import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type CampaignStatus = 'draft' | 'running' | 'completed';

@Entity('email_campaigns')
export class EmailCampaign {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @Column()
  @ApiProperty()
  name: string;

  @Column()
  @ApiProperty()
  templateId: string;

  @Column({ type: 'varchar', default: 'draft' })
  @ApiProperty()
  status: CampaignStatus;

  @Column({ default: 0 })
  @ApiProperty()
  sentCount: number;

  @Column({ default: 0 })
  @ApiProperty()
  openedCount: number;

  @Column({ default: 0 })
  @ApiProperty()
  clickedCount: number;

  @Column({ default: 0 })
  @ApiProperty()
  repliedCount: number;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}