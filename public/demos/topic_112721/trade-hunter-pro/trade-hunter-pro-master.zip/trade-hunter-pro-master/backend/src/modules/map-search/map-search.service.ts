import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Lead } from '@/database/entities/Lead.entity';
import { SearchDto } from './dto/search.dto';
import { ImportDto } from './dto/import.dto';

interface GeocodeResult {
  lat: number;
  lng: number;
}

export interface PlaceResult {
  placeId: string;
  name: string;
  address: string;
  phone?: string;
  website?: string;
  rating?: number;
  reviewCount?: number;
  latitude: number;
  longitude: number;
  types: string[];
}

@Injectable()
export class MapSearchService {
  private readonly geocodeCache = new Map<string, GeocodeResult>();

  constructor(
    private configService: ConfigService,
    @InjectRepository(Lead) private leadRepository: Repository<Lead>,
  ) {}

  private get apiKey(): string {
    return this.configService.get<string>('GOOGLE_PLACES_API_KEY') || '';
  }

  async geocode(location: string): Promise<GeocodeResult> {
    const cached = this.geocodeCache.get(location);
    if (cached) return cached;

    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(location)}&key=${this.apiKey}`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.status !== 'OK' || !data.results?.length) {
      throw new Error(`Geocoding failed: ${data.status || 'UNKNOWN_ERROR'}`);
    }

    const { lat, lng } = data.results[0].geometry.location;
    const result = { lat, lng };
    this.geocodeCache.set(location, result);
    return result;
  }

  async search(dto: SearchDto): Promise<{ results: PlaceResult[]; nextPageToken?: string }> {
    const { lat, lng } = await this.geocode(dto.location);

    const url = 'https://places.googleapis.com/v1/places:searchText';
    const body: Record<string, unknown> = {
      textQuery: dto.keyword,
      locationBias: {
        circle: {
          center: { latitude: lat, longitude: lng },
          radius: dto.radius,
        },
      },
      pageSize: 20,
    };

    if (dto.pageToken) {
      body.pageToken = dto.pageToken;
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': this.apiKey,
        'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.websiteUri,places.rating,places.userRatingCount,places.location,places.types,nextPageToken',
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Places API error: ${res.status} ${err}`);
    }

    const data = await res.json();

    const results: PlaceResult[] = (data.places || []).map((p: any) => ({
      placeId: p.id,
      name: p.displayName?.text || '',
      address: p.formattedAddress || '',
      phone: p.nationalPhoneNumber,
      website: p.websiteUri,
      rating: p.rating,
      reviewCount: p.userRatingCount,
      latitude: p.location?.latitude,
      longitude: p.location?.longitude,
      types: p.types || [],
    }));

    return { results, nextPageToken: data.nextPageToken };
  }

  async importPlaces(dto: ImportDto, tenantId: string) {
    // Fetch full details for each placeId to ensure data completeness
    const results = { imported: 0, failed: 0, duplicates: 0 };

    for (const placeId of dto.placeIds) {
      try {
        const place = await this.getPlaceDetails(placeId);
        if (!place) {
          results.failed++;
          continue;
        }

        // Check duplicate by placeId
        let exists = await this.leadRepository.findOne({
          where: { placeId, tenantId },
        });
        if (exists) {
          results.duplicates++;
          continue;
        }

        // Check duplicate by companyName + address
        exists = await this.leadRepository.findOne({
          where: { companyName: place.name, address: place.address, tenantId },
        });
        if (exists) {
          results.duplicates++;
          continue;
        }

        const { score, grade } = this.calcScoreAndGrade(place.rating);

        const lead = this.leadRepository.create({
          tenantId,
          companyName: place.name,
          address: place.address,
          phone: place.phone,
          website: place.website,
          companyDomain: this.extractDomain(place.website),
          placeId: place.placeId,
          latitude: place.latitude,
          longitude: place.longitude,
          googleRating: place.rating,
          googleReviewCount: place.reviewCount,
          source: 'google_maps',
          status: 'new',
          score,
          grade,
        });

        await this.leadRepository.save(lead);
        results.imported++;
      } catch {
        results.failed++;
      }
    }

    return results;
  }

  private async getPlaceDetails(placeId: string): Promise<PlaceResult | null> {
    const url = `https://places.googleapis.com/v1/places/${placeId}`;
    const res = await fetch(url, {
      headers: {
        'X-Goog-Api-Key': this.apiKey,
        'X-Goog-FieldMask': 'id,displayName,formattedAddress,nationalPhoneNumber,websiteUri,rating,userRatingCount,location,types',
      },
    });

    if (!res.ok) return null;

    const p = await res.json();
    return {
      placeId: p.id,
      name: p.displayName?.text || '',
      address: p.formattedAddress || '',
      phone: p.nationalPhoneNumber,
      website: p.websiteUri,
      rating: p.rating,
      reviewCount: p.userRatingCount,
      latitude: p.location?.latitude,
      longitude: p.location?.longitude,
      types: p.types || [],
    };
  }

  private extractDomain(url?: string): string | undefined {
    if (!url) return undefined;
    try {
      const hostname = new URL(url).hostname;
      return hostname.replace(/^www\./, '');
    } catch {
      return undefined;
    }
  }

  private calcScoreAndGrade(rating?: number): { score: number; grade: 'A' | 'B' | 'C' } {
    if (rating === undefined || rating === null) {
      return { score: 50, grade: 'C' };
    }
    if (rating >= 4.5) {
      return { score: Math.min(100, Math.round(85 + (rating - 4.5) * 30)), grade: 'A' };
    }
    if (rating >= 4.0) {
      return { score: Math.min(84, Math.round(70 + (rating - 4.0) * 28)), grade: 'B' };
    }
    return { score: Math.max(30, Math.round(50 + (rating - 3.0) * 20)), grade: 'C' };
  }
}
