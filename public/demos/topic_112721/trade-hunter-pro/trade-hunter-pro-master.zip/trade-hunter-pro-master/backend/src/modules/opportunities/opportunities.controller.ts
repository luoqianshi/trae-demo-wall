import { Controller, Get, Post, Put, Delete, Query, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { OpportunitiesService } from './opportunities.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { Opportunity } from '@/database/entities/Opportunity.entity';

@Controller('opportunities')
@ApiTags('商机管理')
@UseGuards(JwtAuthGuard)
export class OpportunitiesController {
  constructor(private opportunitiesService: OpportunitiesService) {}

  @Get()
  @ApiOperation({ summary: '获取商机列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findAll(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number; stage?: string },
  ) {
    const result = await this.opportunitiesService.findAll(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }

  @Get(':id')
  @ApiOperation({ summary: '获取商机详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async findOne(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.opportunitiesService.findOne(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post()
  @ApiOperation({ summary: '创建商机' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async create(@GetCurrentUser() user: User, @Body() data: Partial<Opportunity>) {
    const result = await this.opportunitiesService.create(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put(':id')
  @ApiOperation({ summary: '更新商机' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async update(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<Opportunity>) {
    const result = await this.opportunitiesService.update(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete(':id')
  @ApiOperation({ summary: '删除商机' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async delete(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.opportunitiesService.delete(id, user.tenantId);
  }
}