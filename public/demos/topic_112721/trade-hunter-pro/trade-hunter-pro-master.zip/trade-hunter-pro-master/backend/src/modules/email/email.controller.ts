import { Controller, Get, Post, Put, Delete, Query, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { EmailService } from './email.service';
import { JwtAuthGuard } from '@/shared/guards/JwtAuth.guard';
import { GetCurrentUser } from '@/shared/decorators/GetCurrentUser.decorator';
import { User } from '@/database/entities/User.entity';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { EmailTemplate } from '@/database/entities/EmailTemplate.entity';

@Controller('email')
@ApiTags('邮件营销')
@UseGuards(JwtAuthGuard)
export class EmailController {
  constructor(private emailService: EmailService) {}

  @Get('campaigns')
  @ApiOperation({ summary: '获取邮件营销活动列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getCampaigns(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number; status?: string },
  ) {
    const result = await this.emailService.getCampaigns(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('campaigns/:id')
  @ApiOperation({ summary: '获取邮件营销活动详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getCampaign(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.emailService.getCampaign(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post('campaigns')
  @ApiOperation({ summary: '创建邮件营销活动' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async createCampaign(@GetCurrentUser() user: User, @Body() data: Partial<EmailCampaign>) {
    const result = await this.emailService.createCampaign(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put('campaigns/:id')
  @ApiOperation({ summary: '更新邮件营销活动' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateCampaign(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<EmailCampaign>) {
    const result = await this.emailService.updateCampaign(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete('campaigns/:id')
  @ApiOperation({ summary: '删除邮件营销活动' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async deleteCampaign(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.emailService.deleteCampaign(id, user.tenantId);
  }

  @Get('templates')
  @ApiOperation({ summary: '获取邮件模板列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getTemplates(@GetCurrentUser() user: User) {
    const result = await this.emailService.getTemplates(user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Get('templates/:id')
  @ApiOperation({ summary: '获取邮件模板详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getTemplate(@GetCurrentUser() user: User, @Param('id') id: string) {
    const result = await this.emailService.getTemplate(id, user.tenantId);
    return { success: true, message: '获取成功', data: result };
  }

  @Post('templates')
  @ApiOperation({ summary: '创建邮件模板' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async createTemplate(@GetCurrentUser() user: User, @Body() data: Partial<EmailTemplate>) {
    const result = await this.emailService.createTemplate(user.tenantId, data);
    return { success: true, message: '创建成功', data: result };
  }

  @Put('templates/:id')
  @ApiOperation({ summary: '更新邮件模板' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateTemplate(@GetCurrentUser() user: User, @Param('id') id: string, @Body() data: Partial<EmailTemplate>) {
    const result = await this.emailService.updateTemplate(id, user.tenantId, data);
    return { success: true, message: '更新成功', data: result };
  }

  @Delete('templates/:id')
  @ApiOperation({ summary: '删除邮件模板' })
  @ApiResponse({ status: 200, description: '删除成功' })
  async deleteTemplate(@GetCurrentUser() user: User, @Param('id') id: string) {
    return this.emailService.deleteTemplate(id, user.tenantId);
  }

  @Get('sent')
  @ApiOperation({ summary: '获取发送记录列表' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getSentEmails(
    @GetCurrentUser() user: User,
    @Query() params: { page?: number; pageSize?: number },
  ) {
    const result = await this.emailService.getSentEmails(user.tenantId, params);
    return { success: true, message: '获取成功', data: result };
  }
}