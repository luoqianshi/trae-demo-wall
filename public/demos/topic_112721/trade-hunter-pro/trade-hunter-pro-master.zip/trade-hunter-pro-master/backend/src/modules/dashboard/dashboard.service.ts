import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { Lead } from '@/database/entities/Lead.entity';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { Opportunity } from '@/database/entities/Opportunity.entity';
import { Task } from '@/database/entities/Task.entity';

@Injectable()
export class DashboardService {
  constructor(
    @InjectRepository(Lead) private leadRepository: Repository<Lead>,
    @InjectRepository(EmailCampaign) private campaignRepository: Repository<EmailCampaign>,
    @InjectRepository(Opportunity) private opportunityRepository: Repository<Opportunity>,
    @InjectRepository(Task) private taskRepository: Repository<Task>,
  ) {}

  async getOverview(tenantId: string) {
    const [totalLeads, newLeadsToday] = await Promise.all([
      this.leadRepository.count({ where: { tenantId } }),
      this.leadRepository.count({ where: { tenantId, status: 'new' } }),
    ]);

    const campaigns = await this.campaignRepository.find({ where: { tenantId } });
    const emailsSent = campaigns.reduce((sum, c) => sum + (c.sentCount || 0), 0);
    const totalOpens = campaigns.reduce((sum, c) => sum + (c.openedCount || 0), 0);
    const totalReplies = campaigns.reduce((sum, c) => sum + (c.repliedCount || 0), 0);
    const openRate = emailsSent > 0 ? Math.round((totalOpens / emailsSent) * 100) : 0;
    const replyRate = emailsSent > 0 ? Math.round((totalReplies / emailsSent) * 100) : 0;

    const recentLeads = await this.leadRepository.find({
      where: { tenantId },
      order: { createdAt: 'DESC' },
      take: 5,
    });

    const recentCampaigns = await this.campaignRepository.find({
      where: { tenantId },
      order: { createdAt: 'DESC' },
      take: 5,
    });

    return {
      totalLeads,
      newLeadsToday,
      emailsSent,
      openRate,
      replyRate,
      conversionRate: 0,
      recentLeads,
      recentCampaigns,
    };
  }

  async getLeadTrend(tenantId: string, days: number = 7) {
    const dateRange = Array.from({ length: days }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (days - 1 - i));
      return date.toISOString().split('T')[0];
    });

    const results = await Promise.all(
      dateRange.map(date =>
        this.leadRepository.count({
          where: {
            tenantId,
            createdAt: Between(new Date(`${date}T00:00:00`), new Date(`${date}T23:59:59`)),
          },
        }),
      ),
    );

    return dateRange.map((date, idx) => ({ date, count: results[idx] }));
  }

  async getCampaignStats(tenantId: string) {
    return this.campaignRepository.createQueryBuilder('campaign')
      .where('campaign.tenantId = :tenantId', { tenantId })
      .select('campaign.status', 'status')
      .addSelect('COUNT(*)', 'count')
      .groupBy('campaign.status')
      .getRawMany();
  }
}