import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';

export type FollowUpType = 'call' | 'email' | 'meeting' | 'note';

@Entity('follow_up_records')
export class FollowUpRecord {
  @PrimaryGeneratedColumn('uuid')
  @ApiProperty()
  id: string;

  @Column()
  @ApiProperty()
  leadId: string;

  @Column({ type: 'varchar' })
  @ApiProperty()
  type: FollowUpType;

  @Column('text')
  @ApiProperty()
  content: string;

  @Column({ nullable: true })
  @ApiProperty()
  result: string;

  @Column()
  @ApiProperty()
  createdBy: string;

  @Column()
  @ApiProperty()
  tenantId: string;

  @CreateDateColumn()
  @ApiProperty()
  createdAt: Date;

  @UpdateDateColumn()
  @ApiProperty()
  updatedAt: Date;
}