import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import configuration from '@/config/configuration';
import { AuthModule } from '@/modules/auth/auth.module';
import { LeadsModule } from '@/modules/leads/leads.module';
import { MarketModule } from '@/modules/market/market.module';
import { TasksModule } from '@/modules/tasks/tasks.module';
import { EmailModule } from '@/modules/email/email.module';
import { DashboardModule } from '@/modules/dashboard/dashboard.module';
import { OpportunitiesModule } from '@/modules/opportunities/opportunities.module';
import { FollowUpModule } from '@/modules/follow-up/follow-up.module';
import { MapSearchModule } from '@/modules/map-search/map-search.module';
import { User } from '@/database/entities/User.entity';
import { Tenant } from '@/database/entities/Tenant.entity';
import { Lead } from '@/database/entities/Lead.entity';
import { EmailCampaign } from '@/database/entities/EmailCampaign.entity';
import { EmailTemplate } from '@/database/entities/EmailTemplate.entity';
import { EmailRecord } from '@/database/entities/EmailRecord.entity';
import { Opportunity } from '@/database/entities/Opportunity.entity';
import { FollowUpRecord } from '@/database/entities/FollowUpRecord.entity';
import { Task } from '@/database/entities/Task.entity';
import { MarketConfig } from '@/database/entities/MarketConfig.entity';
import { Product } from '@/database/entities/Product.entity';
import { Keyword } from '@/database/entities/Keyword.entity';
import { TargetCountry } from '@/database/entities/TargetCountry.entity';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
      load: [configuration],
    }),
    TypeOrmModule.forRoot({
      type: 'better-sqlite3',
      database: './data/db.sqlite',
      entities: [
        User,
        Tenant,
        Lead,
        EmailCampaign,
        EmailTemplate,
        EmailRecord,
        Opportunity,
        FollowUpRecord,
        Task,
        MarketConfig,
        Product,
        Keyword,
        TargetCountry,
      ],
      synchronize: true,
      logging: false,
    }),
    AuthModule,
    LeadsModule,
    MarketModule,
    TasksModule,
    EmailModule,
    DashboardModule,
    OpportunitiesModule,
    FollowUpModule,
    MapSearchModule,
  ],
})
export class AppModule {}