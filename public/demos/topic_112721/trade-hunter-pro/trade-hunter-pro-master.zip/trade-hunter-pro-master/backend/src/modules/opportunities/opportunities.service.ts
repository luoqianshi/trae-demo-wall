import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Opportunity } from '@/database/entities/Opportunity.entity';

@Injectable()
export class OpportunitiesService {
  constructor(
    @InjectRepository(Opportunity) private opportunityRepository: Repository<Opportunity>,
  ) {}

  async findAll(tenantId: string, params: { page?: number; pageSize?: number; stage?: string }) {
    const { page = 1, pageSize = 20, stage } = params;
    const query = this.opportunityRepository.createQueryBuilder('opp')
      .where('opp.tenantId = :tenantId', { tenantId });

    if (stage) {
      query.andWhere('opp.stage = :stage', { stage });
    }

    const [data, total] = await query
      .skip((page - 1) * pageSize)
      .take(pageSize)
      .orderBy('opp.createdAt', 'DESC')
      .getManyAndCount();

    return { data, total, page, pageSize };
  }

  async findOne(id: string, tenantId: string) {
    return this.opportunityRepository.findOne({ where: { id, tenantId } });
  }

  async create(tenantId: string, data: Partial<Opportunity>) {
    const opp = this.opportunityRepository.create({ ...data, tenantId });
    return this.opportunityRepository.save(opp);
  }

  async update(id: string, tenantId: string, data: Partial<Opportunity>) {
    await this.opportunityRepository.update({ id, tenantId }, data);
    return this.findOne(id, tenantId);
  }

  async delete(id: string, tenantId: string) {
    await this.opportunityRepository.delete({ id, tenantId });
    return { success: true, message: '删除成功' };
  }
}