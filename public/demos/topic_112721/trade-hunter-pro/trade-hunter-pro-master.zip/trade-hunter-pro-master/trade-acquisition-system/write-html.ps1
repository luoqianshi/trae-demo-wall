$html = @'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TradeHunter Pro - 外贸智能获客系统</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #f4f6fb;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-card-hover: #f8f9fc;
            --bg-input: #f0f2f8;
            --bg-input-focus: #ebedf5;
            --border: #e2e5ef;
            --border-focus: #1e40af;
            --border-hover: #cdd1de;
            --text-primary: #1a1d2e;
            --text-secondary: #5a6078;
            --text-muted: #8e93a8;
            --text-placeholder: #b0b5c5;
            --accent-primary: #1e40af;
            --accent-primary-dim: rgba(30,64,175,0.08);
            --accent-primary-glow: rgba(30,64,175,0.12);
            --accent-gold: #b8860b;
            --accent-gold-bright: #d4a843;
            --accent-gold-dim: rgba(184,134,11,0.10);
            --accent-gold-glow: rgba(184,134,11,0.20);
            --accent-emerald: #059669;
            --accent-emerald-dim: rgba(5,150,105,0.08);
            --accent-amber: #b8860b;
            --accent-amber-dim: rgba(184,134,11,0.10);
            --accent-rose: #dc2651;
            --accent-rose-dim: rgba(220,38,81,0.08);
            --accent-violet: #7c3aed;
            --accent-violet-dim: rgba(124,58,237,0.08);
            --accent-cyan: #0891b2;
            --accent-cyan-dim: rgba(8,145,178,0.08);
            --sidebar-width: 260px;
            --header-height: 64px;
            --radius-sm: 10px;
            --radius-md: 14px;
            --radius-lg: 18px;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.03);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.06), 0 1px 4px rgba(0,0,0,0.04);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.04);
            --shadow-card: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.03);
            --shadow-gold: 0 4px 20px rgba(184,134,11,0.15);
            --transition-fast: 0.15s cubic-bezier(0.4,0,0.2,1);
            --transition-base: 0.25s cubic-bezier(0.4,0,0.2,1);
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif; background: var(--bg-primary); color: var(--text-primary); line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; left: 0; top: 0; bottom: 0; width: var(--sidebar-width); background: var(--bg-secondary); border-right: 1px solid var(--border); display: flex; flex-direction: column; z-index: 100; box-shadow: var(--shadow-sm); }
        .sidebar-brand { padding: 20px 24px; display: flex; align-items: center; gap: 14px; border-bottom: 1px solid var(--border); }
        .sidebar-brand .logo-icon { width: 42px; height: 42px; background: linear-gradient(135deg, var(--accent-primary), #3b82f6); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 800; font-size: 16px; letter-spacing: 1px; box-shadow: 0 4px 12px rgba(30,64,175,0.25); }
        .sidebar-brand .brand-text h1 { font-family: 'Playfair Display', serif; font-size: 18px; font-weight: 700; color: var(--text-primary); line-height: 1.2; }
        .sidebar-brand .brand-text p { font-size: 11px; color: var(--text-muted); font-weight: 500; letter-spacing: 0.3px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; display: flex; flex-direction: column; gap: 4px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 11px 16px; border-radius: var(--radius-sm); cursor: pointer; transition: all var(--transition-fast); color: var(--text-secondary); font-size: 14px; font-weight: 500; position: relative; }
        .nav-item:hover { background: var(--bg-primary); color: var(--text-primary); }
        .nav-item.active { background: var(--accent-primary-dim); color: var(--accent-primary); font-weight: 600; }
        .nav-item.active::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 3px; height: 24px; border-radius: 0 3px 3px 0; background: var(--accent-primary); }
        .nav-item svg { width: 20px; height: 20px; flex-shrink: 0; }
        .nav-badge { margin-left: auto; background: var(--accent-rose); color: #fff; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 10px; min-width: 22px; text-align: center; }
        .sidebar-footer { padding: 16px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; gap: 12px; }
        .sidebar-footer .avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, var(--accent-gold), var(--accent-gold-bright)); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 14px; box-shadow: var(--shadow-gold); }
        .sidebar-footer .user-info h4 { font-size: 13px; font-weight: 600; color: var(--text-primary); }
        .sidebar-footer .user-info p { font-size: 11px; color: var(--text-muted); }
        .main { margin-left: var(--sidebar-width); min-height: 100vh; }
        .header { height: var(--header-height); background: var(--bg-secondary); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; position: sticky; top: 0; z-index: 50; box-shadow: var(--shadow-sm); }
        .header h2 { font-family: 'Playfair Display', serif; font-size: 20px; font-weight: 700; }
        .header-right { display: flex; align-items: center; gap: 16px; }
        .header-right .status-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary); }
        .status-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent-emerald); animation: pulse 2s infinite; }
        .header-right .btn-icon { width: 38px; height: 38px; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg-secondary); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all var(--transition-fast); color: var(--text-secondary); }
        .header-right .btn-icon:hover { border-color: var(--border-hover); color: var(--text-primary); }
        .content { padding: 28px 32px; }
        .page { display: none; }
        .page.active { display: block; animation: pageIn 0.35s ease; }
        .stat-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: var(--bg-card); border-radius: var(--radius-md); padding: 22px 24px; border: 1px solid var(--border); box-shadow: var(--shadow-card); transition: all var(--transition-base); display: flex; align-items: flex-start; justify-content: space-between; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .stat-card .stat-label { font-size: 13px; color: var(--text-muted); font-weight: 500; margin-bottom: 6px; }
        .stat-card .stat-value { font-family: 'Playfair Display', serif; font-size: 28px; font-weight: 700; color: var(--text-primary); }
        .stat-card .stat-change { font-size: 12px; margin-top: 4px; font-weight: 500; }
        .stat-change.positive { color: var(--accent-emerald); }
        .stat-change.negative { color: var(--accent-rose); }
        .stat-icon { width: 44px; height: 44px; border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .stat-icon svg { width: 22px; height: 22px; }
        .panel { background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border); box-shadow: var(--shadow-card); margin-bottom: 24px; overflow: hidden; }
        .panel-header { padding: 18px 24px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .panel-header h3 { font-size: 15px; font-weight: 700; color: var(--text-primary); display: flex; align-items: center; gap: 8px; }
        .panel-header h3 svg { width: 18px; height: 18px; color: var(--accent-primary); }
        .panel-body { padding: 24px; }
        .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-label { display: block; font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 8px; }
        .form-input, .form-select, .form-textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--bg-input); color: var(--text-primary); font-family: inherit; font-size: 13.5px; transition: all var(--transition-fast); outline: none; }
        .form-input:focus, .form-select:focus, .form-textarea:focus { border-color: var(--border-focus); background: var(--bg-input-focus); box-shadow: 0 0 0 3px var(--accent-primary-glow); }
        .form-input::placeholder, .form-textarea::placeholder { color: var(--text-placeholder); }
        .form-textarea { resize: vertical; min-height: 80px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 8px; padding: 8px 12px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--bg-input); min-height: 44px; align-items: center; cursor: text; transition: all var(--transition-fast); }
        .tag-container:focus-within { border-color: var(--border-focus); background: var(--bg-input-focus); box-shadow: 0 0 0 3px var(--accent-primary-glow); }
        .tag-item { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 20px; font-size: 12.5px; font-weight: 600; animation: tagIn 0.2s ease; }
        .tag-item .tag-remove { cursor: pointer; opacity: 0.6; transition: opacity var(--transition-fast); display: flex; align-items: center; }
        .tag-item .tag-remove:hover { opacity: 1; }
        .tag-item .tag-remove svg { width: 12px; height: 12px; }
        .tag-blue { background: var(--accent-primary-dim); color: var(--accent-primary); }
        .tag-gold { background: var(--accent-gold-dim); color: var(--accent-gold); }
        .tag-emerald { background: var(--accent-emerald-dim); color: var(--accent-emerald); }
        .tag-violet { background: var(--accent-violet-dim); color: var(--accent-violet); }
        .tag-rose { background: var(--accent-rose-dim); color: var(--accent-rose); }
        .tag-cyan { background: var(--accent-cyan-dim); color: var(--accent-cyan); }
        .tag-input-inline { border: none; background: transparent; outline: none; font-size: 13px; color: var(--text-primary); font-family: inherit; min-width: 100px; flex: 1; }
        .tag-input-inline::placeholder { color: var(--text-placeholder); }
        .product-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 16px; }
        .product-card { background: var(--bg-primary); border-radius: var(--radius-sm); padding: 16px; border: 1px solid var(--border); transition: all var(--transition-base); }
        .product-card:hover { border-color: var(--border-hover); box-shadow: var(--shadow-sm); }
        .product-card .product-name { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
        .product-card .product-category { font-size: 12px; color: var(--text-muted); margin-bottom: 8px; }
        .product-card .product-price { font-family: 'JetBrains Mono', monospace; font-size: 13px; font-weight: 600; color: var(--accent-primary); }
        .product-card .product-price span { font-size: 11px; color: var(--text-muted); font-weight: 400; }
        .btn-add { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 16px; border: 2px dashed var(--border); border-radius: var(--radius-sm); background: transparent; cursor: pointer; transition: all var(--transition-fast); color: var(--text-muted); font-size: 13px; font-weight: 500; }
        .btn-add:hover { border-color: var(--accent-primary); color: var(--accent-primary); background: var(--accent-primary-dim); }
        .btn-add svg { width: 18px; height: 18px; }
        .toggle-group { display: flex; flex-direction: column; gap: 16px; }
        .toggle-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border); }
        .toggle-item:last-child { border-bottom: none; }
        .toggle-item .toggle-label { font-size: 13.5px; font-weight: 500; }
        .toggle-item .toggle-desc { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
        .toggle-switch { position: relative; width: 44px; height: 24px; flex-shrink: 0; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider { position: absolute; inset: 0; background: var(--border); border-radius: 12px; cursor: pointer; transition: all var(--transition-fast); }
        .toggle-slider::before { content: ''; position: absolute; left: 3px; bottom: 3px; width: 18px; height: 18px; background: #fff; border-radius: 50%; transition: all var(--transition-fast); box-shadow: 0 1px 3px rgba(0,0,0,0.15); }
        .toggle-switch input:checked + .toggle-slider { background: var(--accent-primary); }
        .toggle-switch input:checked + .toggle-slider::before { transform: translateX(20px); }
        .week-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px; }
        .week-btn { padding: 8px; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg-input); font-size: 12px; font-weight: 600; color: var(--text-secondary); cursor: pointer; transition: all var(--transition-fast); text-align: center; }
        .week-btn.active { background: var(--accent-primary); color: #fff; border-color: var(--accent-primary); box-shadow: 0 2px 8px rgba(30,64,175,0.25); }
        .week-btn:not(.active):hover { border-color: var(--border-hover); }
        .template-editor { border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--bg-input); min-height: 140px; padding: 14px; font-size: 13.5px; line-height: 1.7; outline: none; transition: all var(--transition-fast); }
        .template-editor:focus { border-color: var(--border-focus); background: var(--bg-input-focus); box-shadow: 0 0 0 3px var(--accent-primary-glow); }
        .template-editor .var-highlight { background: var(--accent-gold-dim); color: var(--accent-gold); padding: 1px 6px; border-radius: 4px; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
        .checkbox-group { display: flex; flex-direction: column; gap: 10px; }
        .checkbox-item { display: flex; align-items: center; gap: 10px; font-size: 13.5px; color: var(--text-secondary); cursor: pointer; }
        .checkbox-item input[type="checkbox"] { width: 16px; height: 16px; accent-color: var(--accent-primary); cursor: pointer; }
        .toolbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; gap: 16px; flex-wrap: wrap; }
        .tab-bar { display: flex; gap: 4px; }
        .tab-btn { padding: 8px 16px; border-radius: var(--radius-sm); border: 1px solid transparent; background: transparent; font-size: 13px; font-weight: 500; color: var(--text-secondary); cursor: pointer; transition: all var(--transition-fast); display: flex; align-items: center; gap: 6px; }
        .tab-btn:hover { background: var(--bg-input); }
        .tab-btn.active { background: var(--accent-primary-dim); color: var(--accent-primary); border-color: var(--accent-primary); font-weight: 600; }
        .tab-btn .tab-count { font-size: 11px; background: var(--bg-input); padding: 1px 6px; border-radius: 8px; font-weight: 600; }
        .tab-btn.active .tab-count { background: rgba(30,64,175,0.15); }
        .toolbar-right { display: flex; gap: 10px; align-items: center; }
        .search-box { display: flex; align-items: center; gap: 8px; padding: 8px 14px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--bg-input); transition: all var(--transition-fast); }
        .search-box:focus-within { border-color: var(--border-focus); box-shadow: 0 0 0 3px var(--accent-primary-glow); }
        .search-box svg { width: 16px; height: 16px; color: var(--text-muted); flex-shrink: 0; }
        .search-box input { border: none; background: transparent; outline: none; font-size: 13px; color: var(--text-primary); font-family: inherit; width: 180px; }
        .search-box input::placeholder { color: var(--text-placeholder); }
        .btn { padding: 8px 18px; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg-secondary); font-size: 13px; font-weight: 600; color: var(--text-primary); cursor: pointer; transition: all var(--transition-fast); display: inline-flex; align-items: center; gap: 6px; font-family: inherit; }
        .btn:hover { border-color: var(--border-hover); box-shadow: var(--shadow-sm); }
        .btn svg { width: 16px; height: 16px; }
        .btn-primary { background: var(--accent-primary); color: #fff; border-color: var(--accent-primary); }
        .btn-primary:hover { background: #1a38a0; box-shadow: 0 4px 12px rgba(30,64,175,0.3); }
        .btn-gold { background: var(--accent-gold); color: #fff; border-color: var(--accent-gold); }
        .btn-gold:hover { background: #a07708; box-shadow: var(--shadow-gold); }
        .data-table-wrap { overflow-x: auto; border: 1px solid var(--border); border-radius: var(--radius-md); background: var(--bg-card); }
        .data-table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
        .data-table thead { background: var(--bg-primary); }
        .data-table th { padding: 12px 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid var(--border); white-space: nowrap; }
        .data-table td { padding: 12px 16px; border-bottom: 1px solid var(--border); color: var(--text-primary); white-space: nowrap; }
        .data-table tbody tr { transition: background var(--transition-fast); }
        .data-table tbody tr:hover { background: var(--bg-card-hover); }
        .data-table tbody tr:last-child td { border-bottom: none; }
        .data-table input[type="checkbox"] { width: 16px; height: 16px; accent-color: var(--accent-primary); cursor: pointer; }
        .country-cell { display: flex; align-items: center; gap: 8px; }
        .country-flag { width: 24px; height: 16px; border-radius: 2px; object-fit: cover; border: 1px solid var(--border); }
        .status-badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
        .status-sent { background: var(--accent-cyan-dim); color: var(--accent-cyan); }
        .status-sent .dot { background: var(--accent-cyan); }
        .status-opened { background: var(--accent-violet-dim); color: var(--accent-violet); }
        .status-opened .dot { background: var(--accent-violet); }
        .status-replied { background: var(--accent-emerald-dim); color: var(--accent-emerald); }
        .status-replied .dot { background: var(--accent-emerald); }
        .status-pending { background: var(--accent-amber-dim); color: var(--accent-amber); }
        .status-pending .dot { background: var(--accent-amber); }
        .action-btns { display: flex; gap: 6px; }
        .action-btn { width: 30px; height: 30px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all var(--transition-fast); color: var(--text-muted); }
        .action-btn:hover { border-color: var(--accent-primary); color: var(--accent-primary); background: var(--accent-primary-dim); }
        .action-btn svg { width: 14px; height: 14px; }
        .pagination { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; }
        .pagination .page-info { font-size: 13px; color: var(--text-muted); }
        .pagination .page-btns { display: flex; gap: 4px; }
        .page-btn { width: 34px; height: 34px; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg-secondary); font-size: 13px; font-weight: 500; color: var(--text-secondary); cursor: pointer; transition: all var(--transition-fast); display: flex; align-items: center; justify-content: center; }
        .page-btn:hover { border-color: var(--accent-primary); color: var(--accent-primary); }
        .page-btn.active { background: var(--accent-primary); color: #fff; border-color: var(--accent-primary); }
        .page-btn:disabled { opacity: 0.4; cursor: not-allowed; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); backdrop-filter: blur(4px); z-index: 200; display: none; align-items: center; justify-content: center; }
        .modal-overlay.active { display: flex; animation: fadeIn 0.2s ease; }
        .modal { background: var(--bg-card); border-radius: var(--radius-lg); width: 520px; max-width: 90vw; max-height: 85vh; overflow-y: auto; box-shadow: var(--shadow-lg); animation: modalIn 0.3s ease; }
        .modal-header { padding: 20px 24px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .modal-header h3 { font-size: 17px; font-weight: 700; }
        .modal-close { width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg-secondary); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all var(--transition-fast); color: var(--text-muted); }
        .modal-close:hover { border-color: var(--accent-rose); color: var(--accent-rose); background: var(--accent-rose-dim); }
        .modal-close svg { width: 16px; height: 16px; }
        .modal-body { padding: 24px; }
        .modal-footer { padding: 16px 24px; border-top: 1px solid var(--border); display: flex; gap: 10px; justify-content: flex-end; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes pageIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.95) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes tagIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
        @keyframes pulse { 0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(5,150,105,0.4); } 50% { opacity: 0.8; box-shadow: 0 0 0 6px rgba(5,150,105,0); } }
        @media (max-width: 1200px) { .stat-row { grid-template-columns: repeat(3, 1fr); } .product-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 900px) { .sidebar { width: 0; overflow: hidden; } .main { margin-left: 0; } .stat-row { grid-template-columns: repeat(2, 1fr); } .two-col { grid-template-columns: 1fr; } .product-grid { grid-template-columns: 1fr; } .form-row { grid-template-columns: 1fr; } }
        ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; } ::-webkit-scrollbar-thumb:hover { background: var(--text-muted); }
    </style>
</head>
<body>
<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-icon">TH</div>
        <div class="brand-text"><h1>TradeHunter</h1><p>外贸智能获客系统</p></div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-item active" onclick="switchPage('config', this)" data-page="config"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg><span>用户配置</span></div>
        <div class="nav-item" onclick="switchPage('task', this)" data-page="task"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/></svg><span>任务配置</span><span class="nav-badge">3</span></div>
        <div class="nav-item" onclick="switchPage('leads', this)" data-page="leads"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg><span>客户线索</span></div>
    </nav>
    <div class="sidebar-footer"><div class="avatar">WW</div><div class="user-info"><h4>Wang Wei</h4><p>外贸经理</p></div></div>
</aside>
<div class="main">
    <header class="header">
        <h2 id="pageTitle">用户配置</h2>
        <div class="header-right">
            <div class="status-indicator" id="statusIndicator" style="display:none;"><div class="status-dot"></div><span>任务运行中</span></div>
            <button class="btn-icon" title="通知"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></button>
            <button class="btn-icon" title="设置"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
        </div>
    </header>
    <div class="content">
        <!-- PAGE 1: User Config -->
        <div class="page active" id="page-config">
            <div class="stat-row">
                <div class="stat-card" style="animation: slideUp 0.4s ease"><div><div class="stat-label">配置产品数</div><div class="stat-value">12</div><div class="stat-change positive">+3 本月新增</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.45s ease"><div><div class="stat-label">目标市场</div><div class="stat-value">8</div><div class="stat-change positive">覆盖欧洲5国</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.5s ease"><div><div class="stat-label">产品品类</div><div class="stat-value">5</div><div class="stat-change positive">音频/充电/穿戴</div></div><div class="stat-icon" style="background:var(--accent-violet-dim);color:var(--accent-violet);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h10"/><line x1="18" y1="13" x2="18" y2="21"/><line x1="15" y1="17" x2="21" y2="17"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.55s ease"><div><div class="stat-label">配置完整度</div><div class="stat-value">86%</div><div class="stat-change" style="color:var(--accent-gold);">建议完善邮箱配置</div></div><div class="stat-icon" style="background:var(--accent-gold-dim);color:var(--accent-gold);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div></div>
            </div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg> 企业基本信息</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">公司名称（中文）</label><input type="text" class="form-input" value="深圳市创辉科技有限公司" placeholder="请输入公司中文名称"></div><div class="form-group"><label class="form-label">公司名称（英文）</label><input type="text" class="form-input" value="Shenzhen Chuanghui Technology Co., Ltd." placeholder="Company Name (English)"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">所属行业</label><select class="form-select"><option selected>消费电子产品</option><option>电子元器件</option><option>服装纺织</option><option>家居用品</option><option>机械设备</option></select></div><div class="form-group"><label class="form-label">公司网站</label><input type="text" class="form-input" value="https://www.chuanghui-tech.com" placeholder="https://..."></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">联系人</label><input type="text" class="form-input" value="Wang Wei" placeholder="联系人姓名"></div><div class="form-group"><label class="form-label">职位</label><input type="text" class="form-input" value="外贸经理" placeholder="职位名称"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">联系邮箱</label><input type="text" class="form-input" value="wangwei@chuanghui-tech.com" placeholder="email@example.com"></div><div class="form-group"><label class="form-label">联系电话</label><input type="text" class="form-input" value="+86 755 2345 6789" placeholder="+86 ..."></div></div>
                <div class="form-group"><label class="form-label">公司简介</label><textarea class="form-textarea" placeholder="请输入公司简介...">深圳创辉科技成立于2015年，专注于消费电子产品的研发与制造。公司拥有200+员工，年出口额超2000万美元，产品远销欧洲、北美、东南亚等30多个国家和地区。我们已通过ISO 9001、CE、FCC等国际认证。</textarea></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> 目标市场配置</h3></div><div class="panel-body">
                <div class="form-group"><label class="form-label">目标区域</label><select class="form-select"><option selected>欧洲 (Europe)</option><option>北美 (North America)</option><option>东南亚 (Southeast Asia)</option><option>中东 (Middle East)</option><option>南美 (South America)</option><option>全球 (Global)</option></select></div>
                <div class="form-group"><label class="form-label">目标国家</label><div class="tag-container" id="countryTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-blue">Germany <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">UK <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">France <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">Netherlands <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">Spain <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="输入国家名称，按 Enter 添加" onkeydown="handleTagInput(event, this, 'countryTags', 'tag-blue')"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">客户类型</label><select class="form-select"><option selected>批发商 / 分销商</option><option>零售商</option><option>电商卖家</option><option>品牌商 / OEM</option></select></div><div class="form-group"><label class="form-label">语言偏好</label><div class="tag-container" id="langTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-emerald">English <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-emerald">German <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-emerald">French <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="输入语言，按 Enter 添加" onkeydown="handleTagInput(event, this, 'langTags', 'tag-emerald')"></div></div></div>
                <div class="form-group"><label class="form-label">客户规模</label><select class="form-select"><option>不限</option><option selected>中型企业 (50-500人)</option><option>大型企业 (500+人)</option><option>小微企业 (50人以下)</option></select></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> 产品品类管理</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">主品类</label><select class="form-select"><option selected>消费电子产品</option><option>音频设备</option><option>充电设备</option><option>智能穿戴</option></select></div><div class="form-group"><label class="form-label">子品类标签</label><div class="tag-container" id="subCatTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-violet">TWS耳机 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">移动电源 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">智能手表 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">蓝牙音箱 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="输入子品类，按 Enter 添加" onkeydown="handleTagInput(event, this, 'subCatTags', 'tag-violet')"></div></div></div>
                <div class="form-group"><label class="form-label">价格区间</label><div class="form-row"><input type="text" class="form-input" value="$5 - $50" placeholder="最低价"><input type="text" class="form-input" value="MOQ: 500pcs" placeholder="MOQ"></div></div>
                <div class="product-grid"><div class="product-card"><div class="product-name">TWS Earbuds Pro</div><div class="product-category">TWS耳机 / 主动降噪</div><div class="product-price">$12.50 <span>/ MOQ 1000</span></div></div><div class="product-card"><div class="product-name">Power Bank 20000mAh</div><div class="product-category">移动电源 / 快充</div><div class="product-price">$8.80 <span>/ MOQ 500</span></div></div><div class="product-card"><div class="product-name">Smart Watch X</div><div class="product-category">智能手表 / 健康监测</div><div class="product-price">$22.00 <span>/ MOQ 300</span></div></div><div class="btn-add" onclick="openModal('addProductModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>添加新产品</div></div>
            </div></div>
        </div>
        <!-- PAGE 2: Task Config -->
        <div class="page" id="page-task">
            <div class="stat-row">
                <div class="stat-card" style="animation: slideUp 0.4s ease"><div><div class="stat-label">活跃任务</div><div class="stat-value">3</div><div class="stat-change positive">运行正常</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.45s ease"><div><div class="stat-label">今日已发送</div><div class="stat-value">87</div><div class="stat-change positive">+23 vs 昨日</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.5s ease"><div><div class="stat-label">今日回复</div><div class="stat-value">5</div><div class="stat-change positive">回复率 5.7%</div></div><div class="stat-icon" style="background:var(--accent-gold-dim);color:var(--accent-gold);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.55s ease"><div><div class="stat-label">待发送队列</div><div class="stat-value">234</div><div class="stat-change" style="color:var(--accent-amber);">预计2.7天发完</div></div><div class="stat-icon" style="background:var(--accent-amber-dim);color:var(--accent-amber);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></div></div>
            </div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> 邮箱账户配置</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">SMTP 服务器</label><input type="text" class="form-input" value="smtp.chuanghui-tech.com" placeholder="smtp.example.com"></div><div class="form-group"><label class="form-label">端口</label><input type="text" class="form-input" value="465" placeholder="465 / 587 / 25"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">发件邮箱</label><input type="text" class="form-input" value="sales@chuanghui-tech.com" placeholder="sender@example.com"></div><div class="form-group"><label class="form-label">密码 / 授权码</label><input type="password" class="form-input" value="" placeholder="请输入密码"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">加密方式</label><select class="form-select"><option selected>SSL/TLS</option><option>STARTTLS</option><option>无加密</option></select></div><div class="form-group"><label class="form-label">每日发送上限</label><input type="text" class="form-input" value="200" placeholder="200"></div></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> 邮件内容配置</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">主题模板</label><input type="text" class="form-input" value="Quality {{product}} from China - Factory Direct Pricing" placeholder="邮件主题模板"></div><div class="form-group"><label class="form-label">发件人显示名</label><input type="text" class="form-input" value="Wang Wei - Chuanghui Tech" placeholder="发件人名称"></div></div>
                <div class="form-group"><label class="form-label">正文模板</label><div class="template-editor" contenteditable="true">Dear <span class="var-highlight">{{customer_name}}</span>,<br><br>Thank you for your interest in our products. We are <span class="var-highlight">{{company_name}}</span>, a leading manufacturer of <span class="var-highlight">{{product_category}}</span> in China.<br><br>I would like to introduce our best-selling <span class="var-highlight">{{product}}</span> to you. With competitive pricing and strict quality control, we have been serving clients in <span class="var-highlight">{{country}}</span> for over 8 years.<br><br>Would you be available for a brief call this week to discuss potential cooperation?<br><br>Best regards,<br><span class="var-highlight">{{sender_name}}</span><br><span class="var-highlight">{{sender_title}}</span></div></div>
                <div class="form-group"><label class="form-label">附件设置</label><div class="checkbox-group"><label class="checkbox-item"><input type="checkbox" checked> 产品目录 PDF</label><label class="checkbox-item"><input type="checkbox" checked> 报价单 Excel</label><label class="checkbox-item"><input type="checkbox"> 公司资质证书</label><label class="checkbox-item"><input type="checkbox"> 产品图片包</label></div></div>
            </div></div>
            <div class="two-col">
                <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> 定时发送配置</h3></div><div class="panel-body">
                    <div class="form-group"><label class="form-label">发送时段</label><div class="form-row"><input type="time" class="form-input" value="09:00"><input type="time" class="form-input" value="18:00"></div></div>
                    <div class="form-group"><label class="form-label">发送日</label><div class="week-grid"><div class="week-btn active">周一</div><div class="week-btn active">周二</div><div class="week-btn active">周三</div><div class="week-btn active">周四</div><div class="week-btn active">周五</div><div class="week-btn">周六</div><div class="week-btn">周日</div></div></div>
                    <div class="form-group"><label class="form-label">发送间隔</label><select class="form-select"><option>30 秒</option><option selected>60 秒</option><option>90 秒</option><option>120 秒</option><option>180 秒</option></select></div>
                    <div class="form-row"><div class="form-group"><label class="form-label">每邮箱日上限</label><input type="text" class="form-input" value="80" placeholder="80"></div><div class="form-group"><label class="form-label">时区</label><select class="form-select"><option selected>UTC+8 (Asia/Shanghai)</option><option>UTC+0 (Europe/London)</option><option>UTC+1 (Europe/Berlin)</option><option>UTC-5 (America/New_York)</option></select></div></div>
                </div></div>
                <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> 自动回复配置</h3></div><div class="panel-body">
                    <div class="toggle-group">
                        <div class="toggle-item"><div><div class="toggle-label">启用自动回复</div><div class="toggle-desc">收到客户回复时自动响应</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">AI 智能回复</div><div class="toggle-desc">使用AI分析回复内容生成针对性回复</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">自动标记潜在客户</div><div class="toggle-desc">根据回复内容自动识别意向度</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">自动发送报价单</div><div class="toggle-desc">对高意向客户自动发送详细报价</div></div><label class="toggle-switch"><input type="checkbox"><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">通知提醒</div><div class="toggle-desc">收到回复时发送桌面/邮件通知</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                    </div>
                    <div class="form-group" style="margin-top:20px;"><label class="form-label">回复延迟（秒）</label><input type="text" class="form-input" value="300" placeholder="300"></div>
                    <div class="form-group"><label class="form-label">默认回复模板</label><textarea class="form-textarea" rows="3">Thank you for your reply! We appreciate your interest in our products. Let me provide more details and arrange a sample for you.</textarea></div>
                </div></div>
            </div>
        </div>
        <!-- PAGE 3: Customer Leads -->
        <div class="page" id="page-leads">
            <div class="stat-row">
                <div class="stat-card" style="animation: slideUp 0.4s ease"><div><div class="stat-label">总邮件</div><div class="stat-value">1,284</div><div class="stat-change positive">本周 +342</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.45s ease"><div><div class="stat-label">待发送</div><div class="stat-value">234</div><div class="stat-change" style="color:var(--accent-amber);">队列中</div></div><div class="stat-icon" style="background:var(--accent-amber-dim);color:var(--accent-amber);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.5s ease"><div><div class="stat-label">已发送</div><div class="stat-value">892</div><div class="stat-change positive">送达率 98.2%</div></div><div class="stat-icon" style="background:var(--accent-cyan-dim);color:var(--accent-cyan);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></div></div>
                <div class="stat-card" style="animation: slideUp 0.55s ease"><div><div class="stat-label">已回复</div><div class="stat-value">156</div><div class="stat-change positive">回复率 12.2%</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div></div>
            </div>
            <div class="stat-row" style="grid-template-columns:repeat(1,1fr);"><div class="stat-card" style="animation:slideUp 0.6s ease;background:var(--accent-violet-dim);border-color:rgba(124,58,237,0.3);"><div><div class="stat-label">已读邮件</div><div class="stat-value" style="color:var(--accent-violet);">423</div><div class="stat-change positive">打开率 47.4%（基于已发送）</div></div><div class="stat-icon" style="background:var(--accent-violet-dim);color:var(--accent-violet);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div></div></div>
            <div class="toolbar">
                <div class="tab-bar"><div class="tab-btn active" onclick="filterLeads('all',this)">全部 <span class="tab-count">20</span></div><div class="tab-btn" onclick="filterLeads('pending',this)">待发 <span class="tab-count">4</span></div><div class="tab-btn" onclick="filterLeads('sent',this)">已发 <span class="tab-count">7</span></div><div class="tab-btn" onclick="filterLeads('opened',this)">已读 <span class="tab-count">5</span></div><div class="tab-btn" onclick="filterLeads('replied',this)">已回复 <span class="tab-count">4</span></div></div>
                <div class="toolbar-right">
                    <div class="search-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input type="text" placeholder="搜索邮箱、公司..." oninput="searchLeads(this.value)"></div>
                    <button class="btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>导出</button>
                    <button class="btn btn-primary"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新建线索</button>
                </div>
            </div>
            <div class="data-table-wrap"><table class="data-table"><thead><tr><th><input type="checkbox" onclick="toggleAllCheckbox(this)"></th><th>收件邮箱</th><th>公司</th><th>国家</th><th>产品</th><th>发送时间</th><th>状态</th><th>操作</th></tr></thead><tbody id="leadsTableBody"></tbody></table></div>
            <div class="pagination"><div class="page-info">显示 1-20 条，共 20 条记录</div><div class="page-btns"><button class="page-btn" disabled><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg></button><button class="page-btn active">1</button><button class="page-btn">2</button><button class="page-btn">3</button><button class="page-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></button></div></div>
        </div>
    </div>
</div>
<!-- Modals -->
<div class="modal-overlay" id="addProductModal"><div class="modal"><div class="modal-header"><h3>添加新产品</h3><button class="modal-close" onclick="closeModal('addProductModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div><div class="modal-body"><div class="form-group"><label class="form-label">产品名称</label><input type="text" class="form-input" placeholder="请输入产品名称" id="newProductName"></div><div class="form-group"><label class="form-label">产品品类</label><select class="form-select" id="newProductCategory"><option>TWS耳机</option><option>移动电源</option><option>智能手表</option><option>蓝牙音箱</option></select></div><div class="form-row"><div class="form-group"><label class="form-label">单价 ($)</label><input type="text" class="form-input" placeholder="0.00" id="newProductPrice"></div><div class="form-group"><label class="form-label">MOQ (件)</label><input type="text" class="form-input" placeholder="500" id="newProductMoq"></div></div><div class="form-group"><label class="form-label">产品描述</label><textarea class="form-textarea" placeholder="产品简要描述..." id="newProductDesc"></textarea></div></div><div class="modal-footer"><button class="btn" onclick="closeModal('addProductModal')">取消</button><button class="btn btn-primary" onclick="closeModal('addProductModal')">添加产品</button></div></div></div>
<div class="modal-overlay" id="leadDetailModal"><div class="modal" style="width:580px;"><div class="modal-header"><h3 id="leadDetailTitle">线索详情</h3><button class="modal-close" onclick="closeModal('leadDetailModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div><div class="modal-body" id="leadDetailBody"></div><div class="modal-footer"><button class="btn" onclick="closeModal('leadDetailModal')">关闭</button><button class="btn btn-gold">发送跟进邮件</button><button class="btn btn-primary">标记为潜在客户</button></div></div></div>
<script>
var pageTitles={config:'用户配置',task:'任务配置',leads:'客户线索'};
var statusIndicatorPages=['task'];
function switchPage(p,n){document.querySelectorAll('.page').forEach(function(e){e.classList.remove('active')});document.querySelectorAll('.nav-item').forEach(function(e){e.classList.remove('active')});document.getElementById('page-'+p).classList.add('active');if(n)n.classList.add('active');document.getElementById('pageTitle').textContent=pageTitles[p];document.getElementById('statusIndicator').style.display=statusIndicatorPages.indexOf(p)!==-1?'flex':'none'}
function openModal(id){document.getElementById(id).classList.add('active')}
function closeModal(id){document.getElementById(id).classList.remove('active')}
document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.modal-overlay.active').forEach(function(m){m.classList.remove('active')})});
document.querySelectorAll('.modal-overlay').forEach(function(o){o.addEventListener('click',function(e){if(e.target===this)this.classList.remove('active')})});
function handleTagInput(e,i,c,t){if(e.key==='Enter'){e.preventDefault();var v=i.value.trim();if(!v)return;var co=document.getElementById(c);var g=document.createElement('span');g.className='tag-item '+t;g.innerHTML=v+' <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span>';co.insertBefore(g,i);i.value=''}else if(e.key==='Backspace'&&!i.value){var co=document.getElementById(c);var tags=co.querySelectorAll('.tag-item');if(tags.length>0)tags[tags.length-1].remove()}}
function removeTag(el){el.parentElement.remove()}
document.querySelectorAll('.week-btn').forEach(function(b){b.addEventListener('click',function(){this.classList.toggle('active')})});
var leadsData=[{email:'john.mueller@techdistrib.com',company:'TechDistribute GmbH',country:'Germany',flag:'DE',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:15',status:'replied'},{email:'sarah.clark@ukretail.co.uk',company:'UK Retail Solutions',country:'UK',flag:'GB',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:18',status:'opened'},{email:'pierre.dupont@electrofr.fr',company:'Electro France SARL',country:'France',flag:'FR',product:'Smart Watch X',sentTime:'2026-06-27 09:21',status:'sent'},{email:'maria.garcia@importes.com',company:'Importaciones Garcia',country:'Spain',flag:'ES',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:24',status:'opened'},{email:'hans.de.vries@nltrade.nl',company:'NL Trade BV',country:'Netherlands',flag:'NL',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:27',status:'replied'},{email:'lucas.silva@brasilimport.br',company:'Brasil Import Ltda',country:'Brazil',flag:'BR',product:'Smart Watch X',sentTime:'2026-06-27 09:30',status:'pending'},{email:'yuki.tanaka@tokyotech.jp',company:'Tokyo Tech Trading',country:'Japan',flag:'JP',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:33',status:'sent'},{email:'kim.park@seoultrade.kr',company:'Seoul Trade Korea',country:'S. Korea',flag:'KR',product:'Portable Speaker',sentTime:'2026-06-27 09:36',status:'opened'},{email:'alex.johnson@ausretail.au',company:'Australia Retail Co',country:'Australia',flag:'AU',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:39',status:'sent'},{email:'ahmed.hassan@cairoimp.eg',company:'Cairo Importers',country:'Egypt',flag:'EG',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:42',status:'pending'},{email:'emma.wilson@retailuk.com',company:'Wilson Retail Group',country:'UK',flag:'GB',product:'Smart Watch X',sentTime:'2026-06-27 09:45',status:'replied'},{email:'thomas.schmidt@berlin.de',company:'Berlin Electronics GmbH',country:'Germany',flag:'DE',product:'Portable Speaker',sentTime:'2026-06-27 09:48',status:'sent'},{email:'sofia.rossi@milano.it',company:'Milano Distribution',country:'Italy',flag:'IT',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:51',status:'opened'},{email:'carlos.mendez@mximport.mx',company:'Mexico Import SA',country:'Mexico',flag:'MX',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:54',status:'pending'},{email:'liam.oconnor@dublin.ie',company:'Dublin Trade Partners',country:'Ireland',flag:'IE',product:'Smart Watch X',sentTime:'2026-06-27 09:57',status:'sent'},{email:'anna.kowalski@warsaw.pl',company:'Warsaw Distribution',country:'Poland',flag:'PL',product:'Portable Speaker',sentTime:'2026-06-27 10:00',status:'replied'},{email:'erik.johansson@stockholm.se',company:'Stockholm Tech AB',country:'Sweden',flag:'SE',product:'Power Bank 20000mAh',sentTime:'2026-06-27 10:03',status:'opened'},{email:'david.smith@toronto.ca',company:'Toronto Imports Inc',country:'Canada',flag:'CA',product:'TWS Earbuds Pro',sentTime:'2026-06-27 10:06',status:'sent'},{email:'marie.leroy@paris.fr',company:'Paris Distribution Co',country:'France',flag:'FR',product:'Smart Watch X',sentTime:'2026-06-27 10:09',status:'pending'},{email:'james.taylor@london.uk',company:'Taylor Wholesale Ltd',country:'UK',flag:'GB',product:'Portable Speaker',sentTime:'2026-06-27 10:12',status:'sent'}];
var statusMap={sent:{label:'已发送',class:'status-sent'},opened:{label:'已读',class:'status-opened'},replied:{label:'已回复',class:'status-replied'},pending:{label:'待发送',class:'status-pending'}};
function renderLeads(data){var tb=document.getElementById('leadsTableBody');tb.innerHTML='';data.forEach(function(l,i){var s=statusMap[l.status];var r=document.createElement('tr');r.setAttribute('data-status',l.status);r.setAttribute('data-email',l.email);r.setAttribute('data-company',l.company);r.innerHTML='<td><input type="checkbox"></td><td style="font-family:JetBrains Mono,monospace;font-size:13px;">'+l.email+'</td><td style="font-weight:600;">'+l.company+'</td><td><div class="country-cell"><img class="country-flag" src="https://flagcdn.com/24x18/'+l.flag.toLowerCase()+'.png" alt="'+l.flag+'" onerror="this.style.display=\'none\'"> '+l.country+'</div></td><td>'+l.product+'</td><td style="font-family:JetBrains Mono,monospace;font-size:12.5px;color:var(--text-muted);">'+l.sentTime+'</td><td><span class="status-badge '+s.class+'"><span class="dot"></span>'+s.label+'</span></td><td><div class="action-btns"><button class="action-btn" title="查看详情" onclick="showLeadDetail('+i+')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button><button class="action-btn" title="发送邮件"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></button><button class="action-btn" title="更多"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg></button></div></td>';tb.appendChild(r)})}
function filterLeads(s,t){document.querySelectorAll('.tab-btn').forEach(function(b){b.classList.remove('active')});if(t)t.classList.add('active');var f=s==='all'?leadsData:leadsData.filter(function(l){return l.status===s});renderLeads(f)}
function searchLeads(q){q=q.toLowerCase().trim();if(!q){renderLeads(leadsData);return}var f=leadsData.filter(function(l){return l.email.toLowerCase().indexOf(q)!==-1||l.company.toLowerCase().indexOf(q)!==-1||l.country.toLowerCase().indexOf(q)!==-1||l.product.toLowerCase().indexOf(q)!==-1});renderLeads(f)}
function showLeadDetail(i){var l=leadsData[i];var s=statusMap[l.status];document.getElementById('leadDetailTitle').textContent=l.company;var nm=l.email.split('@')[0].replace('.',' ').replace(/\b\w/g,function(c){return c.toUpperCase()});document.getElementById('leadDetailBody').innerHTML='<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;"><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">收件邮箱</div><div style="font-family:JetBrains Mono,monospace;font-size:13px;font-weight:600;">'+l.email+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">国家</div><div style="font-weight:600;display:flex;align-items:center;gap:6px;"><img src="https://flagcdn.com/24x18/'+l.flag.toLowerCase()+'.png" style="width:20px;height:14px;border-radius:2px;border:1px solid var(--border);" onerror="this.style.display=\'none\'"> '+l.country+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">感兴趣产品</div><div style="font-weight:600;">'+l.product+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">发送时间</div><div style="font-family:JetBrains Mono,monospace;font-size:13px;">'+l.sentTime+'</div></div></div><div style="margin-bottom:16px;"><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">当前状态</div><span class="status-badge '+s.class+'"><span class="dot"></span>'+s.label+'</span></div><div style="margin-bottom:16px;"><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">邮件模板</div><div style="padding:14px;background:var(--bg-primary);border-radius:var(--radius-sm);font-size:13px;line-height:1.7;border:1px solid var(--border);">Dear '+nm+',<br><br>Thank you for your interest in our products. We are Shenzhen Chuanghui Technology Co., Ltd., a leading manufacturer of consumer electronics in China.<br><br>I would like to introduce our best-selling <strong style="color:var(--accent-primary);">'+l.product+'</strong> to you. With competitive pricing and strict quality control, we have been serving clients in '+l.country+' for over 8 years.<br><br>Would you be available for a brief call this week to discuss potential cooperation?<br><br>Best regards,<br>Wang Wei<br>Foreign Trade Manager</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">互动记录</div><div style="border:1px solid var(--border);border-radius:var(--radius-sm);overflow:hidden;"><div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;"><div style="width:8px;height:8px;border-radius:50%;background:'+(l.status==='replied'?'var(--accent-emerald)':'var(--accent-cyan)')+';"></div><div style="flex:1;"><div style="font-size:13px;font-weight:600;">'+(l.status==='replied'?'客户已回复 - 表达合作意向':l.status==='opened'?'邮件已打开 - 客户阅读了邮件':l.status==='sent'?'邮件已成功送达':'等待发送')+'</div><div style="font-size:12px;color:var(--text-muted);font-family:JetBrains Mono,monospace;">'+l.sentTime+'</div></div></div></div></div>';openModal('leadDetailModal')}
function toggleAllCheckbox(el){document.querySelectorAll('#leadsTableBody input[type="checkbox"]').forEach(function(cb){cb.checked=el.checked})}
document.querySelectorAll('.toggle-switch input').forEach(function(t){t.addEventListener('change',function(){})});
document.addEventListener('DOMContentLoaded',function(){renderLeads(leadsData)});
</script>
</body>
</html>
'@
$tmpPath = 'd:\web\getClient\trade-acquisition-system\index_new.html'
[System.IO.File]::WriteAllText($tmpPath, $html, [System.Text.Encoding]::UTF8)
$targetPath = 'd:\web\getClient\trade-acquisition-system\index.html'
Remove-Item $targetPath -Force -ErrorAction SilentlyContinue
Move-Item $tmpPath $targetPath -Force
Write-Output "File written successfully"
