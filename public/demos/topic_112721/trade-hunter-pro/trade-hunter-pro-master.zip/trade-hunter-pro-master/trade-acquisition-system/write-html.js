const fs = require('fs');
const path = 'd:/web/getClient/trade-acquisition-system/index_new.html';

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TradeHunter Pro - \u5916\u8d38\u667a\u80fd\u83b7\u5ba2\u7cfb\u7edf</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #f4f6fb; --bg-secondary: #ffffff; --bg-card: #ffffff; --bg-card-hover: #f8f9fc;
            --bg-input: #f0f2f8; --bg-input-focus: #ebedf5; --border: #e2e5ef; --border-focus: #1e40af;
            --border-hover: #cdd1de; --text-primary: #1a1d2e; --text-secondary: #5a6078;
            --text-muted: #8e93a8; --text-placeholder: #b0b5c5; --accent-primary: #1e40af;
            --accent-primary-dim: rgba(30,64,175,0.08); --accent-primary-glow: rgba(30,64,175,0.12);
            --accent-gold: #b8860b; --accent-gold-bright: #d4a843; --accent-gold-dim: rgba(184,134,11,0.10);
            --accent-gold-glow: rgba(184,134,11,0.20); --accent-emerald: #059669; --accent-emerald-dim: rgba(5,150,105,0.08);
            --accent-amber: #b8860b; --accent-amber-dim: rgba(184,134,11,0.10); --accent-rose: #dc2651;
            --accent-rose-dim: rgba(220,38,81,0.08); --accent-violet: #7c3aed; --accent-violet-dim: rgba(124,58,237,0.08);
            --accent-cyan: #0891b2; --accent-cyan-dim: rgba(8,145,178,0.08); --sidebar-width: 260px;
            --header-height: 64px; --radius-sm: 10px; --radius-md: 14px; --radius-lg: 18px;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.03);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.06), 0 1px 4px rgba(0,0,0,0.04);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.04);
            --shadow-card: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.03);
            --shadow-gold: 0 4px 20px rgba(184,134,11,0.15);
            --transition-fast: 0.15s cubic-bezier(0.4,0,0.2,1);
            --transition-base: 0.25s cubic-bezier(0.4,0,0.2,1);
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;background:var(--bg-primary);color:var(--text-primary);line-height:1.6;overflow-x:hidden}
        .sidebar{position:fixed;left:0;top:0;bottom:0;width:var(--sidebar-width);background:var(--bg-secondary);border-right:1px solid var(--border);display:flex;flex-direction:column;z-index:100;box-shadow:var(--shadow-sm)}
        .sidebar-brand{padding:20px 24px;display:flex;align-items:center;gap:14px;border-bottom:1px solid var(--border)}
        .sidebar-brand .logo-icon{width:42px;height:42px;background:linear-gradient(135deg,var(--accent-primary),#3b82f6);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:16px;letter-spacing:1px;box-shadow:0 4px 12px rgba(30,64,175,0.25)}
        .sidebar-brand .brand-text h1{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--text-primary);line-height:1.2}
        .sidebar-brand .brand-text p{font-size:11px;color:var(--text-muted);font-weight:500;letter-spacing:0.3px}
        .sidebar-nav{flex:1;padding:16px 12px;display:flex;flex-direction:column;gap:4px}
        .nav-item{display:flex;align-items:center;gap:12px;padding:11px 16px;border-radius:var(--radius-sm);cursor:pointer;transition:all var(--transition-fast);color:var(--text-secondary);font-size:14px;font-weight:500;position:relative}
        .nav-item:hover{background:var(--bg-primary);color:var(--text-primary)}
        .nav-item.active{background:var(--accent-primary-dim);color:var(--accent-primary);font-weight:600}
        .nav-item.active::before{content:'';position:absolute;left:0;top:50%;transform:translateY(-50%);width:3px;height:24px;border-radius:0 3px 3px 0;background:var(--accent-primary)}
        .nav-item svg{width:20px;height:20px;flex-shrink:0}
        .nav-badge{margin-left:auto;background:var(--accent-rose);color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;min-width:22px;text-align:center}
        .sidebar-footer{padding:16px 20px;border-top:1px solid var(--border);display:flex;align-items:center;gap:12px}
        .sidebar-footer .avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--accent-gold),var(--accent-gold-bright));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:14px;box-shadow:var(--shadow-gold)}
        .sidebar-footer .user-info h4{font-size:13px;font-weight:600;color:var(--text-primary)}
        .sidebar-footer .user-info p{font-size:11px;color:var(--text-muted)}
        .main{margin-left:var(--sidebar-width);min-height:100vh}
        .header{height:var(--header-height);background:var(--bg-secondary);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 32px;position:sticky;top:0;z-index:50;box-shadow:var(--shadow-sm)}
        .header h2{font-family:'Playfair Display',serif;font-size:20px;font-weight:700}
        .header-right{display:flex;align-items:center;gap:16px}
        .header-right .status-indicator{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text-secondary)}
        .status-dot{width:8px;height:8px;border-radius:50%;background:var(--accent-emerald);animation:pulse 2s infinite}
        .header-right .btn-icon{width:38px;height:38px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--bg-secondary);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all var(--transition-fast);color:var(--text-secondary)}
        .header-right .btn-icon:hover{border-color:var(--border-hover);color:var(--text-primary)}
        .content{padding:28px 32px}
        .page{display:none}
        .page.active{display:block;animation:pageIn 0.35s ease}
        .stat-row{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-bottom:28px}
        .stat-card{background:var(--bg-card);border-radius:var(--radius-md);padding:22px 24px;border:1px solid var(--border);box-shadow:var(--shadow-card);transition:all var(--transition-base);display:flex;align-items:flex-start;justify-content:space-between}
        .stat-card:hover{transform:translateY(-2px);box-shadow:var(--shadow-md)}
        .stat-card .stat-label{font-size:13px;color:var(--text-muted);font-weight:500;margin-bottom:6px}
        .stat-card .stat-value{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--text-primary)}
        .stat-card .stat-change{font-size:12px;margin-top:4px;font-weight:500}
        .stat-change.positive{color:var(--accent-emerald)}
        .stat-change.negative{color:var(--accent-rose)}
        .stat-icon{width:44px;height:44px;border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;flex-shrink:0}
        .stat-icon svg{width:22px;height:22px}
        .panel{background:var(--bg-card);border-radius:var(--radius-md);border:1px solid var(--border);box-shadow:var(--shadow-card);margin-bottom:24px;overflow:hidden}
        .panel-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
        .panel-header h3{font-size:15px;font-weight:700;color:var(--text-primary);display:flex;align-items:center;gap:8px}
        .panel-header h3 svg{width:18px;height:18px;color:var(--accent-primary)}
        .panel-body{padding:24px}
        .two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}
        .form-group{margin-bottom:20px}
        .form-group:last-child{margin-bottom:0}
        .form-label{display:block;font-size:13px;font-weight:600;color:var(--text-secondary);margin-bottom:8px}
        .form-input,.form-select,.form-textarea{width:100%;padding:10px 14px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-input);color:var(--text-primary);font-family:inherit;font-size:13.5px;transition:all var(--transition-fast);outline:none}
        .form-input:focus,.form-select:focus,.form-textarea:focus{border-color:var(--border-focus);background:var(--bg-input-focus);box-shadow:0 0 0 3px var(--accent-primary-glow)}
        .form-input::placeholder,.form-textarea::placeholder{color:var(--text-placeholder)}
        .form-textarea{resize:vertical;min-height:80px}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
        .tag-container{display:flex;flex-wrap:wrap;gap:8px;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-input);min-height:44px;align-items:center;cursor:text;transition:all var(--transition-fast)}
        .tag-container:focus-within{border-color:var(--border-focus);background:var(--bg-input-focus);box-shadow:0 0 0 3px var(--accent-primary-glow)}
        .tag-item{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;font-size:12.5px;font-weight:600;animation:tagIn 0.2s ease}
        .tag-item .tag-remove{cursor:pointer;opacity:0.6;transition:opacity var(--transition-fast);display:flex;align-items:center}
        .tag-item .tag-remove:hover{opacity:1}
        .tag-item .tag-remove svg{width:12px;height:12px}
        .tag-blue{background:var(--accent-primary-dim);color:var(--accent-primary)}
        .tag-emerald{background:var(--accent-emerald-dim);color:var(--accent-emerald)}
        .tag-violet{background:var(--accent-violet-dim);color:var(--accent-violet)}
        .tag-input-inline{border:none;background:transparent;outline:none;font-size:13px;color:var(--text-primary);font-family:inherit;min-width:100px;flex:1}
        .tag-input-inline::placeholder{color:var(--text-placeholder)}
        .product-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:16px}
        .product-card{background:var(--bg-primary);border-radius:var(--radius-sm);padding:16px;border:1px solid var(--border);transition:all var(--transition-base)}
        .product-card:hover{border-color:var(--border-hover);box-shadow:var(--shadow-sm)}
        .product-card .product-name{font-size:14px;font-weight:600;margin-bottom:4px}
        .product-card .product-category{font-size:12px;color:var(--text-muted);margin-bottom:8px}
        .product-card .product-price{font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:600;color:var(--accent-primary)}
        .product-card .product-price span{font-size:11px;color:var(--text-muted);font-weight:400}
        .btn-add{display:flex;align-items:center;justify-content:center;gap:8px;padding:16px;border:2px dashed var(--border);border-radius:var(--radius-sm);background:transparent;cursor:pointer;transition:all var(--transition-fast);color:var(--text-muted);font-size:13px;font-weight:500}
        .btn-add:hover{border-color:var(--accent-primary);color:var(--accent-primary);background:var(--accent-primary-dim)}
        .btn-add svg{width:18px;height:18px}
        .toggle-group{display:flex;flex-direction:column;gap:16px}
        .toggle-item{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)}
        .toggle-item:last-child{border-bottom:none}
        .toggle-item .toggle-label{font-size:13.5px;font-weight:500}
        .toggle-item .toggle-desc{font-size:12px;color:var(--text-muted);margin-top:2px}
        .toggle-switch{position:relative;width:44px;height:24px;flex-shrink:0}
        .toggle-switch input{opacity:0;width:0;height:0}
        .toggle-slider{position:absolute;inset:0;background:var(--border);border-radius:12px;cursor:pointer;transition:all var(--transition-fast)}
        .toggle-slider::before{content:'';position:absolute;left:3px;bottom:3px;width:18px;height:18px;background:#fff;border-radius:50%;transition:all var(--transition-fast);box-shadow:0 1px 3px rgba(0,0,0,0.15)}
        .toggle-switch input:checked+.toggle-slider{background:var(--accent-primary)}
        .toggle-switch input:checked+.toggle-slider::before{transform:translateX(20px)}
        .week-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}
        .week-btn{padding:8px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--bg-input);font-size:12px;font-weight:600;color:var(--text-secondary);cursor:pointer;transition:all var(--transition-fast);text-align:center}
        .week-btn.active{background:var(--accent-primary);color:#fff;border-color:var(--accent-primary);box-shadow:0 2px 8px rgba(30,64,175,0.25)}
        .week-btn:not(.active):hover{border-color:var(--border-hover)}
        .template-editor{border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-input);min-height:140px;padding:14px;font-size:13.5px;line-height:1.7;outline:none;transition:all var(--transition-fast)}
        .template-editor:focus{border-color:var(--border-focus);background:var(--bg-input-focus);box-shadow:0 0 0 3px var(--accent-primary-glow)}
        .template-editor .var-highlight{background:var(--accent-gold-dim);color:var(--accent-gold);padding:1px 6px;border-radius:4px;font-family:'JetBrains Mono',monospace;font-size:12px}
        .checkbox-group{display:flex;flex-direction:column;gap:10px}
        .checkbox-item{display:flex;align-items:center;gap:10px;font-size:13.5px;color:var(--text-secondary);cursor:pointer}
        .checkbox-item input[type="checkbox"]{width:16px;height:16px;accent-color:var(--accent-primary);cursor:pointer}
        .toolbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;gap:16px;flex-wrap:wrap}
        .tab-bar{display:flex;gap:4px}
        .tab-btn{padding:8px 16px;border-radius:var(--radius-sm);border:1px solid transparent;background:transparent;font-size:13px;font-weight:500;color:var(--text-secondary);cursor:pointer;transition:all var(--transition-fast);display:flex;align-items:center;gap:6px}
        .tab-btn:hover{background:var(--bg-input)}
        .tab-btn.active{background:var(--accent-primary-dim);color:var(--accent-primary);border-color:var(--accent-primary);font-weight:600}
        .tab-btn .tab-count{font-size:11px;background:var(--bg-input);padding:1px 6px;border-radius:8px;font-weight:600}
        .tab-btn.active .tab-count{background:rgba(30,64,175,0.15)}
        .toolbar-right{display:flex;gap:10px;align-items:center}
        .search-box{display:flex;align-items:center;gap:8px;padding:8px 14px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--bg-input);transition:all var(--transition-fast)}
        .search-box:focus-within{border-color:var(--border-focus);box-shadow:0 0 0 3px var(--accent-primary-glow)}
        .search-box svg{width:16px;height:16px;color:var(--text-muted);flex-shrink:0}
        .search-box input{border:none;background:transparent;outline:none;font-size:13px;color:var(--text-primary);font-family:inherit;width:180px}
        .search-box input::placeholder{color:var(--text-placeholder)}
        .btn{padding:8px 18px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--bg-secondary);font-size:13px;font-weight:600;color:var(--text-primary);cursor:pointer;transition:all var(--transition-fast);display:inline-flex;align-items:center;gap:6px;font-family:inherit}
        .btn:hover{border-color:var(--border-hover);box-shadow:var(--shadow-sm)}
        .btn svg{width:16px;height:16px}
        .btn-primary{background:var(--accent-primary);color:#fff;border-color:var(--accent-primary)}
        .btn-primary:hover{background:#1a38a0;box-shadow:0 4px 12px rgba(30,64,175,0.3)}
        .btn-gold{background:var(--accent-gold);color:#fff;border-color:var(--accent-gold)}
        .btn-gold:hover{background:#a07708;box-shadow:var(--shadow-gold)}
        .data-table-wrap{overflow-x:auto;border:1px solid var(--border);border-radius:var(--radius-md);background:var(--bg-card)}
        .data-table{width:100%;border-collapse:collapse;font-size:13.5px}
        .data-table thead{background:var(--bg-primary)}
        .data-table th{padding:12px 16px;text-align:left;font-weight:600;color:var(--text-secondary);font-size:12px;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid var(--border);white-space:nowrap}
        .data-table td{padding:12px 16px;border-bottom:1px solid var(--border);color:var(--text-primary);white-space:nowrap}
        .data-table tbody tr{transition:background var(--transition-fast)}
        .data-table tbody tr:hover{background:var(--bg-card-hover)}
        .data-table tbody tr:last-child td{border-bottom:none}
        .data-table input[type="checkbox"]{width:16px;height:16px;accent-color:var(--accent-primary);cursor:pointer}
        .country-cell{display:flex;align-items:center;gap:8px}
        .country-flag{width:24px;height:16px;border-radius:2px;object-fit:cover;border:1px solid var(--border)}
        .status-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
        .status-badge .dot{width:6px;height:6px;border-radius:50%}
        .status-sent{background:var(--accent-cyan-dim);color:var(--accent-cyan)}.status-sent .dot{background:var(--accent-cyan)}
        .status-opened{background:var(--accent-violet-dim);color:var(--accent-violet)}.status-opened .dot{background:var(--accent-violet)}
        .status-replied{background:var(--accent-emerald-dim);color:var(--accent-emerald)}.status-replied .dot{background:var(--accent-emerald)}
        .status-pending{background:var(--accent-amber-dim);color:var(--accent-amber)}.status-pending .dot{background:var(--accent-amber)}
        .action-btns{display:flex;gap:6px}
        .action-btn{width:30px;height:30px;border-radius:6px;border:1px solid var(--border);background:var(--bg-secondary);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all var(--transition-fast);color:var(--text-muted)}
        .action-btn:hover{border-color:var(--accent-primary);color:var(--accent-primary);background:var(--accent-primary-dim)}
        .action-btn svg{width:14px;height:14px}
        .pagination{display:flex;align-items:center;justify-content:space-between;padding:16px 0}
        .pagination .page-info{font-size:13px;color:var(--text-muted)}
        .pagination .page-btns{display:flex;gap:4px}
        .page-btn{width:34px;height:34px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--bg-secondary);font-size:13px;font-weight:500;color:var(--text-secondary);cursor:pointer;transition:all var(--transition-fast);display:flex;align-items:center;justify-content:center}
        .page-btn:hover{border-color:var(--accent-primary);color:var(--accent-primary)}
        .page-btn.active{background:var(--accent-primary);color:#fff;border-color:var(--accent-primary)}
        .page-btn:disabled{opacity:0.4;cursor:not-allowed}
        .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.4);backdrop-filter:blur(4px);z-index:200;display:none;align-items:center;justify-content:center}
        .modal-overlay.active{display:flex;animation:fadeIn 0.2s ease}
        .modal{background:var(--bg-card);border-radius:var(--radius-lg);width:520px;max-width:90vw;max-height:85vh;overflow-y:auto;box-shadow:var(--shadow-lg);animation:modalIn 0.3s ease}
        .modal-header{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
        .modal-header h3{font-size:17px;font-weight:700}
        .modal-close{width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:var(--bg-secondary);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all var(--transition-fast);color:var(--text-muted)}
        .modal-close:hover{border-color:var(--accent-rose);color:var(--accent-rose);background:var(--accent-rose-dim)}
        .modal-close svg{width:16px;height:16px}
        .modal-body{padding:24px}
        .modal-footer{padding:16px 24px;border-top:1px solid var(--border);display:flex;gap:10px;justify-content:flex-end}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes pageIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes modalIn{from{opacity:0;transform:scale(0.95) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}
        @keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes tagIn{from{opacity:0;transform:scale(0.8)}to{opacity:1;transform:scale(1)}}
        @keyframes pulse{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(5,150,105,0.4)}50%{opacity:0.8;box-shadow:0 0 0 6px rgba(5,150,105,0)}}
        @media(max-width:1200px){.stat-row{grid-template-columns:repeat(3,1fr)}.product-grid{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:900px){.sidebar{width:0;overflow:hidden}.main{margin-left:0}.stat-row{grid-template-columns:repeat(2,1fr)}.two-col{grid-template-columns:1fr}.product-grid{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}}
        ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}::-webkit-scrollbar-thumb:hover{background:var(--text-muted)}
    </style>
</head>
<body>
<aside class="sidebar">
    <div class="sidebar-brand"><div class="logo-icon">TH</div><div class="brand-text"><h1>TradeHunter</h1><p>\u5916\u8d38\u667a\u80fd\u83b7\u5ba2\u7cfb\u7edf</p></div></div>
    <nav class="sidebar-nav">
        <div class="nav-item active" onclick="switchPage('config',this)" data-page="config"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg><span>\u7528\u6237\u914d\u7f6e</span></div>
        <div class="nav-item" onclick="switchPage('task',this)" data-page="task"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/></svg><span>\u4efb\u52a1\u914d\u7f6e</span><span class="nav-badge">3</span></div>
        <div class="nav-item" onclick="switchPage('leads',this)" data-page="leads"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg><span>\u5ba2\u6237\u7ebf\u7d22</span></div>
    </nav>
    <div class="sidebar-footer"><div class="avatar">WW</div><div class="user-info"><h4>Wang Wei</h4><p>\u5916\u8d38\u7ecf\u7406</p></div></div>
</aside>
<div class="main">
    <header class="header">
        <h2 id="pageTitle">\u7528\u6237\u914d\u7f6e</h2>
        <div class="header-right">
            <div class="status-indicator" id="statusIndicator" style="display:none;"><div class="status-dot"></div><span>\u4efb\u52a1\u8fd0\u884c\u4e2d</span></div>
            <button class="btn-icon" title="\u901a\u77e5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></button>
            <button class="btn-icon" title="\u8bbe\u7f6e"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
        </div>
    </header>
    <div class="content">
        <!-- PAGE 1: User Config -->
        <div class="page active" id="page-config">
            <div class="stat-row">
                <div class="stat-card" style="animation:slideUp 0.4s ease"><div><div class="stat-label">\u914d\u7f6e\u4ea7\u54c1\u6570</div><div class="stat-value">12</div><div class="stat-change positive">+3 \u672c\u6708\u65b0\u589e</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.45s ease"><div><div class="stat-label">\u76ee\u6807\u5e02\u573a</div><div class="stat-value">8</div><div class="stat-change positive">\u8986\u76d6\u6b27\u6d315\u56fd</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.5s ease"><div><div class="stat-label">\u4ea7\u54c1\u54c1\u7c7b</div><div class="stat-value">5</div><div class="stat-change positive">\u97f3\u9891/\u5145\u7535/\u7a7f\u6234</div></div><div class="stat-icon" style="background:var(--accent-violet-dim);color:var(--accent-violet);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h10"/><line x1="18" y1="13" x2="18" y2="21"/><line x1="15" y1="17" x2="21" y2="17"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.55s ease"><div><div class="stat-label">\u914d\u7f6e\u5b8c\u6574\u5ea6</div><div class="stat-value">86%</div><div class="stat-change" style="color:var(--accent-gold);">\u5efa\u8bae\u5b8c\u5584\u90ae\u7bb1\u914d\u7f6e</div></div><div class="stat-icon" style="background:var(--accent-gold-dim);color:var(--accent-gold);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div></div>
            </div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg> \u4f01\u4e1a\u57fa\u672c\u4fe1\u606f</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">\u516c\u53f8\u540d\u79f0\uff08\u4e2d\u6587\uff09</label><input type="text" class="form-input" value="\u6df1\u5733\u5e02\u521b\u8f89\u79d1\u6280\u6709\u9650\u516c\u53f8" placeholder="\u8bf7\u8f93\u5165\u516c\u53f8\u4e2d\u6587\u540d\u79f0"></div><div class="form-group"><label class="form-label">\u516c\u53f8\u540d\u79f0\uff08\u82f1\u6587\uff09</label><input type="text" class="form-input" value="Shenzhen Chuanghui Technology Co., Ltd." placeholder="Company Name (English)"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u6240\u5c5e\u884c\u4e1a</label><select class="form-select"><option selected>\u6d88\u8d39\u7535\u5b50\u4ea7\u54c1</option><option>\u7535\u5b50\u5143\u5668\u4ef6</option><option>\u670d\u88c5\u7eba\u7ec7</option><option>\u5bb6\u5c45\u7528\u54c1</option><option>\u673a\u68b0\u8bbe\u5907</option></select></div><div class="form-group"><label class="form-label">\u516c\u53f8\u7f51\u7ad9</label><input type="text" class="form-input" value="https://www.chuanghui-tech.com" placeholder="https://..."></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u8054\u7cfb\u4eba</label><input type="text" class="form-input" value="Wang Wei" placeholder="\u8054\u7cfb\u4eba\u59d3\u540d"></div><div class="form-group"><label class="form-label">\u804c\u4f4d</label><input type="text" class="form-input" value="\u5916\u8d38\u7ecf\u7406" placeholder="\u804c\u4f4d\u540d\u79f0"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u8054\u7cfb\u90ae\u7bb1</label><input type="text" class="form-input" value="wangwei@chuanghui-tech.com" placeholder="email@example.com"></div><div class="form-group"><label class="form-label">\u8054\u7cfb\u7535\u8bdd</label><input type="text" class="form-input" value="+86 755 2345 6789" placeholder="+86 ..."></div></div>
                <div class="form-group"><label class="form-label">\u516c\u53f8\u7b80\u4ecb</label><textarea class="form-textarea" placeholder="\u8bf7\u8f93\u5165\u516c\u53f8\u7b80\u4ecb...">\u6df1\u5733\u521b\u8f89\u79d1\u6280\u6210\u7acb\u4e8e2015\u5e74\uff0c\u4e13\u6ce8\u4e8e\u6d88\u8d39\u7535\u5b50\u4ea7\u54c1\u7684\u7814\u53d1\u4e0e\u5236\u9020\u3002\u516c\u53f8\u62e5\u6709200+\u5458\u5de5\uff0c\u5e74\u51fa\u53e3\u989d\u8d852000\u4e07\u7f8e\u5143\uff0c\u4ea7\u54c1\u8fdc\u9500\u6b27\u6d32\u3001\u5317\u7f8e\u3001\u4e1c\u5357\u4e9a\u7b4930\u591a\u4e2a\u56fd\u5bb6\u548c\u5730\u533a\u3002\u6211\u4eec\u5df2\u901a\u8fc7ISO 9001\u3001CE\u3001FCC\u7b49\u56fd\u9645\u8ba4\u8bc1\u3002</textarea></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> \u76ee\u6807\u5e02\u573a\u914d\u7f6e</h3></div><div class="panel-body">
                <div class="form-group"><label class="form-label">\u76ee\u6807\u533a\u57df</label><select class="form-select"><option selected>\u6b27\u6d32 (Europe)</option><option>\u5317\u7f8e (North America)</option><option>\u4e1c\u5357\u4e9a (Southeast Asia)</option><option>\u4e2d\u4e1c (Middle East)</option><option>\u5357\u7f8e (South America)</option><option>\u5168\u7403 (Global)</option></select></div>
                <div class="form-group"><label class="form-label">\u76ee\u6807\u56fd\u5bb6</label><div class="tag-container" id="countryTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-blue">Germany <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">UK <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">France <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">Netherlands <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-blue">Spain <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="\u8f93\u5165\u56fd\u5bb6\u540d\u79f0\uff0c\u6309 Enter \u6dfb\u52a0" onkeydown="handleTagInput(event, this, 'countryTags', 'tag-blue')"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u5ba2\u6237\u7c7b\u578b</label><select class="form-select"><option selected>\u6279\u53d1\u5546 / \u5206\u9500\u5546</option><option>\u96f6\u552e\u5546</option><option>\u7535\u5546\u5356\u5bb6</option><option>\u54c1\u724c\u5546 / OEM</option></select></div><div class="form-group"><label class="form-label">\u8bed\u8a00\u504f\u597d</label><div class="tag-container" id="langTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-emerald">English <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-emerald">German <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-emerald">French <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="\u8f93\u5165\u8bed\u8a00\uff0c\u6309 Enter \u6dfb\u52a0" onkeydown="handleTagInput(event, this, 'langTags', 'tag-emerald')"></div></div></div>
                <div class="form-group"><label class="form-label">\u5ba2\u6237\u89c4\u6a21</label><select class="form-select"><option>\u4e0d\u9650</option><option selected>\u4e2d\u578b\u4f01\u4e1a (50-500\u4eba)</option><option>\u5927\u578b\u4f01\u4e1a (500+\u4eba)</option><option>\u5c0f\u5fae\u4f01\u4e1a (50\u4eba\u4ee5\u4e0b)</option></select></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> \u4ea7\u54c1\u54c1\u7c7b\u7ba1\u7406</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">\u4e3b\u54c1\u7c7b</label><select class="form-select"><option selected>\u6d88\u8d39\u7535\u5b50\u4ea7\u54c1</option><option>\u97f3\u9891\u8bbe\u5907</option><option>\u5145\u7535\u8bbe\u5907</option><option>\u667a\u80fd\u7a7f\u6234</option></select></div><div class="form-group"><label class="form-label">\u5b50\u54c1\u7c7b\u6807\u7b7e</label><div class="tag-container" id="subCatTags" onclick="this.querySelector('input').focus()"><span class="tag-item tag-violet">TWS\u8033\u673a <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">\u79fb\u52a8\u7535\u6e90 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">\u667a\u80fd\u624b\u8868 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><span class="tag-item tag-violet">\u84dd\u7259\u97f3\u7bb1 <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></span><input type="text" class="tag-input-inline" placeholder="\u8f93\u5165\u5b50\u54c1\u7c7b\uff0c\u6309 Enter \u6dfb\u52a0" onkeydown="handleTagInput(event, this, 'subCatTags', 'tag-violet')"></div></div></div>
                <div class="form-group"><label class="form-label">\u4ef7\u683c\u533a\u95f4</label><div class="form-row"><input type="text" class="form-input" value="$5 - $50" placeholder="\u6700\u4f4e\u4ef7"><input type="text" class="form-input" value="MOQ: 500pcs" placeholder="MOQ"></div></div>
                <div class="product-grid"><div class="product-card"><div class="product-name">TWS Earbuds Pro</div><div class="product-category">TWS\u8033\u673a / \u4e3b\u52a8\u964d\u566a</div><div class="product-price">$12.50 <span>/ MOQ 1000</span></div></div><div class="product-card"><div class="product-name">Power Bank 20000mAh</div><div class="product-category">\u79fb\u52a8\u7535\u6e90 / \u5feb\u5145</div><div class="product-price">$8.80 <span>/ MOQ 500</span></div></div><div class="product-card"><div class="product-name">Smart Watch X</div><div class="product-category">\u667a\u80fd\u624b\u8868 / \u5065\u5eb7\u76d1\u6d4b</div><div class="product-price">$22.00 <span>/ MOQ 300</span></div></div><div class="btn-add" onclick="openModal('addProductModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>\u6dfb\u52a0\u65b0\u4ea7\u54c1</div></div>
            </div></div>
        </div>
        <!-- PAGE 2: Task Config -->
        <div class="page" id="page-task">
            <div class="stat-row">
                <div class="stat-card" style="animation:slideUp 0.4s ease"><div><div class="stat-label">\u6d3b\u8dc3\u4efb\u52a1</div><div class="stat-value">3</div><div class="stat-change positive">\u8fd0\u884c\u6b63\u5e38</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.45s ease"><div><div class="stat-label">\u4eca\u65e5\u5df2\u53d1\u9001</div><div class="stat-value">87</div><div class="stat-change positive">+23 vs \u6628\u65e5</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.5s ease"><div><div class="stat-label">\u4eca\u65e5\u56de\u590d</div><div class="stat-value">5</div><div class="stat-change positive">\u56de\u590d\u7387 5.7%</div></div><div class="stat-icon" style="background:var(--accent-gold-dim);color:var(--accent-gold);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.55s ease"><div><div class="stat-label">\u5f85\u53d1\u9001\u961f\u5217</div><div class="stat-value">234</div><div class="stat-change" style="color:var(--accent-amber);">\u9884\u8ba12.7\u5929\u53d1\u5b8c</div></div><div class="stat-icon" style="background:var(--accent-amber-dim);color:var(--accent-amber);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></div></div>
            </div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> \u90ae\u7bb1\u8d26\u6237\u914d\u7f6e</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">SMTP \u670d\u52a1\u5668</label><input type="text" class="form-input" value="smtp.chuanghui-tech.com" placeholder="smtp.example.com"></div><div class="form-group"><label class="form-label">\u7aef\u53e3</label><input type="text" class="form-input" value="465" placeholder="465 / 587 / 25"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u53d1\u4ef6\u90ae\u7bb1</label><input type="text" class="form-input" value="sales@chuanghui-tech.com" placeholder="sender@example.com"></div><div class="form-group"><label class="form-label">\u5bc6\u7801 / \u6388\u6743\u7801</label><input type="password" class="form-input" value="" placeholder="\u8bf7\u8f93\u5165\u5bc6\u7801"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">\u52a0\u5bc6\u65b9\u5f0f</label><select class="form-select"><option selected>SSL/TLS</option><option>STARTTLS</option><option>\u65e0\u52a0\u5bc6</option></select></div><div class="form-group"><label class="form-label">\u6bcf\u65e5\u53d1\u9001\u4e0a\u9650</label><input type="text" class="form-input" value="200" placeholder="200"></div></div>
            </div></div>
            <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> \u90ae\u4ef6\u5185\u5bb9\u914d\u7f6e</h3></div><div class="panel-body">
                <div class="form-row"><div class="form-group"><label class="form-label">\u4e3b\u9898\u6a21\u677f</label><input type="text" class="form-input" value="Quality {{product}} from China - Factory Direct Pricing" placeholder="\u90ae\u4ef6\u4e3b\u9898\u6a21\u677f"></div><div class="form-group"><label class="form-label">\u53d1\u4ef6\u4eba\u663e\u793a\u540d</label><input type="text" class="form-input" value="Wang Wei - Chuanghui Tech" placeholder="\u53d1\u4ef6\u4eba\u540d\u79f0"></div></div>
                <div class="form-group"><label class="form-label">\u6b63\u6587\u6a21\u677f</label><div class="template-editor" contenteditable="true">Dear <span class="var-highlight">{{customer_name}}</span>,<br><br>Thank you for your interest in our products. We are <span class="var-highlight">{{company_name}}</span>, a leading manufacturer of <span class="var-highlight">{{product_category}}</span> in China.<br><br>I would like to introduce our best-selling <span class="var-highlight">{{product}}</span> to you. With competitive pricing and strict quality control, we have been serving clients in <span class="var-highlight">{{country}}</span> for over 8 years.<br><br>Would you be available for a brief call this week to discuss potential cooperation?<br><br>Best regards,<br><span class="var-highlight">{{sender_name}}</span><br><span class="var-highlight">{{sender_title}}</span></div></div>
                <div class="form-group"><label class="form-label">\u9644\u4ef6\u8bbe\u7f6e</label><div class="checkbox-group"><label class="checkbox-item"><input type="checkbox" checked> \u4ea7\u54c1\u76ee\u5f55 PDF</label><label class="checkbox-item"><input type="checkbox" checked> \u62a5\u4ef7\u5355 Excel</label><label class="checkbox-item"><input type="checkbox"> \u516c\u53f8\u8d44\u8d28\u8bc1\u4e66</label><label class="checkbox-item"><input type="checkbox"> \u4ea7\u54c1\u56fe\u7247\u5305</label></div></div>
            </div></div>
            <div class="two-col">
                <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> \u5b9a\u65f6\u53d1\u9001\u914d\u7f6e</h3></div><div class="panel-body">
                    <div class="form-group"><label class="form-label">\u53d1\u9001\u65f6\u6bb5</label><div class="form-row"><input type="time" class="form-input" value="09:00"><input type="time" class="form-input" value="18:00"></div></div>
                    <div class="form-group"><label class="form-label">\u53d1\u9001\u65e5</label><div class="week-grid"><div class="week-btn active">\u5468\u4e00</div><div class="week-btn active">\u5468\u4e8c</div><div class="week-btn active">\u5468\u4e09</div><div class="week-btn active">\u5468\u56db</div><div class="week-btn active">\u5468\u4e94</div><div class="week-btn">\u5468\u516d</div><div class="week-btn">\u5468\u65e5</div></div></div>
                    <div class="form-group"><label class="form-label">\u53d1\u9001\u95f4\u9694</label><select class="form-select"><option>30 \u79d2</option><option selected>60 \u79d2</option><option>90 \u79d2</option><option>120 \u79d2</option><option>180 \u79d2</option></select></div>
                    <div class="form-row"><div class="form-group"><label class="form-label">\u6bcf\u90ae\u7bb1\u65e5\u4e0a\u9650</label><input type="text" class="form-input" value="80" placeholder="80"></div><div class="form-group"><label class="form-label">\u65f6\u533a</label><select class="form-select"><option selected>UTC+8 (Asia/Shanghai)</option><option>UTC+0 (Europe/London)</option><option>UTC+1 (Europe/Berlin)</option><option>UTC-5 (America/New_York)</option></select></div></div>
                </div></div>
                <div class="panel"><div class="panel-header"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> \u81ea\u52a8\u56de\u590d\u914d\u7f6e</h3></div><div class="panel-body">
                    <div class="toggle-group">
                        <div class="toggle-item"><div><div class="toggle-label">\u542f\u7528\u81ea\u52a8\u56de\u590d</div><div class="toggle-desc">\u6536\u5230\u5ba2\u6237\u56de\u590d\u65f6\u81ea\u52a8\u54cd\u5e94</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">AI \u667a\u80fd\u56de\u590d</div><div class="toggle-desc">\u4f7f\u7528AI\u5206\u6790\u56de\u590d\u5185\u5bb9\u751f\u6210\u9488\u5bf9\u6027\u56de\u590d</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">\u81ea\u52a8\u6807\u8bb0\u6f5c\u5728\u5ba2\u6237</div><div class="toggle-desc">\u6839\u636e\u56de\u590d\u5185\u5bb9\u81ea\u52a8\u8bc6\u522b\u610f\u5411\u5ea6</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">\u81ea\u52a8\u53d1\u9001\u62a5\u4ef7\u5355</div><div class="toggle-desc">\u5bf9\u9ad8\u610f\u5411\u5ba2\u6237\u81ea\u52a8\u53d1\u9001\u8be6\u7ec6\u62a5\u4ef7</div></div><label class="toggle-switch"><input type="checkbox"><span class="toggle-slider"></span></label></div>
                        <div class="toggle-item"><div><div class="toggle-label">\u901a\u77e5\u63d0\u9192</div><div class="toggle-desc">\u6536\u5230\u56de\u590d\u65f6\u53d1\u9001\u684c\u9762/\u90ae\u4ef6\u901a\u77e5</div></div><label class="toggle-switch"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
                    </div>
                    <div class="form-group" style="margin-top:20px;"><label class="form-label">\u56de\u590d\u5ef6\u8fdf\uff08\u79d2\uff09</label><input type="text" class="form-input" value="300" placeholder="300"></div>
                    <div class="form-group"><label class="form-label">\u9ed8\u8ba4\u56de\u590d\u6a21\u677f</label><textarea class="form-textarea" rows="3">Thank you for your reply! We appreciate your interest in our products. Let me provide more details and arrange a sample for you.</textarea></div>
                </div></div>
            </div>
        </div>
        <!-- PAGE 3: Customer Leads -->
        <div class="page" id="page-leads">
            <div class="stat-row">
                <div class="stat-card" style="animation:slideUp 0.4s ease"><div><div class="stat-label">\u603b\u90ae\u4ef6</div><div class="stat-value">1,284</div><div class="stat-change positive">\u672c\u5468 +342</div></div><div class="stat-icon" style="background:var(--accent-primary-dim);color:var(--accent-primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.45s ease"><div><div class="stat-label">\u5f85\u53d1\u9001</div><div class="stat-value">234</div><div class="stat-change" style="color:var(--accent-amber);">\u961f\u5217\u4e2d</div></div><div class="stat-icon" style="background:var(--accent-amber-dim);color:var(--accent-amber);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.5s ease"><div><div class="stat-label">\u5df2\u53d1\u9001</div><div class="stat-value">892</div><div class="stat-change positive">\u9001\u8fbe\u7387 98.2%</div></div><div class="stat-icon" style="background:var(--accent-cyan-dim);color:var(--accent-cyan);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></div></div>
                <div class="stat-card" style="animation:slideUp 0.55s ease"><div><div class="stat-label">\u5df2\u56de\u590d</div><div class="stat-value">156</div><div class="stat-change positive">\u56de\u590d\u7387 12.2%</div></div><div class="stat-icon" style="background:var(--accent-emerald-dim);color:var(--accent-emerald);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div></div>
            </div>
            <div class="stat-row" style="grid-template-columns:repeat(1,1fr);"><div class="stat-card" style="animation:slideUp 0.6s ease;background:var(--accent-violet-dim);border-color:rgba(124,58,237,0.3);"><div><div class="stat-label">\u5df2\u8bfb\u90ae\u4ef6</div><div class="stat-value" style="color:var(--accent-violet);">423</div><div class="stat-change positive">\u6253\u5f00\u7387 47.4%\uff08\u57fa\u4e8e\u5df2\u53d1\u9001\uff09</div></div><div class="stat-icon" style="background:var(--accent-violet-dim);color:var(--accent-violet);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div></div></div>
            <div class="toolbar">
                <div class="tab-bar"><div class="tab-btn active" onclick="filterLeads('all',this)">\u5168\u90e8 <span class="tab-count">20</span></div><div class="tab-btn" onclick="filterLeads('pending',this)">\u5f85\u53d1 <span class="tab-count">4</span></div><div class="tab-btn" onclick="filterLeads('sent',this)">\u5df2\u53d1 <span class="tab-count">7</span></div><div class="tab-btn" onclick="filterLeads('opened',this)">\u5df2\u8bfb <span class="tab-count">5</span></div><div class="tab-btn" onclick="filterLeads('replied',this)">\u5df2\u56de\u590d <span class="tab-count">4</span></div></div>
                <div class="toolbar-right">
                    <div class="search-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input type="text" placeholder="\u641c\u7d22\u90ae\u7bb1\u3001\u516c\u53f8..." oninput="searchLeads(this.value)"></div>
                    <button class="btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>\u5bfc\u51fa</button>
                    <button class="btn btn-primary"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>\u65b0\u5efa\u7ebf\u7d22</button>
                </div>
            </div>
            <div class="data-table-wrap"><table class="data-table"><thead><tr><th><input type="checkbox" onclick="toggleAllCheckbox(this)"></th><th>\u6536\u4ef6\u90ae\u7bb1</th><th>\u516c\u53f8</th><th>\u56fd\u5bb6</th><th>\u4ea7\u54c1</th><th>\u53d1\u9001\u65f6\u95f4</th><th>\u72b6\u6001</th><th>\u64cd\u4f5c</th></tr></thead><tbody id="leadsTableBody"></tbody></table></div>
            <div class="pagination"><div class="page-info">\u663e\u793a 1-20 \u6761\uff0c\u5171 20 \u6761\u8bb0\u5f55</div><div class="page-btns"><button class="page-btn" disabled><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg></button><button class="page-btn active">1</button><button class="page-btn">2</button><button class="page-btn">3</button><button class="page-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></button></div></div>
        </div>
    </div>
</div>
<!-- Modals -->
<div class="modal-overlay" id="addProductModal"><div class="modal"><div class="modal-header"><h3>\u6dfb\u52a0\u65b0\u4ea7\u54c1</h3><button class="modal-close" onclick="closeModal('addProductModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div><div class="modal-body"><div class="form-group"><label class="form-label">\u4ea7\u54c1\u540d\u79f0</label><input type="text" class="form-input" placeholder="\u8bf7\u8f93\u5165\u4ea7\u54c1\u540d\u79f0" id="newProductName"></div><div class="form-group"><label class="form-label">\u4ea7\u54c1\u54c1\u7c7b</label><select class="form-select" id="newProductCategory"><option>TWS\u8033\u673a</option><option>\u79fb\u52a8\u7535\u6e90</option><option>\u667a\u80fd\u624b\u8868</option><option>\u84dd\u7259\u97f3\u7bb1</option></select></div><div class="form-row"><div class="form-group"><label class="form-label">\u5355\u4ef7 ($)</label><input type="text" class="form-input" placeholder="0.00" id="newProductPrice"></div><div class="form-group"><label class="form-label">MOQ (\u4ef6)</label><input type="text" class="form-input" placeholder="500" id="newProductMoq"></div></div><div class="form-group"><label class="form-label">\u4ea7\u54c1\u63cf\u8ff0</label><textarea class="form-textarea" placeholder="\u4ea7\u54c1\u7b80\u8981\u63cf\u8ff0..." id="newProductDesc"></textarea></div></div><div class="modal-footer"><button class="btn" onclick="closeModal('addProductModal')">\u53d6\u6d88</button><button class="btn btn-primary" onclick="closeModal('addProductModal')">\u6dfb\u52a0\u4ea7\u54c1</button></div></div></div>
<div class="modal-overlay" id="leadDetailModal"><div class="modal" style="width:580px;"><div class="modal-header"><h3 id="leadDetailTitle">\u7ebf\u7d22\u8be6\u60c5</h3><button class="modal-close" onclick="closeModal('leadDetailModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div><div class="modal-body" id="leadDetailBody"></div><div class="modal-footer"><button class="btn" onclick="closeModal('leadDetailModal')">\u5173\u95ed</button><button class="btn btn-gold">\u53d1\u9001\u8ddf\u8fdb\u90ae\u4ef6</button><button class="btn btn-primary">\u6807\u8bb0\u4e3a\u6f5c\u5728\u5ba2\u6237</button></div></div></div>
<script>
var pageTitles={config:'\\u7528\\u6237\\u914d\\u7f6e',task:'\\u4efb\\u52a1\\u914d\\u7f6e',leads:'\\u5ba2\\u6237\\u7ebf\\u7d22'};
var statusIndicatorPages=['task'];
function switchPage(p,n){document.querySelectorAll('.page').forEach(function(e){e.classList.remove('active')});document.querySelectorAll('.nav-item').forEach(function(e){e.classList.remove('active')});document.getElementById('page-'+p).classList.add('active');if(n)n.classList.add('active');document.getElementById('pageTitle').textContent=pageTitles[p];document.getElementById('statusIndicator').style.display=statusIndicatorPages.indexOf(p)!==-1?'flex':'none'}
function openModal(id){document.getElementById(id).classList.add('active')}
function closeModal(id){document.getElementById(id).classList.remove('active')}
document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.modal-overlay.active').forEach(function(m){m.classList.remove('active')})});
document.querySelectorAll('.modal-overlay').forEach(function(o){o.addEventListener('click',function(e){if(e.target===this)this.classList.remove('active')})});
function handleTagInput(e,i,c,t){if(e.key==='Enter'){e.preventDefault();var v=i.value.trim();if(!v)return;var co=document.getElementById(c);var g=document.createElement('span');g.className='tag-item '+t;g.innerHTML=v+' <span class="tag-remove" onclick="removeTag(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span>';co.insertBefore(g,i);i.value=''}else if(e.key==='Backspace'&&!i.value){var co=document.getElementById(c);var tags=co.querySelectorAll('.tag-item');if(tags.length>0)tags[tags.length-1].remove()}}
function removeTag(el){el.parentElement.remove()}
document.querySelectorAll('.week-btn').forEach(function(b){b.addEventListener('click',function(){this.classList.toggle('active')})});
var leadsData=[
{email:'john.mueller@techdistrib.com',company:'TechDistribute GmbH',country:'Germany',flag:'DE',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:15',status:'replied'},
{email:'sarah.clark@ukretail.co.uk',company:'UK Retail Solutions',country:'UK',flag:'GB',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:18',status:'opened'},
{email:'pierre.dupont@electrofr.fr',company:'Electro France SARL',country:'France',flag:'FR',product:'Smart Watch X',sentTime:'2026-06-27 09:21',status:'sent'},
{email:'maria.garcia@importes.com',company:'Importaciones Garcia',country:'Spain',flag:'ES',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:24',status:'opened'},
{email:'hans.de.vries@nltrade.nl',company:'NL Trade BV',country:'Netherlands',flag:'NL',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:27',status:'replied'},
{email:'lucas.silva@brasilimport.br',company:'Brasil Import Ltda',country:'Brazil',flag:'BR',product:'Smart Watch X',sentTime:'2026-06-27 09:30',status:'pending'},
{email:'yuki.tanaka@tokyotech.jp',company:'Tokyo Tech Trading',country:'Japan',flag:'JP',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:33',status:'sent'},
{email:'kim.park@seoultrade.kr',company:'Seoul Trade Korea',country:'S. Korea',flag:'KR',product:'Portable Speaker',sentTime:'2026-06-27 09:36',status:'opened'},
{email:'alex.johnson@ausretail.au',company:'Australia Retail Co',country:'Australia',flag:'AU',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:39',status:'sent'},
{email:'ahmed.hassan@cairoimp.eg',company:'Cairo Importers',country:'Egypt',flag:'EG',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:42',status:'pending'},
{email:'emma.wilson@retailuk.com',company:'Wilson Retail Group',country:'UK',flag:'GB',product:'Smart Watch X',sentTime:'2026-06-27 09:45',status:'replied'},
{email:'thomas.schmidt@berlin.de',company:'Berlin Electronics GmbH',country:'Germany',flag:'DE',product:'Portable Speaker',sentTime:'2026-06-27 09:48',status:'sent'},
{email:'sofia.rossi@milano.it',company:'Milano Distribution',country:'Italy',flag:'IT',product:'Power Bank 20000mAh',sentTime:'2026-06-27 09:51',status:'opened'},
{email:'carlos.mendez@mximport.mx',company:'Mexico Import SA',country:'Mexico',flag:'MX',product:'TWS Earbuds Pro',sentTime:'2026-06-27 09:54',status:'pending'},
{email:'liam.oconnor@dublin.ie',company:'Dublin Trade Partners',country:'Ireland',flag:'IE',product:'Smart Watch X',sentTime:'2026-06-27 09:57',status:'sent'},
{email:'anna.kowalski@warsaw.pl',company:'Warsaw Distribution',country:'Poland',flag:'PL',product:'Portable Speaker',sentTime:'2026-06-27 10:00',status:'replied'},
{email:'erik.johansson@stockholm.se',company:'Stockholm Tech AB',country:'Sweden',flag:'SE',product:'Power Bank 20000mAh',sentTime:'2026-06-27 10:03',status:'opened'},
{email:'david.smith@toronto.ca',company:'Toronto Imports Inc',country:'Canada',flag:'CA',product:'TWS Earbuds Pro',sentTime:'2026-06-27 10:06',status:'sent'},
{email:'marie.leroy@paris.fr',company:'Paris Distribution Co',country:'France',flag:'FR',product:'Smart Watch X',sentTime:'2026-06-27 10:09',status:'pending'},
{email:'james.taylor@london.uk',company:'Taylor Wholesale Ltd',country:'UK',flag:'GB',product:'Portable Speaker',sentTime:'2026-06-27 10:12',status:'sent'}
];
var statusMap={sent:{label:'\\u5df2\\u53d1\\u9001',class:'status-sent'},opened:{label:'\\u5df2\\u8bfb',class:'status-opened'},replied:{label:'\\u5df2\\u56de\\u590d',class:'status-replied'},pending:{label:'\\u5f85\\u53d1\\u9001',class:'status-pending'}};
function renderLeads(data){var tb=document.getElementById('leadsTableBody');tb.innerHTML='';data.forEach(function(l,i){var s=statusMap[l.status];var r=document.createElement('tr');r.setAttribute('data-status',l.status);r.setAttribute('data-email',l.email);r.setAttribute('data-company',l.company);r.innerHTML='<td><input type="checkbox"></td><td style="font-family:JetBrains Mono,monospace;font-size:13px;">'+l.email+'</td><td style="font-weight:600;">'+l.company+'</td><td><div class="country-cell"><img class="country-flag" src="https://flagcdn.com/24x18/'+l.flag.toLowerCase()+'.png" alt="'+l.flag+'" onerror="this.style.display=\\'none\\'"> '+l.country+'</div></td><td>'+l.product+'</td><td style="font-family:JetBrains Mono,monospace;font-size:12.5px;color:var(--text-muted);">'+l.sentTime+'</td><td><span class="status-badge '+s.class+'"><span class="dot"></span>'+s.label+'</span></td><td><div class="action-btns"><button class="action-btn" title="\\u67e5\\u770b\\u8be6\\u60c5" onclick="showLeadDetail('+i+')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button><button class="action-btn" title="\\u53d1\\u9001\\u90ae\\u4ef6"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></button><button class="action-btn" title="\\u66f4\\u591a"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg></button></div></td>';tb.appendChild(r)})}
function filterLeads(s,t){document.querySelectorAll('.tab-btn').forEach(function(b){b.classList.remove('active')});if(t)t.classList.add('active');var f=s==='all'?leadsData:leadsData.filter(function(l){return l.status===s});renderLeads(f)}
function searchLeads(q){q=q.toLowerCase().trim();if(!q){renderLeads(leadsData);return}var f=leadsData.filter(function(l){return l.email.toLowerCase().indexOf(q)!==-1||l.company.toLowerCase().indexOf(q)!==-1||l.country.toLowerCase().indexOf(q)!==-1||l.product.toLowerCase().indexOf(q)!==-1});renderLeads(f)}
function showLeadDetail(i){var l=leadsData[i];var s=statusMap[l.status];document.getElementById('leadDetailTitle').textContent=l.company;var nm=l.email.split('@')[0].replace('.',' ').replace(/\\b\\w/g,function(c){return c.toUpperCase()});document.getElementById('leadDetailBody').innerHTML='<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;"><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">\\u6536\\u4ef6\\u90ae\\u7bb1</div><div style="font-family:JetBrains Mono,monospace;font-size:13px;font-weight:600;">'+l.email+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">\\u56fd\\u5bb6</div><div style="font-weight:600;display:flex;align-items:center;gap:6px;"><img src="https://flagcdn.com/24x18/'+l.flag.toLowerCase()+'.png" style="width:20px;height:14px;border-radius:2px;border:1px solid var(--border);" onerror="this.style.display=\\'none\\'"> '+l.country+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">\\u611f\\u5174\\u8da3\\u4ea7\\u54c1</div><div style="font-weight:600;">'+l.product+'</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">\\u53d1\\u9001\\u65f6\\u95f4</div><div style="font-family:JetBrains Mono,monospace;font-size:13px;">'+l.sentTime+'</div></div></div><div style="margin-bottom:16px;"><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">\\u5f53\\u524d\\u72b6\\u6001</div><span class="status-badge '+s.class+'"><span class="dot"></span>'+s.label+'</span></div><div style="margin-bottom:16px;"><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">\\u90ae\\u4ef6\\u6a21\\u677f</div><div style="padding:14px;background:var(--bg-primary);border-radius:var(--radius-sm);font-size:13px;line-height:1.7;border:1px solid var(--border);">Dear '+nm+',<br><br>Thank you for your interest in our products. We are Shenzhen Chuanghui Technology Co., Ltd., a leading manufacturer of consumer electronics in China.<br><br>I would like to introduce our best-selling <strong style="color:var(--accent-primary);">'+l.product+'</strong> to you. With competitive pricing and strict quality control, we have been serving clients in '+l.country+' for over 8 years.<br><br>Would you be available for a brief call this week to discuss potential cooperation?<br><br>Best regards,<br>Wang Wei<br>Foreign Trade Manager</div></div><div><div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">\\u4e92\\u52a8\\u8bb0\\u5f55</div><div style="border:1px solid var(--border);border-radius:var(--radius-sm);overflow:hidden;"><div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;"><div style="width:8px;height:8px;border-radius:50%;background:'+(l.status==='replied'?'var(--accent-emerald)':'var(--accent-cyan)')+';"></div><div style="flex:1;"><div style="font-size:13px;font-weight:600;">'+(l.status==='replied'?'\\u5ba2\\u6237\\u5df2\\u56de\\u590d - \\u8868\\u8fbe\\u5408\\u4f5c\\u610f\\u5411':l.status==='opened'?'\\u90ae\\u4ef6\\u5df2\\u6253\\u5f00 - \\u5ba2\\u6237\\u9605\\u8bfb\\u4e86\\u90ae\\u4ef6':l.status==='sent'?'\\u90ae\\u4ef6\\u5df2\\u6210\\u529f\\u9001\\u8fbe':'\\u7b49\\u5f85\\u53d1\\u9001')+'</div><div style="font-size:12px;color:var(--text-muted);font-family:JetBrains Mono,monospace;">'+l.sentTime+'</div></div></div></div></div>';openModal('leadDetailModal')}
function toggleAllCheckbox(el){document.querySelectorAll('#leadsTableBody input[type="checkbox"]').forEach(function(cb){cb.checked=el.checked})}
document.querySelectorAll('.toggle-switch input').forEach(function(t){t.addEventListener('change',function(){})});
document.addEventListener('DOMContentLoaded',function(){renderLeads(leadsData)});
</script>
</body>
</html>`;

fs.writeFileSync(path, html, 'utf8');
try { fs.unlinkSync('d:/web/getClient/trade-acquisition-system/index.html'); } catch(e) {}
fs.renameSync(path, 'd:/web/getClient/trade-acquisition-system/index.html');
const stat = fs.statSync('d:/web/getClient/trade-acquisition-system/index.html');
console.log('Written: ' + stat.size + ' bytes');

// Verify Chinese
const buf = fs.readFileSync('d:/web/getClient/trade-acquisition-system/index.html', 'utf8');
console.log('Has \\u7528\\u6237\\u914d\\u7f6e: ' + buf.includes('\\u7528\\u6237\\u914d\\u7f6e'));
console.log('Ends </html>: ' + buf.trimEnd().endsWith('</html>'));
