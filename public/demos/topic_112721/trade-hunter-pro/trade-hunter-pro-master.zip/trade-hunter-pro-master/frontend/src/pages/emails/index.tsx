import { useState, useEffect } from 'react';
import { Card, Tabs, Table, Button, Tag, Form, Input, Select, Modal, message, InputNumber } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, SendOutlined, PlayCircleOutlined } from '@ant-design/icons';
import { emailsApi } from '@/services/api';
import { formatDate, getStatusText } from '@/utils';

const { Option } = Select;

export const Emails = () => {
  const [activeTab, setActiveTab] = useState('campaigns');
  const [accounts, setAccounts] = useState<unknown[]>([]);
  const [templates, setTemplates] = useState<unknown[]>([]);
  const [campaigns, setCampaigns] = useState<unknown[]>([]);
  const [records] = useState<unknown[]>([]);
  const [sequences, setSequences] = useState<unknown[]>([]);
  const [form] = Form.useForm();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalType, setModalType] = useState<'account' | 'template' | 'campaign'>('account');
  const [editingItem, setEditingItem] = useState<unknown | null>(null);

  useEffect(() => {
    fetchAccounts();
    fetchTemplates();
    fetchCampaigns();
    fetchSequences();
  }, []);

  const fetchAccounts = async () => {
    try {
      const response = await emailsApi.accounts.list();
      if ((response.data as { success: boolean }).success) {
        setAccounts((response.data as { data: unknown[] }).data || []);
      }
    } catch (error) {
      message.error('获取邮箱账户失败');
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await emailsApi.templates.list();
      if ((response.data as { success: boolean }).success) {
        setTemplates((response.data as { data: unknown[] }).data || []);
      }
    } catch (error) {
      message.error('获取模板失败');
    }
  };

  const fetchCampaigns = async () => {
    try {
      const response = await emailsApi.campaigns.list();
      setCampaigns(response.data.data || []);
    } catch (error) {
      message.error('获取活动失败');
    }
  };

  const fetchSequences = async () => {
    try {
      const response = await emailsApi.sequences.list();
      if ((response.data as { success: boolean }).success) {
        setSequences((response.data as { data: unknown[] }).data || []);
      }
    } catch (error) {
      message.error('获取序列失败');
    }
  };

  const handleSubmit = async (values: unknown) => {
    try {
      if (modalType === 'account') {
        if (editingItem) {
          await emailsApi.accounts.update((editingItem as { id: string }).id, values);
          message.success('邮箱账户更新成功');
        } else {
          await emailsApi.accounts.create(values);
          message.success('邮箱账户创建成功');
        }
        fetchAccounts();
      } else if (modalType === 'template') {
        if (editingItem) {
          await emailsApi.templates.update((editingItem as { id: string }).id, values);
          message.success('模板更新成功');
        } else {
          await emailsApi.templates.create(values);
          message.success('模板创建成功');
        }
        fetchTemplates();
      } else if (modalType === 'campaign') {
        if (editingItem) {
          await emailsApi.campaigns.update((editingItem as { id: string }).id, values);
          message.success('活动更新成功');
        } else {
          await emailsApi.campaigns.create(values);
          message.success('活动创建成功');
        }
        fetchCampaigns();
      }
      setModalVisible(false);
      setEditingItem(null);
      form.resetFields();
    } catch (error) {
      message.error('操作失败');
    }
  };

  const handleDelete = async (type: string, id: string) => {
    try {
      if (type === 'account') await emailsApi.accounts.delete(id);
      else if (type === 'template') await emailsApi.templates.delete(id);
      else if (type === 'campaign') await emailsApi.campaigns.delete(id);
      else if (type === 'sequence') await emailsApi.sequences.delete(id);
      message.success('删除成功');
      if (type === 'account') fetchAccounts();
      else if (type === 'template') fetchTemplates();
      else if (type === 'campaign') fetchCampaigns();
      else if (type === 'sequence') fetchSequences();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const handleSendCampaign = async (id: string) => {
    try {
      await emailsApi.campaigns.send(id);
      message.success('发送任务已启动');
      fetchCampaigns();
    } catch (error) {
      message.error('发送失败');
    }
  };

  const openModal = (type: 'account' | 'template' | 'campaign', item?: unknown) => {
    setModalType(type);
    if (item) {
      setEditingItem(item);
      form.setFieldsValue(item);
    } else {
      setEditingItem(null);
      form.resetFields();
    }
    setModalVisible(true);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">邮件营销</h1>

      <Tabs activeKey={activeTab} onChange={setActiveTab} className="mb-6">
        <Tabs.TabPane tab="邮件活动" key="campaigns" />
        <Tabs.TabPane tab="邮件模板" key="templates" />
        <Tabs.TabPane tab="邮箱账户" key="accounts" />
        <Tabs.TabPane tab="邮件序列" key="sequences" />
        <Tabs.TabPane tab="发送记录" key="records" />
      </Tabs>

      {activeTab === 'campaigns' && (
        <Card title="邮件活动" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('campaign')}>创建活动</Button>}>
          <Table
            columns={[
              { title: '活动名称', dataIndex: 'name', key: 'name' },
              { title: '模板', dataIndex: 'templateName', key: 'templateName' },
              { title: '发送数量', dataIndex: 'sentCount', key: 'sentCount' },
              { title: '打开率', dataIndex: 'openRate', key: 'openRate', render: (v: number) => `${v}%` },
              { title: '回复率', dataIndex: 'replyRate', key: 'replyRate', render: (v: number) => `${v}%` },
              {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (status: string) => (
                  <Tag color={status === 'running' ? 'blue' : status === 'completed' ? 'green' : 'default'}>
                    {getStatusText(status)}
                  </Tag>
                ),
              },
              { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', render: formatDate },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string; status: string }) => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" onClick={() => openModal('campaign', record)} />
                    {record.status !== 'running' && (
                      <Button icon={<SendOutlined />} size="small" type="primary" onClick={() => handleSendCampaign(record.id)} />
                    )}
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('campaign', record.id)} />
                  </div>
                ),
              },
            ]}
            dataSource={campaigns as { id: string; status: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'templates' && (
        <Card title="邮件模板" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('template')}>创建模板</Button>}>
          <Table
            columns={[
              { title: '模板名称', dataIndex: 'name', key: 'name' },
              { title: '主题', dataIndex: 'subject', key: 'subject' },
              { title: '类型', dataIndex: 'type', key: 'type', render: (t: string) => (
                <Tag>{t === 'cold' ? '开发信' : t === 'follow-up' ? '跟进信' : t === 'quote' ? '报价信' : '自定义'}</Tag>
              )},
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string }) => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" onClick={() => openModal('template', record)} />
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('template', record.id)} />
                  </div>
                ),
              },
            ]}
            dataSource={templates as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'accounts' && (
        <Card title="邮箱账户" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('account')}>添加账户</Button>}>
          <Table
            columns={[
              { title: '邮箱地址', dataIndex: 'smtpUser', key: 'smtpUser' },
              { title: 'SMTP服务器', dataIndex: 'smtpHost', key: 'smtpHost' },
              { title: '端口', dataIndex: 'smtpPort', key: 'smtpPort' },
              { title: '加密方式', dataIndex: 'encryptionType', key: 'encryptionType', render: (t: string) => t.toUpperCase() },
              { title: '日限额', dataIndex: 'dailyLimit', key: 'dailyLimit' },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string }) => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" onClick={() => openModal('account', record)} />
                    <Button size="small" onClick={() => emailsApi.accounts.test(record.id).then(() => message.success('测试成功'))}>测试</Button>
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('account', record.id)} />
                  </div>
                ),
              },
            ]}
            dataSource={accounts as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'sequences' && (
        <Card title="邮件序列" extra={<Button icon={<PlusOutlined />}>创建序列</Button>}>
          <Table
            columns={[
              { title: '序列名称', dataIndex: 'name', key: 'name' },
              { title: '触发条件', dataIndex: 'triggerCondition', key: 'triggerCondition' },
              { title: '步骤数', dataIndex: 'stepsCount', key: 'stepsCount' },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string }) => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" />
                    <Button icon={<PlayCircleOutlined />} size="small" type="primary" />
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('sequence', record.id)} />
                  </div>
                ),
              },
            ]}
            dataSource={sequences as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'records' && (
        <Card title="发送记录">
          <Table
            columns={[
              { title: '活动名称', dataIndex: 'campaignName', key: 'campaignName' },
              { title: '收件人', dataIndex: 'leadEmail', key: 'leadEmail' },
              { title: '主题', dataIndex: 'subject', key: 'subject' },
              {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (status: string) => (
                  <Tag color={
                    status === 'sent' ? 'blue' :
                    status === 'opened' ? 'green' :
                    status === 'replied' ? 'purple' :
                    status === 'failed' ? 'red' : 'default'
                  }>
                    {getStatusText(status)}
                  </Tag>
                ),
              },
              { title: '发送时间', dataIndex: 'sentAt', key: 'sentAt', render: formatDate },
              { title: '打开时间', dataIndex: 'openedAt', key: 'openedAt', render: (d: string) => d ? formatDate(d) : '-' },
              { title: '回复时间', dataIndex: 'repliedAt', key: 'repliedAt', render: (d: string) => d ? formatDate(d) : '-' },
            ]}
            dataSource={records as { id: string }[]}
            rowKey="id"
            pagination={{ pageSize: 20 }}
          />
        </Card>
      )}

      <Modal
        title={modalType === 'account' ? (editingItem ? '编辑邮箱账户' : '添加邮箱账户') :
               modalType === 'template' ? (editingItem ? '编辑邮件模板' : '创建邮件模板') :
               (editingItem ? '编辑邮件活动' : '创建邮件活动')}
        visible={modalVisible}
        onCancel={() => { setModalVisible(false); setEditingItem(null); }}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={handleSubmit}>
          {modalType === 'account' && (
            <>
              <Form.Item name="smtpHost" label="SMTP服务器" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="smtpPort" label="SMTP端口" rules={[{ required: true }]}>
                <InputNumber />
              </Form.Item>
              <Form.Item name="smtpUser" label="邮箱地址" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="smtpPassword" label="密码" rules={[{ required: true }]}>
                <Input.Password />
              </Form.Item>
              <Form.Item name="encryptionType" label="加密方式" rules={[{ required: true }]}>
                <Select>
                  <Option value="ssl">SSL</Option>
                  <Option value="tls">TLS</Option>
                  <Option value="none">无</Option>
                </Select>
              </Form.Item>
              <Form.Item name="dailyLimit" label="日发送限额">
                <InputNumber />
              </Form.Item>
            </>
          )}
          {modalType === 'template' && (
            <>
              <Form.Item name="name" label="模板名称" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="subject" label="邮件主题" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="type" label="模板类型" rules={[{ required: true }]}>
                <Select>
                  <Option value="cold">开发信</Option>
                  <Option value="follow-up">跟进信</Option>
                  <Option value="quote">报价信</Option>
                  <Option value="custom">自定义</Option>
                </Select>
              </Form.Item>
              <Form.Item name="body" label="邮件内容" rules={[{ required: true }]}>
                <Input.TextArea rows={6} />
              </Form.Item>
            </>
          )}
          {modalType === 'campaign' && (
            <>
              <Form.Item name="name" label="活动名称" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="templateId" label="选择模板" rules={[{ required: true }]}>
                <Select>
                  {(templates as { id: string; name: string }[]).map((t) => (
                    <Option key={t.id} value={t.id}>{t.name}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name="leadIds" label="选择线索">
                <Select mode="multiple" placeholder="选择线索" />
              </Form.Item>
              <Form.Item name="sendTime" label="发送时间">
                <Input type="datetime-local" />
              </Form.Item>
            </>
          )}
          <Form.Item>
            <Button type="primary" htmlType="submit">保存</Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};