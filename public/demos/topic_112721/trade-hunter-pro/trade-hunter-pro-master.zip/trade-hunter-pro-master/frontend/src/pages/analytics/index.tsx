import { useState, useEffect } from 'react';
import { Card, Tabs, Row, Col, Statistic, Progress, Table, Button, message } from 'antd';
import {
  UpOutlined,
  DownOutlined,
  BarChartOutlined,
  PieChartOutlined,
} from '@ant-design/icons';
import { analyticsApi } from '@/services/api';

interface ChannelData {
  name: string;
  leads: number;
  conversionRate: number;
  roi: number;
}

interface FunnelData {
  stage: string;
  count: number;
  percent: number;
}

export const Analytics = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [channels, setChannels] = useState<ChannelData[]>([]);
  const [funnel, setFunnelData] = useState<FunnelData[]>([]);
  const [reports, setReports] = useState<unknown[]>([]);

  useEffect(() => {
    fetchChannels();
    fetchFunnel();
  }, []);

  const fetchChannels = async () => {
    try {
      const response = await analyticsApi.channels();
      if (response.data.success) {
        setChannels(response.data.data as ChannelData[]);
      }
    } catch (error) {
      message.error('获取渠道数据失败');
    }
  };

  const fetchFunnel = async () => {
    try {
      const response = await analyticsApi.funnel();
      if (response.data.success) {
        setFunnelData(response.data.data as FunnelData[]);
      }
    } catch (error) {
      message.error('获取漏斗数据失败');
    }
  };

  const fetchReport = async (type: string) => {
    try {
      let response;
      if (type === 'daily') response = await analyticsApi.reports.daily();
      else if (type === 'weekly') response = await analyticsApi.reports.weekly();
      else response = await analyticsApi.reports.monthly();
      if ((response.data as { success: boolean }).success) {
        setReports(((response.data as { data: unknown[] }).data) || []);
      }
    } catch (error) {
      message.error('获取报表失败');
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">数据分析</h1>

      <Tabs activeKey={activeTab} onChange={setActiveTab} className="mb-6">
        <Tabs.TabPane tab="数据概览" key="dashboard" />
        <Tabs.TabPane tab="渠道分析" key="channels" />
        <Tabs.TabPane tab="转化漏斗" key="funnel" />
        <Tabs.TabPane tab="报表中心" key="reports" />
      </Tabs>

      {activeTab === 'dashboard' && (
        <div>
          <Row gutter={[16, 16]} className="mb-8">
            <Col span={6}>
              <Card>
                <Statistic
                  title="本月新增线索"
                  value={1256}
                  prefix={<UpOutlined className="text-green-500" />}
                  suffix="+12.5%"
                  valueStyle={{ color: '#52c41a' }}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card>
                <Statistic
                  title="邮件发送量"
                  value={8520}
                  prefix={<BarChartOutlined className="text-blue-500" />}
                  suffix="+8.3%"
                  valueStyle={{ color: '#1890ff' }}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card>
                <Statistic
                  title="平均打开率"
                  value={24.8}
                  prefix={<PieChartOutlined className="text-gold-500" />}
                  suffix="%"
                  valueStyle={{ color: '#faad14' }}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card>
                <Statistic
                  title="平均回复率"
                  value={5.2}
                  prefix={<UpOutlined className="text-purple-500" />}
                  suffix="%"
                  valueStyle={{ color: '#722ed1' }}
                />
              </Card>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            <Col span={12}>
              <Card title="线索来源分布">
                <div className="space-y-4">
                  {[
                    { name: 'Google搜索', value: 45, color: '#4285F4' },
                    { name: 'LinkedIn', value: 25, color: '#0077B5' },
                    { name: '海关数据', value: 15, color: '#DB4437' },
                    { name: '黄页网站', value: 10, color: '#F4B400' },
                    { name: '其他', value: 5, color: '#9E9E9E' },
                  ].map((item) => (
                    <div key={item.name}>
                      <div className="flex justify-between mb-1">
                        <span>{item.name}</span>
                        <span>{item.value}%</span>
                      </div>
                      <Progress percent={item.value} strokeColor={item.color} />
                    </div>
                  ))}
                </div>
              </Card>
            </Col>
            <Col span={12}>
              <Card title="转化趋势">
                <div className="flex items-center justify-center h-48">
                  <BarChartOutlined className="text-6xl text-gray-300" />
                </div>
                <p className="text-center text-gray-400">图表功能开发中...</p>
              </Card>
            </Col>
          </Row>
        </div>
      )}

      {activeTab === 'channels' && (
        <Card title="渠道效果分析">
          <Table
            columns={[
              { title: '渠道名称', dataIndex: 'name', key: 'name' },
              { title: '线索数量', dataIndex: 'leads', key: 'leads' },
              {
                title: '转化率',
                dataIndex: 'conversionRate',
                key: 'conversionRate',
                render: (rate: number) => (
                  <div className="flex items-center gap-2">
                    <Progress percent={rate} size="small" />
                    <span>{rate}%</span>
                  </div>
                ),
              },
              {
                title: 'ROI',
                dataIndex: 'roi',
                key: 'roi',
                render: (roi: number) => (
                  <span className={roi > 0 ? 'text-green-500' : 'text-red-500'}>
                    {roi > 0 ? <UpOutlined /> : <DownOutlined />}
                    {roi}%
                  </span>
                ),
              },
              {
                title: '操作',
                key: 'action',
                render: () => <Button size="small">查看详情</Button>,
              },
            ]}
            dataSource={channels}
            rowKey="name"
          />
        </Card>
      )}

      {activeTab === 'funnel' && (
        <Card title="转化漏斗分析">
          <div className="space-y-6">
            {funnel.length > 0 ? funnel.map((item) => (
              <div key={item.stage}>
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{item.stage}</span>
                  <span>{item.count} ({item.percent}%)</span>
                </div>
                <div className="bg-gray-200 rounded-full h-8">
                  <div
                    className="h-8 rounded-full flex items-center justify-end pr-4 transition-all"
                    style={{
                      width: `${item.percent}%`,
                      background: `linear-gradient(to right, #1890ff, #722ed1)`,
                    }}
                  >
                    <span className="text-white text-sm">{item.count}</span>
                  </div>
                </div>
              </div>
            )) : (
              <div className="space-y-6">
                {[
                  { stage: '线索获取', count: 1000, percent: 100 },
                  { stage: '邮件发送', count: 800, percent: 80 },
                  { stage: '邮件打开', count: 200, percent: 20 },
                  { stage: '客户回复', count: 50, percent: 5 },
                  { stage: '商机创建', count: 25, percent: 2.5 },
                  { stage: '成交转化', count: 10, percent: 1 },
                ].map((item) => (
                  <div key={item.stage}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{item.stage}</span>
                      <span>{item.count} ({item.percent}%)</span>
                    </div>
                    <div className="bg-gray-200 rounded-full h-8">
                      <div
                        className="h-8 rounded-full flex items-center justify-end pr-4 transition-all"
                        style={{
                          width: `${item.percent}%`,
                          background: `linear-gradient(to right, #1890ff, #722ed1)`,
                        }}
                      >
                        <span className="text-white text-sm">{item.count}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      )}

      {activeTab === 'reports' && (
        <div>
          <div className="flex gap-4 mb-4">
            <Button type="primary" onClick={() => fetchReport('daily')}>日报</Button>
            <Button onClick={() => fetchReport('weekly')}>周报</Button>
            <Button onClick={() => fetchReport('monthly')}>月报</Button>
          </div>
          <Card title="报表数据">
            <Table
              columns={[
                { title: '日期', dataIndex: 'date', key: 'date' },
                { title: '新增线索', dataIndex: 'newLeads', key: 'newLeads' },
                { title: '邮件发送', dataIndex: 'emailsSent', key: 'emailsSent' },
                { title: '打开率', dataIndex: 'openRate', key: 'openRate', render: (v: number) => `${v}%` },
                { title: '回复率', dataIndex: 'replyRate', key: 'replyRate', render: (v: number) => `${v}%` },
                { title: '新增商机', dataIndex: 'newOpportunities', key: 'newOpportunities' },
                { title: '成交金额', dataIndex: 'revenue', key: 'revenue' },
              ]}
              dataSource={reports.length > 0 ? reports : [
                { date: '2026-07-01', newLeads: 150, emailsSent: 500, openRate: 25, replyRate: 5, newOpportunities: 10, revenue: 5000 },
                { date: '2026-07-02', newLeads: 180, emailsSent: 600, openRate: 23, replyRate: 4.5, newOpportunities: 8, revenue: 3000 },
                { date: '2026-07-03', newLeads: 120, emailsSent: 400, openRate: 28, replyRate: 6, newOpportunities: 12, revenue: 8000 },
              ]}
              rowKey="date"
            />
          </Card>
        </div>
      )}
    </div>
  );
};