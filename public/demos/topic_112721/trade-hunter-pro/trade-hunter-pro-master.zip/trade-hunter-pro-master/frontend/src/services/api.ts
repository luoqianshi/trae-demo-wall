import axios from 'axios';
import type { ApiResponse, PaginatedResponse } from '@/types';

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  login: (data: { email: string; password: string }) =>
    api.post<ApiResponse<{ token: string; user: unknown }>>('/auth/login', data),
  register: (data: { email: string; password: string; name: string; companyName: string }) =>
    api.post<ApiResponse>('/auth/register', data),
  logout: () => api.post<ApiResponse>('/auth/logout'),
  profile: () => api.get<ApiResponse<unknown>>('/auth/profile'),
};

export const usersApi = {
  list: (params?: { page?: number; pageSize?: number }) =>
    api.get<PaginatedResponse<unknown>>('/users', { params }),
  get: (id: string) => api.get<ApiResponse<unknown>>(`/users/${id}`),
  update: (id: string, data: unknown) => api.put<ApiResponse>(`/users/${id}`, data),
  delete: (id: string) => api.delete<ApiResponse>(`/users/${id}`),
};

export const marketApi = {
  config: {
    get: () => api.get<ApiResponse<unknown>>('/market/config'),
    update: (data: unknown) => api.put<ApiResponse>('/market/config', data),
  },
  countries: {
    list: () => api.get<ApiResponse<unknown[]>>('/market/countries'),
    create: (data: unknown) => api.post<ApiResponse>('/market/countries', data),
    delete: (id: string) => api.delete<ApiResponse>(`/market/countries/${id}`),
  },
  products: {
    list: (params?: { page?: number; pageSize?: number }) =>
      api.get<ApiResponse<PaginatedResponse<unknown>>>('/market/products', { params }),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/market/products/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/market/products', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/market/products/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/market/products/${id}`),
  },
  keywords: {
    list: () => api.get<ApiResponse<unknown[]>>('/market/keywords'),
    create: (data: unknown) => api.post<ApiResponse>('/market/keywords', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/market/keywords/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/market/keywords/${id}`),
  },
};

export const leadsApi = {
  list: (params?: { page?: number; pageSize?: number; status?: string; grade?: string; keyword?: string }) =>
    api.get<ApiResponse<PaginatedResponse<unknown>>>('/leads', { params }),
  get: (id: string) => api.get<ApiResponse<unknown>>(`/leads/${id}`),
  create: (data: unknown) => api.post<ApiResponse>('/leads', data),
  update: (id: string, data: unknown) => api.put<ApiResponse>(`/leads/${id}`, data),
  delete: (id: string) => api.delete<ApiResponse>(`/leads/${id}`),
  import: (file: FormData) => api.post<ApiResponse>('/leads/import', file, { headers: { 'Content-Type': 'multipart/form-data' } }),
  export: (params?: { status?: string }) => api.get('/leads/export', { params, responseType: 'blob' }),
};

export const emailsApi = {
  accounts: {
    list: () => api.get<ApiResponse<unknown[]>>('/emails/accounts'),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/emails/accounts/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/emails/accounts', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/emails/accounts/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/emails/accounts/${id}`),
    test: (id: string) => api.post<ApiResponse>(`/emails/accounts/${id}/test`),
  },
  templates: {
    list: () => api.get<ApiResponse<unknown[]>>('/emails/templates'),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/emails/templates/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/emails/templates', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/emails/templates/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/emails/templates/${id}`),
  },
  campaigns: {
    list: (params?: { page?: number; pageSize?: number }) =>
      api.get<PaginatedResponse<unknown>>('/emails/campaigns', { params }),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/emails/campaigns/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/emails/campaigns', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/emails/campaigns/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/emails/campaigns/${id}`),
    send: (id: string) => api.post<ApiResponse>(`/emails/campaigns/${id}/send`),
  },
  records: {
    list: (params?: { page?: number; pageSize?: number; campaignId?: string }) =>
      api.get<PaginatedResponse<unknown>>('/emails/records', { params }),
  },
  sequences: {
    list: () => api.get<ApiResponse<unknown[]>>('/emails/sequences'),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/emails/sequences/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/emails/sequences', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/emails/sequences/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/emails/sequences/${id}`),
  },
};

export const customersApi = {
  list: (params?: { page?: number; pageSize?: number }) =>
    api.get<PaginatedResponse<unknown>>('/customers', { params }),
  get: (id: string) => api.get<ApiResponse<unknown>>(`/customers/${id}`),
  update: (id: string, data: unknown) => api.put<ApiResponse>(`/customers/${id}`, data),
  tags: {
    list: () => api.get<ApiResponse<unknown[]>>('/customers/tags'),
    create: (data: unknown) => api.post<ApiResponse>('/customers/tags', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/customers/tags/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/customers/tags/${id}`),
  },
  opportunities: {
    list: (params?: { page?: number; pageSize?: number }) =>
      api.get<PaginatedResponse<unknown>>('/customers/opportunities', { params }),
    get: (id: string) => api.get<ApiResponse<unknown>>(`/customers/opportunities/${id}`),
    create: (data: unknown) => api.post<ApiResponse>('/customers/opportunities', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/customers/opportunities/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/customers/opportunities/${id}`),
  },
  followups: {
    list: (params?: { leadId?: string }) => api.get<ApiResponse<unknown[]>>('/customers/followups', { params }),
    create: (data: unknown) => api.post<ApiResponse>('/customers/followups', data),
    update: (id: string, data: unknown) => api.put<ApiResponse>(`/customers/followups/${id}`, data),
    delete: (id: string) => api.delete<ApiResponse>(`/customers/followups/${id}`),
  },
};

export const mapSearchApi = {
  search: (params: { keyword: string; location: string; radius: number; type?: string; pageToken?: string }) =>
    api.get<ApiResponse<{ results: unknown[]; nextPageToken?: string }>>('/map-search', { params }),
  import: (data: { placeIds: string[] }) =>
    api.post<ApiResponse<{ imported: number; failed: number; duplicates: number }>>('/map-search/import', data),
};

export const analyticsApi = {
  dashboard: () => api.get<ApiResponse<unknown>>('/dashboard/overview'),
  channels: () => api.get<ApiResponse<unknown>>('/dashboard/campaign-stats'),
  funnel: () => api.get<ApiResponse<unknown>>('/dashboard/lead-trend'),
  reports: {
    daily: () => api.get<ApiResponse<unknown>>('/dashboard/overview'),
    weekly: () => api.get<ApiResponse<unknown>>('/dashboard/overview'),
    monthly: () => api.get<ApiResponse<unknown>>('/dashboard/overview'),
  },
};

export const tasksApi = {
  list: (params?: { page?: number; pageSize?: number; status?: string }) =>
    api.get<PaginatedResponse<unknown>>('/tasks', { params }),
  get: (id: string) => api.get<ApiResponse<unknown>>(`/tasks/${id}`),
  create: (data: unknown) => api.post<ApiResponse>('/tasks', data),
  update: (id: string, data: unknown) => api.put<ApiResponse>(`/tasks/${id}`, data),
  delete: (id: string) => api.delete<ApiResponse>(`/tasks/${id}`),
  start: (id: string) => api.post<ApiResponse>(`/tasks/${id}/start`),
  pause: (id: string) => api.post<ApiResponse>(`/tasks/${id}/pause`),
  logs: (id: string) => api.get<ApiResponse<unknown[]>>(`/tasks/${id}/logs`),
};

export default api;