export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(value);
};

export const formatPercent = (value: number): string => {
  return `${value.toFixed(1)}%`;
};

export const getStatusText = (status: string): string => {
  const statusMap: Record<string, string> = {
    new: '新线索',
    verified: '已验证',
    qualified: '已筛选',
    contacted: '已联系',
    converted: '已转化',
    rejected: '已拒绝',
    pending: '待处理',
    running: '进行中',
    completed: '已完成',
    failed: '失败',
    draft: '草稿',
    active: '活跃',
    expired: '已过期',
    cancelled: '已取消',
    sent: '已发送',
    delivered: '已送达',
    opened: '已打开',
    clicked: '已点击',
    replied: '已回复',
  };
  return statusMap[status] || status;
};

export const getGradeColor = (grade: string): string => {
  const colorMap: Record<string, string> = {
    A: '#52c41a',
    B: '#faad14',
    C: '#ff4d4f',
  };
  return colorMap[grade] || '#d9d9d9';
};

export const getPriorityColor = (priority: string): string => {
  const colorMap: Record<string, string> = {
    high: '#ff4d4f',
    medium: '#faad14',
    low: '#52c41a',
  };
  return colorMap[priority] || '#d9d9d9';
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const debounce = <T extends (...args: unknown[]) => void>(fn: T, delay: number): T => {
  let timer: ReturnType<typeof setTimeout>;
  return ((...args: unknown[]) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  }) as T;
};

export const throttle = <T extends (...args: unknown[]) => void>(fn: T, limit: number): T => {
  let inThrottle: boolean;
  return ((...args: unknown[]) => {
    if (!inThrottle) {
      fn(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  }) as T;
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};