import { useState } from 'react';
import { Form, Input, Button, Card, message, Typography, Divider } from 'antd';
import { UserOutlined, LockOutlined, MailOutlined, PhoneOutlined, BuildOutlined } from '@ant-design/icons';
import { useNavigate, Link } from 'react-router-dom';
import { authApi } from '@/services/api';

const { Title, Text } = Typography;

export const Register = () => {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (values: {
    email: string;
    password: string;
    confirmPassword: string;
    name: string;
    companyName: string;
    phone?: string;
  }) => {
    if (values.password !== values.confirmPassword) {
      message.error('两次输入的密码不一致');
      return;
    }

    setLoading(true);
    try {
      const response = await authApi.register({
        email: values.email,
        password: values.password,
        name: values.name,
        companyName: values.companyName,
      });
      if (response.data.success) {
        message.success('注册成功，请登录');
        navigate('/login');
      } else {
        message.error(response.data.message);
      }
    } catch (error) {
      message.error('注册失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 via-white to-gold-50 p-4">
      <Card className="w-full max-w-lg shadow-xl">
        <div className="text-center mb-6">
          <Title level={2} className="text-primary-600">TradeHunter Pro</Title>
          <Text className="text-gray-500">外贸智能获客系统</Text>
        </div>

        <Form
          name="register"
          onFinish={handleSubmit}
          layout="vertical"
          size="large"
        >
          <Form.Item
            name="name"
            label="姓名"
            rules={[{ required: true, message: '请输入姓名' }]}
          >
            <Input prefix={<UserOutlined />} placeholder="请输入姓名" />
          </Form.Item>

          <Form.Item
            name="email"
            label="邮箱"
            rules={[
              { required: true, message: '请输入邮箱' },
              { type: 'email', message: '请输入有效的邮箱' },
            ]}
          >
            <Input prefix={<MailOutlined />} placeholder="请输入邮箱" />
          </Form.Item>

          <Form.Item
            name="phone"
            label="手机号"
          >
            <Input prefix={<PhoneOutlined />} placeholder="请输入手机号（选填）" />
          </Form.Item>

          <Form.Item
            name="companyName"
            label="公司名称"
            rules={[{ required: true, message: '请输入公司名称' }]}
          >
            <Input prefix={<BuildOutlined />} placeholder="请输入公司名称" />
          </Form.Item>

          <Form.Item
            name="password"
            label="密码"
            rules={[
              { required: true, message: '请输入密码' },
              { min: 6, message: '密码长度至少6位' },
            ]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="请输入密码" />
          </Form.Item>

          <Form.Item
            name="confirmPassword"
            label="确认密码"
            rules={[{ required: true, message: '请确认密码' }]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="请确认密码" />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading} className="w-full">
              注册
            </Button>
          </Form.Item>
        </Form>

        <Divider plain>或者</Divider>

        <div className="flex gap-4">
          <Button className="flex-1" icon={<UserOutlined />}>
            Google注册
          </Button>
          <Button className="flex-1">
            LinkedIn注册
          </Button>
        </div>

        <div className="text-center mt-4">
          <Text>已有账号? </Text>
          <Link to="/login" className="text-primary-600 font-medium">立即登录</Link>
        </div>
      </Card>
    </div>
  );
};