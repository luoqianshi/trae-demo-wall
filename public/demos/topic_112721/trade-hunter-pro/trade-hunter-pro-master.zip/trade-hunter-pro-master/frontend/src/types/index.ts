export interface User {
  id: string;
  email: string;
  phone?: string;
  name: string;
  avatar?: string;
  role: string;
  tenantId: string;
  createdAt: string;
}

export interface Tenant {
  id: string;
  name: string;
  industry?: string;
  website?: string;
  description?: string;
  createdAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  planType: 'lite' | 'pro' | 'enterprise';
  status: 'active' | 'expired' | 'cancelled';
  startDate: string;
  endDate: string;
}

export interface MarketConfig {
  id: string;
  tenantId: string;
  targetRegion: string;
  languages: string[];
  customerType: string;
  customerSize?: string;
}

export interface TargetCountry {
  id: string;
  configId: string;
  countryCode: string;
  countryName: string;
}

export interface Product {
  id: string;
  tenantId: string;
  name: string;
  category: string;
  subCategory: string;
  priceMin: number;
  priceMax: number;
  moq: number;
  description?: string;
  createdAt: string;
}

export interface Keyword {
  id: string;
  tenantId: string;
  keyword: string;
  type: 'include' | 'exclude';
  weight: number;
}

export interface Lead {
  id: string;
  tenantId: string;
  companyName: string;
  companyDomain?: string;
  email: string;
  phone?: string;
  address?: string;
  website?: string;
  placeId?: string;
  latitude?: number;
  longitude?: number;
  googleRating?: number;
  googleReviewCount?: number;
  contactPerson?: string;
  contactTitle?: string;
  source: string;
  status: 'new' | 'verified' | 'qualified' | 'contacted' | 'converted' | 'rejected';
  score: number;
  grade: 'A' | 'B' | 'C';
  createdAt: string;
}

export interface GooglePlace {
  placeId: string;
  name: string;
  address: string;
  phone?: string;
  website?: string;
  rating?: number;
  reviewCount?: number;
  latitude: number;
  longitude: number;
  types: string[];
}

export interface Tag {
  id: string;
  tenantId: string;
  name: string;
  color: string;
}

export interface EmailAccount {
  id: string;
  tenantId: string;
  smtpHost: string;
  smtpPort: number;
  smtpUser: string;
  encryptionType: 'ssl' | 'tls' | 'none';
  dailyLimit: number;
}

export interface EmailTemplate {
  id: string;
  tenantId: string;
  name: string;
  subject: string;
  body: string;
  type: 'cold' | 'follow-up' | 'quote' | 'custom';
  variables: string[];
}

export interface EmailCampaign {
  id: string;
  tenantId: string;
  name: string;
  templateId: string;
  status: 'draft' | 'running' | 'completed';
  sentCount: number;
  openedCount: number;
  clickedCount: number;
  repliedCount: number;
  createdAt: string;
}

export interface EmailRecord {
  id: string;
  campaignId: string;
  leadId: string;
  emailAccountId: string;
  subject: string;
  body: string;
  sentAt?: string;
  openedAt?: string;
  clickedAt?: string;
  repliedAt?: string;
  status: 'pending' | 'sent' | 'delivered' | 'opened' | 'clicked' | 'replied' | 'failed';
}

export interface Opportunity {
  id: string;
  tenantId: string;
  leadId: string;
  name: string;
  stage: string;
  amount?: number;
  probability?: number;
  expectedCloseDate?: string;
  createdAt: string;
}

export interface FollowUpRecord {
  id: string;
  leadId: string;
  type: 'call' | 'email' | 'meeting' | 'note';
  content: string;
  result?: string;
  createdAt: string;
  createdBy: string;
}

export interface Task {
  id: string;
  tenantId: string;
  type: 'mining' | 'cleaning' | 'email-sending';
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  priority: 'low' | 'medium' | 'high';
  progress: number;
  scheduledAt?: string;
  startedAt?: string;
  completedAt?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  phone?: string;
  companyName: string;
  industry?: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}