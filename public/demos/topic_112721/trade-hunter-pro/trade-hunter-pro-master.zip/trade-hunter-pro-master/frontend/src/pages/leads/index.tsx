import { useState, useEffect, useMemo } from 'react';
import { Card, Table, Button, Tag, Input, Select, message, Modal, Progress, Form, Space } from 'antd';
import { PlusOutlined, DownloadOutlined, UploadOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { leadsApi } from '@/services/api';
import { formatDate, getStatusText, getGradeColor } from '@/utils';
import type { Lead } from '@/types';

const { Option } = Select;

const STATUS_COLOR_MAP: Record<string, string> = {
  new: 'blue',
  verified: 'green',
  qualified: 'gold',
  contacted: 'purple',
  converted: 'success',
  rejected: 'default',
};

const SOURCE_OPTIONS = [
  { value: 'website', label: '官网' },
  { value: 'social_media', label: '社交媒体' },
  { value: 'exhibition', label: '展会' },
  { value: 'referral', label: '推荐' },
  { value: 'cold_call', label: '陌拜' },
  { value: 'email', label: '邮件营销' },
];

export const Leads = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [gradeFilter, setGradeFilter] = useState('');
  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
  const [leadModalVisible, setLeadModalVisible] = useState(false);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });
  const [form] = Form.useForm();

  useEffect(() => {
    fetchLeads(pagination.current, pagination.pageSize);
  }, [statusFilter, gradeFilter]);

  const fetchLeads = async (page: number, pageSize: number) => {
    setLoading(true);
    try {
      const params: Record<string, unknown> = { page, pageSize };
      if (statusFilter) params.status = statusFilter;
      if (gradeFilter) params.grade = gradeFilter;
      if (searchText) params.keyword = searchText;
      const response = await leadsApi.list(params);
      if (response.data.success) {
        setLeads((response.data.data?.data as Lead[]) || []);
        setPagination({
          current: response.data.data?.page || page,
          pageSize: response.data.data?.pageSize || pageSize,
          total: response.data.data?.total || 0,
        });
      }
    } catch {
      message.error('获取线索失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setPagination({ ...pagination, current: 1 });
    fetchLeads(1, pagination.pageSize);
  };

  const handleBatchDelete = async () => {
    try {
      for (const id of selectedLeads) {
        await leadsApi.delete(id);
      }
      message.success('批量删除成功');
      setSelectedLeads([]);
      fetchLeads(pagination.current, pagination.pageSize);
    } catch {
      message.error('批量删除失败');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await leadsApi.delete(id);
      message.success('删除成功');
      fetchLeads(pagination.current, pagination.pageSize);
    } catch {
      message.error('删除失败');
    }
  };

  const handleExport = () => {
    leadsApi.export({ status: statusFilter || undefined }).then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'text/csv; charset=utf-8' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'leads.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    }).catch(() => {
      message.error('导出失败');
    });
  };

  const handleAddLead = () => {
    setCurrentLead(null);
    setIsEditing(true);
    form.resetFields();
    setLeadModalVisible(true);
  };

  const handleSaveLead = async (values: Record<string, unknown>) => {
    try {
      if (currentLead) {
        await leadsApi.update(currentLead.id, values);
        message.success('更新成功');
      } else {
        await leadsApi.create(values);
        message.success('创建成功');
      }
      setLeadModalVisible(false);
      setCurrentLead(null);
      form.resetFields();
      fetchLeads(pagination.current, pagination.pageSize);
    } catch {
      message.error(currentLead ? '更新失败' : '创建失败');
    }
  };

  const columns = useMemo(() => [
    {
      title: '选择',
      key: 'selection',
      render: (_: unknown, record: Lead) => (
        <input
          type="checkbox"
          checked={selectedLeads.includes(record.id)}
          onChange={(e) => {
            if (e.target.checked) {
              setSelectedLeads([...selectedLeads, record.id]);
            } else {
              setSelectedLeads(selectedLeads.filter((id) => id !== record.id));
            }
          }}
        />
      ),
    },
    { title: '公司名称', dataIndex: 'companyName', key: 'companyName' },
    { title: '邮箱', dataIndex: 'email', key: 'email' },
    { title: '联系人', dataIndex: 'contactPerson', key: 'contactPerson' },
    { title: '职位', dataIndex: 'contactTitle', key: 'contactTitle' },
    {
      title: '来源',
      dataIndex: 'source',
      key: 'source',
      render: (source: string) => SOURCE_OPTIONS.find((s) => s.value === source)?.label || source,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={STATUS_COLOR_MAP[status] || 'default'}>{getStatusText(status)}</Tag>
      ),
    },
    {
      title: '评分',
      dataIndex: 'score',
      key: 'score',
      render: (_: unknown, record: Lead) => (
        <div className="flex items-center gap-2">
          <span style={{ color: getGradeColor(record.grade), fontWeight: 'bold' }}>{record.grade}</span>
          <Progress percent={record.score} size="small" strokeColor={getGradeColor(record.grade)} />
        </div>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: formatDate,
    },
    {
      title: '操作',
      key: 'action',
      render: (_: unknown, record: Lead) => (
        <Space>
          <Button icon={<EditOutlined />} size="small" onClick={() => { setCurrentLead(record); setIsEditing(true); form.setFieldsValue(record); setLeadModalVisible(true); }} />
          <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete(record.id)} />
        </Space>
      ),
    },
  ], [selectedLeads]);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">线索管理</h1>

      <Card className="mb-6">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex-1">
            <Input.Search
              placeholder="搜索公司名称或邮箱"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              onSearch={handleSearch}
              className="w-full max-w-md"
            />
          </div>
          <Select
            placeholder="状态筛选"
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 150 }}
            allowClear
          >
            <Option value="new">新线索</Option>
            <Option value="verified">已验证</Option>
            <Option value="qualified">已筛选</Option>
            <Option value="contacted">已联系</Option>
            <Option value="converted">已转化</Option>
            <Option value="rejected">已拒绝</Option>
          </Select>
          <Select
            placeholder="评分筛选"
            value={gradeFilter}
            onChange={setGradeFilter}
            style={{ width: 100 }}
            allowClear
          >
            <Option value="A">A级</Option>
            <Option value="B">B级</Option>
            <Option value="C">C级</Option>
          </Select>
          {selectedLeads.length > 0 && (
            <Button danger onClick={handleBatchDelete}>批量删除 ({selectedLeads.length})</Button>
          )}
          <Button icon={<UploadOutlined />}>导入</Button>
          <Button icon={<DownloadOutlined />} onClick={handleExport}>导出</Button>
          <Button type="primary" icon={<PlusOutlined />} onClick={handleAddLead}>添加线索</Button>
        </div>
      </Card>

      <Card title={`线索列表 (${pagination.total})`}>
        <Table
          columns={columns}
          dataSource={leads}
          rowKey="id"
          loading={loading}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            onChange: (page, pageSize) => fetchLeads(page, pageSize || 10),
          }}
        />
      </Card>

      <Modal
        title={currentLead ? (isEditing ? '编辑线索' : '线索详情') : '添加线索'}
        open={leadModalVisible}
        onCancel={() => { setLeadModalVisible(false); setCurrentLead(null); }}
        footer={null}
        width={600}
      >
        {isEditing ? (
          <Form form={form} layout="vertical" onFinish={handleSaveLead}>
            <Form.Item name="companyName" label="公司名称" rules={[{ required: true, message: '请输入公司名称' }]}>
              <Input />
            </Form.Item>
            <Form.Item name="companyDomain" label="公司域名">
              <Input />
            </Form.Item>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="email" label="邮箱" rules={[{ required: true, message: '请输入邮箱' }, { type: 'email', message: '请输入有效的邮箱' }]}>
                <Input />
              </Form.Item>
              <Form.Item name="phone" label="电话">
                <Input />
              </Form.Item>
              <Form.Item name="contactPerson" label="联系人">
                <Input />
              </Form.Item>
              <Form.Item name="contactTitle" label="职位">
                <Input />
              </Form.Item>
            </div>
            <Form.Item name="address" label="地址">
              <Input.TextArea rows={3} />
            </Form.Item>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="source" label="来源" rules={[{ required: true, message: '请选择来源' }]}>
                <Select>
                  {SOURCE_OPTIONS.map((s) => (
                    <Option key={s.value} value={s.value}>{s.label}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name="status" label="状态">
                <Select defaultValue="new">
                  <Option value="new">新线索</Option>
                  <Option value="verified">已验证</Option>
                  <Option value="qualified">已筛选</Option>
                  <Option value="contacted">已联系</Option>
                  <Option value="converted">已转化</Option>
                  <Option value="rejected">已拒绝</Option>
                </Select>
              </Form.Item>
            </div>
            <Form.Item>
              <Button type="primary" htmlType="submit" block>保存</Button>
            </Form.Item>
          </Form>
        ) : (
          currentLead && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <h3 className="text-xl font-bold">{currentLead.companyName}</h3>
                <Tag color={getGradeColor(currentLead.grade)}>{currentLead.grade}级</Tag>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-gray-500">邮箱：</span>
                  <span>{currentLead.email}</span>
                </div>
                <div>
                  <span className="text-gray-500">电话：</span>
                  <span>{currentLead.phone || '-'}</span>
                </div>
                <div>
                  <span className="text-gray-500">联系人：</span>
                  <span>{currentLead.contactPerson || '-'}</span>
                </div>
                <div>
                  <span className="text-gray-500">职位：</span>
                  <span>{currentLead.contactTitle || '-'}</span>
                </div>
                <div>
                  <span className="text-gray-500">来源：</span>
                  <span>{SOURCE_OPTIONS.find((s) => s.value === currentLead.source)?.label || currentLead.source}</span>
                </div>
                <div>
                  <span className="text-gray-500">状态：</span>
                  <Tag color={STATUS_COLOR_MAP[currentLead.status] || 'default'}>{getStatusText(currentLead.status)}</Tag>
                </div>
                <div className="col-span-2">
                  <span className="text-gray-500">地址：</span>
                  <span>{currentLead.address || '-'}</span>
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => { setIsEditing(true); }}>编辑</Button>
              </div>
            </div>
          )
        )}
      </Modal>
    </div>
  );
};
