import { useEffect, useState } from 'react';
import { Card, Row, Col, Statistic, Progress, Table, Tag, message } from 'antd';
import {
  UserOutlined,
  MailOutlined,
  EyeOutlined,
  MessageOutlined,
  UpOutlined,
} from '@ant-design/icons';
import { analyticsApi } from '@/services/api';
import { formatDate, getStatusText } from '@/utils';

interface DashboardData {
  totalLeads: number;
  newLeadsToday: number;
  emailsSent: number;
  openRate: number;
  replyRate: number;
  conversionRate: number;
  recentLeads: unknown[];
  recentCampaigns: unknown[];
}

export const Dashboard = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const response = await analyticsApi.dashboard();
      if (response.data.success) {
        setData(response.data.data as DashboardData);
      }
    } catch (error) {
      message.error('获取数据失败');
    } finally {
      setLoading(false);
    }
  };

  const recentLeadsColumns = [
    { title: '公司名称', dataIndex: 'companyName', key: 'companyName' },
    { title: '邮箱', dataIndex: 'email', key: 'email' },
    { title: '来源', dataIndex: 'source', key: 'source' },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'new' ? 'blue' : status === 'verified' ? 'green' : 'default'}>
          {getStatusText(status)}
        </Tag>
      ),
    },
    {
      title: '评分',
      dataIndex: 'score',
      key: 'score',
      render: (score: number) => (
        <div className="flex items-center gap-2">
          <Progress percent={score} size="small" strokeColor={score >= 80 ? '#52c41a' : score >= 60 ? '#faad14' : '#ff4d4f'} />
          <span>{score}</span>
        </div>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => formatDate(date),
    },
  ];

  if (loading) {
    return <div className="flex justify-center items-center h-64">加载中...</div>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">数据看板</h1>

      <Row gutter={[16, 16]} className="mb-8">
        <Col span={6}>
          <Card>
            <Statistic
              title="总线索数"
              value={data?.totalLeads || 0}
              prefix={<UserOutlined className="text-primary-500" />}
              suffix={`+${data?.newLeadsToday || 0} 今日新增`}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="邮件发送"
              value={data?.emailsSent || 0}
              prefix={<MailOutlined className="text-green-500" />}
              suffix="封"
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="打开率"
              value={data?.openRate || 0}
              prefix={<EyeOutlined className="text-gold-500" />}
              suffix="%"
              valueStyle={{ color: '#faad14' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="回复率"
              value={data?.replyRate || 0}
              prefix={<MessageOutlined className="text-purple-500" />}
              suffix="%"
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} className="mb-8">
        <Col span={12}>
          <Card title="转化漏斗" className="h-full">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>线索获取</span>
                  <span>{data?.totalLeads || 0}</span>
                </div>
                <Progress percent={100} strokeColor="#1890ff" />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>邮件发送</span>
                  <span>{data?.emailsSent || 0}</span>
                </div>
                <Progress percent={data?.emailsSent ? Math.round((data.emailsSent / data.totalLeads) * 100) : 0} strokeColor="#52c41a" />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>邮件打开</span>
                  <span>{Math.round((data?.emailsSent || 0) * (data?.openRate || 0) / 100)}</span>
                </div>
                <Progress percent={data?.openRate || 0} strokeColor="#faad14" />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>客户回复</span>
                  <span>{Math.round((data?.emailsSent || 0) * (data?.replyRate || 0) / 100)}</span>
                </div>
                <Progress percent={data?.replyRate || 0} strokeColor="#722ed1" />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>成交转化</span>
                  <span>{Math.round((data?.totalLeads || 0) * (data?.conversionRate || 0) / 100)}</span>
                </div>
                <Progress percent={data?.conversionRate || 0} strokeColor="#ff4d4f" />
              </div>
            </div>
          </Card>
        </Col>
        <Col span={12}>
          <Card title="趋势概览" className="h-full">
            <div className="flex items-center justify-center h-48">
              <UpOutlined className="text-6xl text-gray-300" />
            </div>
            <p className="text-center text-gray-400">图表功能开发中...</p>
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col span={12}>
          <Card title="最近线索" className="h-full">
            <Table
              columns={recentLeadsColumns}
              dataSource={data?.recentLeads || []}
              rowKey="id"
              pagination={{ pageSize: 5 }}
              size="middle"
            />
          </Card>
        </Col>
        <Col span={12}>
          <Card title="最近邮件活动" className="h-full">
            <Table
              columns={[
                { title: '活动名称', dataIndex: 'name', key: 'name' },
                { title: '发送数量', dataIndex: 'sentCount', key: 'sentCount' },
                { title: '打开率', dataIndex: 'openRate', key: 'openRate', render: (v: number) => `${v}%` },
                { title: '回复率', dataIndex: 'replyRate', key: 'replyRate', render: (v: number) => `${v}%` },
                {
                  title: '状态',
                  dataIndex: 'status',
                  key: 'status',
                  render: (status: string) => (
                    <Tag color={status === 'running' ? 'blue' : status === 'completed' ? 'green' : 'default'}>
                      {getStatusText(status)}
                    </Tag>
                  ),
                },
              ]}
              dataSource={data?.recentCampaigns || []}
              rowKey="id"
              pagination={{ pageSize: 5 }}
              size="middle"
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
};