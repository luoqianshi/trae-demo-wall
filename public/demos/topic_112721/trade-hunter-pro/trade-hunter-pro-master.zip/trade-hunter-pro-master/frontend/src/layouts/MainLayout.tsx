import { useState } from 'react';
import {
  Layout,
  Menu,
  Button,
  Avatar,
  Dropdown,
  Tooltip,
} from 'antd';
import {
  DashboardOutlined,
  GlobalOutlined,
  UserOutlined,
  MailOutlined,
  TeamOutlined,
  BarChartOutlined,
  CompassOutlined,
  SettingOutlined,
  LogoutOutlined,
  ProfileOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
} from '@ant-design/icons';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';

const { Header, Sider, Content } = Layout;

const menuItems = [
  { key: '/dashboard', icon: <DashboardOutlined />, label: '数据看板' },
  { key: '/market', icon: <GlobalOutlined />, label: '市场配置' },
  { key: '/map-search', icon: <CompassOutlined />, label: '地图获客' },
  { key: '/leads', icon: <UserOutlined />, label: '线索管理' },
  { key: '/emails', icon: <MailOutlined />, label: '邮件营销' },
  { key: '/customers', icon: <TeamOutlined />, label: '客户管理' },
  { key: '/analytics', icon: <BarChartOutlined />, label: '数据分析' },
];

export const MainLayout = ({ children }: { children: React.ReactNode }) => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const userMenu = (
    <Menu items={[
      { key: 'profile', icon: <ProfileOutlined />, label: '个人信息', onClick: () => navigate('/profile') },
      { key: 'settings', icon: <SettingOutlined />, label: '系统设置', onClick: () => navigate('/settings') },
      { type: 'divider' },
      { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', onClick: handleLogout },
    ]} />
  );

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider trigger={null} collapsible collapsed={collapsed} theme="dark">
        <div className="flex items-center justify-center h-16 bg-gradient-to-r from-primary-500 to-primary-700">
          <span className="text-white font-bold text-lg">TradeHunter</span>
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={({ key }) => navigate(key)}
        />
      </Sider>
      <Layout>
        <Header className="bg-white border-b flex items-center justify-between px-6">
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            className="mr-4"
          />
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-500">欢迎回来，{user?.name}</span>
            <Dropdown overlay={userMenu} placement="bottomRight">
              <Tooltip title="用户菜单">
                <Avatar size="small" icon={<UserOutlined />} />
              </Tooltip>
            </Dropdown>
          </div>
        </Header>
        <Content className="p-6 overflow-auto bg-gray-50">
          {children}
        </Content>
      </Layout>
    </Layout>
  );
};