import { useState, useEffect } from 'react';
import { Card, Tabs, Table, Button, Tag, Input, Select, Modal, Form, message } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { customersApi } from '@/services/api';
import { formatDate, getStatusText } from '@/utils';

const { Option } = Select;

export const Customers = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState<unknown[]>([]);
  const [tags, setTags] = useState<unknown[]>([]);
  const [opportunities, setOpportunities] = useState<unknown[]>([]);
  const [followups, setFollowups] = useState<unknown[]>([]);
  const [form] = Form.useForm();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalType, setModalType] = useState<'tag' | 'opportunity' | 'followup'>('tag');
  const [editingItem, setEditingItem] = useState<unknown | null>(null);

  useEffect(() => {
    fetchCustomers();
    fetchTags();
    fetchOpportunities();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await customersApi.list();
      setCustomers(response.data.data || []);
    } catch (error) {
      message.error('获取客户失败');
    }
  };

  const fetchTags = async () => {
    try {
      const response = await customersApi.tags.list();
      if (response.data.success) {
        setTags(response.data.data || []);
      }
    } catch (error) {
      message.error('获取标签失败');
    }
  };

  const fetchOpportunities = async () => {
    try {
      const response = await customersApi.opportunities.list();
      setOpportunities(response.data.data || []);
    } catch (error) {
      message.error('获取商机失败');
    }
  };

  const fetchFollowups = async () => {
    try {
      const response = await customersApi.followups.list();
      if (response.data.success) {
        setFollowups(response.data.data || []);
      }
    } catch (error) {
      message.error('获取跟进记录失败');
    }
  };

  const handleSubmit = async (values: unknown) => {
    try {
      if (modalType === 'tag') {
        if (editingItem) {
          await customersApi.tags.update((editingItem as { id: string }).id, values);
          message.success('标签更新成功');
        } else {
          await customersApi.tags.create(values);
          message.success('标签创建成功');
        }
        fetchTags();
      } else if (modalType === 'opportunity') {
        if (editingItem) {
          await customersApi.opportunities.update((editingItem as { id: string }).id, values);
          message.success('商机更新成功');
        } else {
          await customersApi.opportunities.create(values);
          message.success('商机创建成功');
        }
        fetchOpportunities();
      } else if (modalType === 'followup') {
        await customersApi.followups.create(values);
        message.success('跟进记录添加成功');
        fetchFollowups();
      }
      setModalVisible(false);
      setEditingItem(null);
      form.resetFields();
    } catch (error) {
      message.error('操作失败');
    }
  };

  const handleDelete = async (type: string, id: string) => {
    try {
      if (type === 'tag') await customersApi.tags.delete(id);
      else if (type === 'opportunity') await customersApi.opportunities.delete(id);
      else if (type === 'followup') await customersApi.followups.delete(id);
      message.success('删除成功');
      if (type === 'tag') fetchTags();
      else if (type === 'opportunity') fetchOpportunities();
      else if (type === 'followup') fetchFollowups();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const openModal = (type: 'tag' | 'opportunity' | 'followup', item?: unknown) => {
    setModalType(type);
    if (item) {
      setEditingItem(item);
      form.setFieldsValue(item);
    } else {
      setEditingItem(null);
      form.resetFields();
    }
    setModalVisible(true);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">客户管理</h1>

      <Tabs activeKey={activeTab} onChange={setActiveTab} className="mb-6">
        <Tabs.TabPane tab="客户列表" key="customers" />
        <Tabs.TabPane tab="标签管理" key="tags" />
        <Tabs.TabPane tab="商机管道" key="opportunities" />
        <Tabs.TabPane tab="跟进记录" key="followups" />
      </Tabs>

      {activeTab === 'customers' && (
        <Card title="客户列表">
          <div className="flex gap-4 mb-4">
            <Input placeholder="搜索客户" className="w-64" />
            <Select placeholder="按标签筛选" className="w-48">
              {(tags as { id: string; name: string }[]).map((t) => (
                <Option key={t.id} value={t.id}>{t.name}</Option>
              ))}
            </Select>
            <Button type="primary" icon={<PlusOutlined />}>添加客户</Button>
          </div>
          <Table
            columns={[
              { title: '公司名称', dataIndex: 'companyName', key: 'companyName' },
              { title: '联系人', dataIndex: 'contactPerson', key: 'contactPerson' },
              { title: '邮箱', dataIndex: 'email', key: 'email' },
              { title: '电话', dataIndex: 'phone', key: 'phone' },
              {
                title: '标签',
                dataIndex: 'tags',
                key: 'tags',
                render: (ts) => (
                  <div className="flex flex-wrap gap-1">
                    {(ts as { name: string; color: string }[]).map((t) => (
                      <Tag key={t.name} color={t.color}>{t.name}</Tag>
                    ))}
                  </div>
                ),
              },
              {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (status: string) => <Tag>{getStatusText(status)}</Tag>,
              },
              { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', render: formatDate },
              {
                title: '操作',
                key: 'action',
                render: () => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" />
                    <Button size="small" onClick={() => openModal('followup')}>添加跟进</Button>
                  </div>
                ),
              },
            ]}
            dataSource={customers as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'tags' && (
        <Card title="标签管理" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('tag')}>创建标签</Button>}>
          <Table
            columns={[
              { title: '标签名称', dataIndex: 'name', key: 'name' },
              { title: '颜色', dataIndex: 'color', key: 'color', render: (c: string) => <div className="w-8 h-8 rounded" style={{ backgroundColor: c }} /> },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string }) => (
                  <div className="flex gap-2">
                    <Button icon={<EditOutlined />} size="small" onClick={() => openModal('tag', record)} />
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('tag', record.id)} />
                  </div>
                ),
              },
            ]}
            dataSource={tags as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'opportunities' && (
        <Card title="商机管道" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('opportunity')}>创建商机</Button>}>
          <div className="grid grid-cols-5 gap-4">
            {['初步接触', '需求确认', '报价', '谈判', '成交'].map((stage) => (
              <div key={stage} className="bg-gray-50 p-4 rounded">
                <h3 className="font-bold mb-4">{stage}</h3>
                <div className="space-y-2">
                  {(opportunities as { stage: string; id: string; name: string; amount: number }[])
                    .filter((o) => o.stage === stage)
                    .map((o) => (
                      <div key={o.id} className="bg-white p-3 rounded shadow">
                        <div className="font-medium">{o.name}</div>
                        <div className="text-sm text-gray-500">{o.amount}</div>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {activeTab === 'followups' && (
        <Card title="跟进记录" extra={<Button icon={<PlusOutlined />} onClick={() => openModal('followup')}>添加记录</Button>}>
          <Table
            columns={[
              { title: '客户', dataIndex: 'leadName', key: 'leadName' },
              { title: '类型', dataIndex: 'type', key: 'type', render: (t: string) => (
                <Tag>{t === 'call' ? '电话' : t === 'email' ? '邮件' : t === 'meeting' ? '会议' : '备注'}</Tag>
              )},
              { title: '内容', dataIndex: 'content', key: 'content' },
              { title: '结果', dataIndex: 'result', key: 'result' },
              { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', render: formatDate },
              { title: '创建人', dataIndex: 'createdBy', key: 'createdBy' },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: { id: string }) => (
                  <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDelete('followup', record.id)} />
                ),
              },
            ]}
            dataSource={followups as { id: string }[]}
            rowKey="id"
          />
        </Card>
      )}

      <Modal
        title={modalType === 'tag' ? (editingItem ? '编辑标签' : '创建标签') :
               modalType === 'opportunity' ? (editingItem ? '编辑商机' : '创建商机') :
               '添加跟进记录'}
        visible={modalVisible}
        onCancel={() => { setModalVisible(false); setEditingItem(null); }}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={handleSubmit}>
          {modalType === 'tag' && (
            <>
              <Form.Item name="name" label="标签名称" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="color" label="标签颜色" rules={[{ required: true }]}>
                <Input type="color" />
              </Form.Item>
            </>
          )}
          {modalType === 'opportunity' && (
            <>
              <Form.Item name="name" label="商机名称" rules={[{ required: true }]}>
                <Input />
              </Form.Item>
              <Form.Item name="leadId" label="关联客户" rules={[{ required: true }]}>
                <Select>
                  {(customers as { id: string; companyName: string }[]).map((c) => (
                    <Option key={c.id} value={c.id}>{c.companyName}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name="stage" label="阶段" rules={[{ required: true }]}>
                <Select>
                  <Option value="初步接触">初步接触</Option>
                  <Option value="需求确认">需求确认</Option>
                  <Option value="报价">报价</Option>
                  <Option value="谈判">谈判</Option>
                  <Option value="成交">成交</Option>
                </Select>
              </Form.Item>
              <Form.Item name="amount" label="预估金额">
                <Input />
              </Form.Item>
              <Form.Item name="probability" label="成功率">
                <Input />
              </Form.Item>
            </>
          )}
          {modalType === 'followup' && (
            <>
              <Form.Item name="leadId" label="关联客户" rules={[{ required: true }]}>
                <Select>
                  {(customers as { id: string; companyName: string }[]).map((c) => (
                    <Option key={c.id} value={c.id}>{c.companyName}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name="type" label="跟进类型" rules={[{ required: true }]}>
                <Select>
                  <Option value="call">电话</Option>
                  <Option value="email">邮件</Option>
                  <Option value="meeting">会议</Option>
                  <Option value="note">备注</Option>
                </Select>
              </Form.Item>
              <Form.Item name="content" label="跟进内容" rules={[{ required: true }]}>
                <Input.TextArea rows={4} />
              </Form.Item>
              <Form.Item name="result" label="跟进结果">
                <Input />
              </Form.Item>
            </>
          )}
          <Form.Item>
            <Button type="primary" htmlType="submit">保存</Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};