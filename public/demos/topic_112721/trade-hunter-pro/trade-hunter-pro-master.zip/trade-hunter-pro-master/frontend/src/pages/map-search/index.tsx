import { useState, useCallback, useMemo } from 'react';
import { Card, Input, Button, Slider, List, Checkbox, message, Spin, Tag, Space, Empty, Alert } from 'antd';
import { SearchOutlined, ImportOutlined, EnvironmentOutlined, StarOutlined, GlobalOutlined, PhoneOutlined } from '@ant-design/icons';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { mapSearchApi } from '@/services/api';
import type { GooglePlace } from '@/types';

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const defaultCenter = {
  lat: 40.7128,
  lng: -74.006,
};

export const MapSearch = () => {
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');
  const [radius, setRadius] = useState(10000);
  const [results, setResults] = useState<GooglePlace[]>([]);
  const [selectedPlaceIds, setSelectedPlaceIds] = useState<Set<string>>(new Set());
  const [activePlaceId, setActivePlaceId] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>();

  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_MAPS_API_KEY,
  });

  const activePlace = useMemo(
    () => results.find((r) => r.placeId === activePlaceId) || null,
    [results, activePlaceId]
  );

  const handleSearch = useCallback(
    async (pageToken?: string) => {
      if (!keyword.trim() || !location.trim()) {
        message.warning('请输入关键词和地区');
        return;
      }
      setLoading(true);
      try {
        const response = await mapSearchApi.search({
          keyword: keyword.trim(),
          location: location.trim(),
          radius,
          pageToken,
        });
        if (response.data.success) {
          const newResults = (response.data.data?.results as GooglePlace[]) || [];
          if (pageToken) {
            setResults((prev) => [...prev, ...newResults]);
          } else {
            setResults(newResults);
            if (newResults.length > 0) {
              setMapCenter({ lat: newResults[0].latitude, lng: newResults[0].longitude });
            }
          }
          setNextPageToken(response.data.data?.nextPageToken);
          setSelectedPlaceIds(new Set());
        } else {
          message.error(response.data.message || '搜索失败');
        }
      } catch {
        message.error('搜索请求失败');
      } finally {
        setLoading(false);
      }
    },
    [keyword, location, radius]
  );

  const handleImport = useCallback(async () => {
    if (selectedPlaceIds.size === 0) {
      message.warning('请先选择要导入的商家');
      return;
    }
    setImporting(true);
    try {
      const response = await mapSearchApi.import({ placeIds: Array.from(selectedPlaceIds) });
      if (response.data.success) {
        const { imported, failed, duplicates } = response.data.data || { imported: 0, failed: 0, duplicates: 0 };
        message.success(`导入完成：成功 ${imported} 条，重复 ${duplicates} 条，失败 ${failed} 条`);
        setSelectedPlaceIds(new Set());
      } else {
        message.error(response.data.message || '导入失败');
      }
    } catch {
      message.error('导入请求失败');
    } finally {
      setImporting(false);
    }
  }, [selectedPlaceIds]);

  const toggleSelect = useCallback((placeId: string) => {
    setSelectedPlaceIds((prev) => {
      const next = new Set(prev);
      if (next.has(placeId)) {
        next.delete(placeId);
      } else {
        next.add(placeId);
      }
      return next;
    });
  }, []);

  const toggleSelectAll = useCallback(() => {
    if (selectedPlaceIds.size === results.length && results.length > 0) {
      setSelectedPlaceIds(new Set());
    } else {
      setSelectedPlaceIds(new Set(results.map((r) => r.placeId)));
    }
  }, [selectedPlaceIds.size, results]);

  return (
    <div className="h-full flex flex-col">
      <h1 className="text-2xl font-bold mb-4">地图获客</h1>

      <Card className="mb-4">
        <Space wrap className="w-full" align="center">
          <Input
            placeholder="搜索关键词，如 LED wholesaler"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onPressEnter={() => handleSearch()}
            style={{ width: 280 }}
            prefix={<SearchOutlined />}
          />
          <Input
            placeholder="目标地区，如 New York, USA"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            onPressEnter={() => handleSearch()}
            style={{ width: 240 }}
            prefix={<EnvironmentOutlined />}
          />
          <div className="flex items-center gap-3" style={{ width: 220 }}>
            <span className="text-sm text-gray-500 whitespace-nowrap">半径</span>
            <Slider
              min={1000}
              max={50000}
              step={1000}
              value={radius}
              onChange={setRadius}
              tooltip={{ formatter: (v) => `${(v || 0) / 1000} km` }}
              className="flex-1"
            />
            <span className="text-sm text-gray-500 whitespace-nowrap">{radius / 1000}km</span>
          </div>
          <Button type="primary" icon={<SearchOutlined />} onClick={() => handleSearch()} loading={loading}>
            搜索
          </Button>
          <Button
            type="default"
            icon={<ImportOutlined />}
            onClick={handleImport}
            loading={importing}
            disabled={selectedPlaceIds.size === 0}
          >
            导入选中 ({selectedPlaceIds.size})
          </Button>
        </Space>
      </Card>

      <div className="flex-1 flex gap-4 min-h-0">
        <Card
          className="flex-1 flex flex-col min-h-0 overflow-hidden"
          title={
            <div className="flex items-center justify-between">
              <span>
                搜索结果 {results.length > 0 ? `(${results.length})` : ''}
              </span>
              {results.length > 0 && (
                <Checkbox
                  checked={selectedPlaceIds.size === results.length && results.length > 0}
                  indeterminate={selectedPlaceIds.size > 0 && selectedPlaceIds.size < results.length}
                  onChange={toggleSelectAll}
                >
                  全选
                </Checkbox>
              )}
            </div>
          }
          bodyStyle={{ padding: 0, overflow: 'auto', flex: 1 }}
        >
          {results.length === 0 && !loading && (
            <Empty description="请输入条件进行搜索" className="mt-12" />
          )}

          <List
            dataSource={results}
            loading={loading}
            renderItem={(item) => (
              <List.Item
                className={`cursor-pointer transition-colors hover:bg-gray-50 ${selectedPlaceIds.has(item.placeId) ? 'bg-blue-50' : ''} ${activePlaceId === item.placeId ? 'border-l-4 border-l-primary-500' : ''}`}
                onClick={() => {
                  setActivePlaceId(item.placeId);
                  setMapCenter({ lat: item.latitude, lng: item.longitude });
                }}
                actions={[
                  <Checkbox
                    checked={selectedPlaceIds.has(item.placeId)}
                    onChange={(e) => {
                      e.stopPropagation();
                      toggleSelect(item.placeId);
                    }}
                  />,
                ]}
              >
                <List.Item.Meta
                  title={
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{item.name}</span>
                      {item.rating !== undefined && (
                        <Tag color="orange" icon={<StarOutlined />}>
                          {item.rating}
                        </Tag>
                      )}
                    </div>
                  }
                  description={
                    <div className="text-xs text-gray-500 space-y-1">
                      <div className="flex items-center gap-1">
                        <EnvironmentOutlined />
                        <span className="truncate max-w-xs">{item.address}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        {item.phone && (
                          <span className="flex items-center gap-1">
                            <PhoneOutlined />
                            {item.phone}
                          </span>
                        )}
                        {item.website && (
                          <span className="flex items-center gap-1">
                            <GlobalOutlined />
                            <a href={item.website} target="_blank" rel="noreferrer" className="text-primary-500 truncate max-w-xs" onClick={(e) => e.stopPropagation()}>
                              {item.website}
                            </a>
                          </span>
                        )}
                      </div>
                    </div>
                  }
                />
              </List.Item>
            )}
          />

          {nextPageToken && (
            <div className="p-4 text-center">
              <Button loading={loading} onClick={() => handleSearch(nextPageToken)}>
                加载更多
              </Button>
            </div>
          )}
        </Card>

        <Card className="flex-1 min-h-0" bodyStyle={{ padding: 0, height: '100%' }}>
          {loadError && (
            <Alert
              message="地图加载失败"
              description="请检查 Google Maps API Key 是否配置正确（VITE_GOOGLE_MAPS_API_KEY）"
              type="error"
              showIcon
              className="m-4"
            />
          )}
          {!GOOGLE_MAPS_API_KEY && !loadError && (
            <Alert
              message="地图未配置"
              description="请在环境变量中配置 VITE_GOOGLE_MAPS_API_KEY 以显示地图"
              type="warning"
              showIcon
              className="m-4"
            />
          )}
          {isLoaded ? (
            <GoogleMap mapContainerStyle={mapContainerStyle} center={mapCenter} zoom={13}>
              {results.map((item) => (
                <Marker
                  key={item.placeId}
                  position={{ lat: item.latitude, lng: item.longitude }}
                  onClick={() => setActivePlaceId(item.placeId)}
                />
              ))}
              {activePlace && (
                <InfoWindow
                  position={{ lat: activePlace.latitude, lng: activePlace.longitude }}
                  onCloseClick={() => setActivePlaceId(null)}
                >
                  <div className="max-w-xs">
                    <h4 className="font-bold mb-1">{activePlace.name}</h4>
                    <p className="text-xs text-gray-600 mb-1">{activePlace.address}</p>
                    {activePlace.rating !== undefined && (
                      <p className="text-xs text-orange-500 mb-1">
                        <StarOutlined /> {activePlace.rating} ({activePlace.reviewCount || 0} 评论)
                      </p>
                    )}
                    {activePlace.phone && (
                      <p className="text-xs text-gray-600 mb-1">
                        <PhoneOutlined /> {activePlace.phone}
                      </p>
                    )}
                    {activePlace.website && (
                      <p className="text-xs">
                        <GlobalOutlined />{' '}
                        <a href={activePlace.website} target="_blank" rel="noreferrer" className="text-primary-500">
                          访问网站
                        </a>
                      </p>
                    )}
                    <div className="mt-2">
                      <Button
                        size="small"
                        type={selectedPlaceIds.has(activePlace.placeId) ? 'default' : 'primary'}
                        onClick={() => toggleSelect(activePlace.placeId)}
                      >
                        {selectedPlaceIds.has(activePlace.placeId) ? '取消选择' : '选择导入'}
                      </Button>
                    </div>
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
          ) : (
            <div className="flex items-center justify-center h-full">
              <Spin tip="加载地图中..." />
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};
