import { useState, useEffect } from 'react';
import { Card, Tabs, Form, Input, Select, Button, Table, Tag, message, Modal, InputNumber, Space } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { marketApi } from '@/services/api';
import { formatDate } from '@/utils';
import type { Product, Keyword, TargetCountry } from '@/types';

const { Option } = Select;

const COUNTRY_OPTIONS = [
  { code: 'US', name: '美国' },
  { code: 'GB', name: '英国' },
  { code: 'DE', name: '德国' },
  { code: 'FR', name: '法国' },
  { code: 'IT', name: '意大利' },
  { code: 'ES', name: '西班牙' },
  { code: 'CA', name: '加拿大' },
  { code: 'AU', name: '澳大利亚' },
  { code: 'JP', name: '日本' },
  { code: 'KR', name: '韩国' },
  { code: 'SG', name: '新加坡' },
  { code: 'MY', name: '马来西亚' },
  { code: 'TH', name: '泰国' },
  { code: 'VN', name: '越南' },
  { code: 'BR', name: '巴西' },
  { code: 'MX', name: '墨西哥' },
  { code: 'RU', name: '俄罗斯' },
  { code: 'ZA', name: '南非' },
  { code: 'AE', name: '阿联酋' },
  { code: 'NL', name: '荷兰' },
  { code: 'BE', name: '比利时' },
  { code: 'PL', name: '波兰' },
  { code: 'SE', name: '瑞典' },
  { code: 'CH', name: '瑞士' },
];

export const MarketConfig = () => {
  const [activeTab, setActiveTab] = useState('config');
  const [products, setProducts] = useState<Product[]>([]);
  const [productPagination, setProductPagination] = useState({ current: 1, pageSize: 10, total: 0 });
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [countries, setCountries] = useState<TargetCountry[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingKeyword, setEditingKeyword] = useState<Keyword | null>(null);
  const [productModalVisible, setProductModalVisible] = useState(false);
  const [keywordModalVisible, setKeywordModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [productForm] = Form.useForm();
  const [keywordForm] = Form.useForm();

  useEffect(() => {
    fetchConfig();
    fetchProducts(1, 10);
    fetchKeywords();
    fetchCountries();
  }, []);

  const fetchConfig = async () => {
    try {
      const response = await marketApi.config.get();
      if (response.data.success) {
        form.setFieldsValue(response.data.data);
      }
    } catch {
      message.error('获取配置失败');
    }
  };

  const fetchProducts = async (page: number, pageSize: number) => {
    try {
      const response = await marketApi.products.list({ page, pageSize });
      if (response.data.success) {
        setProducts((response.data.data?.data as Product[]) || []);
        setProductPagination({
          current: response.data.data?.page || page,
          pageSize: response.data.data?.pageSize || pageSize,
          total: response.data.data?.total || 0,
        });
      }
    } catch {
      message.error('获取产品列表失败');
    }
  };

  const fetchKeywords = async () => {
    try {
      const response = await marketApi.keywords.list();
      if (response.data.success) {
        setKeywords((response.data.data as Keyword[]) || []);
      }
    } catch {
      message.error('获取关键词失败');
    }
  };

  const fetchCountries = async () => {
    try {
      const response = await marketApi.countries.list();
      if (response.data.success) {
        setCountries((response.data.data as TargetCountry[]) || []);
      }
    } catch {
      message.error('获取目标国家失败');
    }
  };

  const handleConfigSubmit = async (values: Record<string, unknown>) => {
    try {
      const response = await marketApi.config.update(values);
      if (response.data.success) {
        message.success('配置更新成功');
      }
    } catch {
      message.error('配置更新失败');
    }
  };

  const handleProductSubmit = async (values: Record<string, unknown>) => {
    try {
      if (editingProduct) {
        await marketApi.products.update(editingProduct.id, values);
        message.success('产品更新成功');
      } else {
        await marketApi.products.create(values);
        message.success('产品创建成功');
      }
      setProductModalVisible(false);
      setEditingProduct(null);
      productForm.resetFields();
      fetchProducts(productPagination.current, productPagination.pageSize);
    } catch {
      message.error(editingProduct ? '产品更新失败' : '产品创建失败');
    }
  };

  const handleKeywordSubmit = async (values: Record<string, unknown>) => {
    try {
      if (editingKeyword) {
        await marketApi.keywords.update(editingKeyword.id, values);
        message.success('关键词更新成功');
      } else {
        await marketApi.keywords.create(values);
        message.success('关键词创建成功');
      }
      setKeywordModalVisible(false);
      setEditingKeyword(null);
      keywordForm.resetFields();
      fetchKeywords();
    } catch {
      message.error(editingKeyword ? '关键词更新失败' : '关键词创建失败');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      await marketApi.products.delete(id);
      message.success('产品删除成功');
      fetchProducts(productPagination.current, productPagination.pageSize);
    } catch {
      message.error('产品删除失败');
    }
  };

  const handleDeleteKeyword = async (id: string) => {
    try {
      await marketApi.keywords.delete(id);
      message.success('关键词删除成功');
      fetchKeywords();
    } catch {
      message.error('关键词删除失败');
    }
  };

  const handleAddCountry = async () => {
    if (!selectedCountry) {
      message.warning('请选择国家');
      return;
    }
    const country = COUNTRY_OPTIONS.find((c) => c.code === selectedCountry);
    if (!country) return;
    try {
      await marketApi.countries.create({
        countryCode: country.code,
        countryName: country.name,
      });
      message.success('添加成功');
      setSelectedCountry('');
      fetchCountries();
    } catch {
      message.error('添加失败，请确保已保存基本配置');
    }
  };

  const handleDeleteCountry = async (id: string) => {
    try {
      await marketApi.countries.delete(id);
      message.success('删除成功');
      fetchCountries();
    } catch {
      message.error('删除失败');
    }
  };

  const openProductModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      productForm.setFieldsValue(product);
    } else {
      setEditingProduct(null);
      productForm.resetFields();
    }
    setProductModalVisible(true);
  };

  const openKeywordModal = (keyword?: Keyword) => {
    if (keyword) {
      setEditingKeyword(keyword);
      keywordForm.setFieldsValue(keyword);
    } else {
      setEditingKeyword(null);
      keywordForm.resetFields();
    }
    setKeywordModalVisible(true);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">市场配置</h1>

      <Tabs activeKey={activeTab} onChange={setActiveTab} className="mb-6">
        <Tabs.TabPane tab="基本配置" key="config" />
        <Tabs.TabPane tab="产品管理" key="products" />
        <Tabs.TabPane tab="关键词" key="keywords" />
        <Tabs.TabPane tab="目标国家" key="countries" />
      </Tabs>

      {activeTab === 'config' && (
        <Card title="基本配置">
          <Form form={form} layout="vertical" onFinish={handleConfigSubmit} size="large">
            <div className="grid grid-cols-2 gap-6">
              <Form.Item name="targetRegion" label="目标区域" rules={[{ required: true, message: '请选择目标区域' }]}>
                <Select placeholder="请选择目标区域">
                  <Option value="europe">欧洲</Option>
                  <Option value="north_america">北美</Option>
                  <Option value="southeast_asia">东南亚</Option>
                  <Option value="middle_east">中东</Option>
                  <Option value="south_america">南美</Option>
                  <Option value="global">全球</Option>
                </Select>
              </Form.Item>
              <Form.Item name="customerType" label="客户类型" rules={[{ required: true, message: '请选择客户类型' }]}>
                <Select placeholder="请选择客户类型">
                  <Option value="wholesaler">批发商</Option>
                  <Option value="retailer">零售商</Option>
                  <Option value="ecommerce">电商卖家</Option>
                  <Option value="brand">品牌商</Option>
                </Select>
              </Form.Item>
              <Form.Item name="customerSize" label="客户规模">
                <Select placeholder="请选择客户规模" allowClear>
                  <Option value="small">小微企业</Option>
                  <Option value="medium">中型企业</Option>
                  <Option value="large">大型企业</Option>
                </Select>
              </Form.Item>
              <Form.Item name="languages" label="语言偏好">
                <Select mode="multiple" placeholder="请选择语言" allowClear>
                  <Option value="en">英语</Option>
                  <Option value="de">德语</Option>
                  <Option value="fr">法语</Option>
                  <Option value="es">西班牙语</Option>
                  <Option value="it">意大利语</Option>
                </Select>
              </Form.Item>
            </div>
            <Form.Item>
              <Button type="primary" htmlType="submit">保存配置</Button>
            </Form.Item>
          </Form>
        </Card>
      )}

      {activeTab === 'products' && (
        <Card title="产品管理" extra={<Button icon={<PlusOutlined />} onClick={() => openProductModal()}>添加产品</Button>}>
          <Table
            columns={[
              { title: '产品名称', dataIndex: 'name', key: 'name' },
              { title: '主品类', dataIndex: 'category', key: 'category' },
              { title: '子品类', dataIndex: 'subCategory', key: 'subCategory' },
              { title: '价格范围', key: 'price', render: (_: unknown, record: Product) => `${record.priceMin} - ${record.priceMax}` },
              { title: 'MOQ', dataIndex: 'moq', key: 'moq' },
              { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', render: formatDate },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: Product) => (
                  <Space>
                    <Button icon={<EditOutlined />} size="small" onClick={() => openProductModal(record)} />
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDeleteProduct(record.id)} />
                  </Space>
                ),
              },
            ]}
            dataSource={products}
            rowKey="id"
            pagination={{
              current: productPagination.current,
              pageSize: productPagination.pageSize,
              total: productPagination.total,
              onChange: (page, pageSize) => fetchProducts(page, pageSize || 10),
            }}
          />
        </Card>
      )}

      {activeTab === 'keywords' && (
        <Card title="关键词管理" extra={<Button icon={<PlusOutlined />} onClick={() => openKeywordModal()}>添加关键词</Button>}>
          <Table
            columns={[
              { title: '关键词', dataIndex: 'keyword', key: 'keyword' },
              { title: '类型', dataIndex: 'type', key: 'type', render: (t: 'include' | 'exclude') => <Tag color={t === 'include' ? 'green' : 'red'}>{t === 'include' ? '包含' : '排除'}</Tag> },
              { title: '权重', dataIndex: 'weight', key: 'weight' },
              {
                title: '操作',
                key: 'action',
                render: (_: unknown, record: Keyword) => (
                  <Space>
                    <Button icon={<EditOutlined />} size="small" onClick={() => openKeywordModal(record)} />
                    <Button icon={<DeleteOutlined />} size="small" danger onClick={() => handleDeleteKeyword(record.id)} />
                  </Space>
                ),
              },
            ]}
            dataSource={keywords}
            rowKey="id"
          />
        </Card>
      )}

      {activeTab === 'countries' && (
        <Card title="目标国家">
          <Space className="mb-4">
            <Select
              style={{ width: 200 }}
              placeholder="选择国家"
              value={selectedCountry || undefined}
              onChange={setSelectedCountry}
              allowClear
            >
              {COUNTRY_OPTIONS.map((c) => (
                <Option key={c.code} value={c.code}>{c.name}</Option>
              ))}
            </Select>
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAddCountry}>添加</Button>
          </Space>
          <div className="flex flex-wrap gap-2">
            {countries.map((c) => (
              <Tag key={c.id} color="blue" closable onClose={() => handleDeleteCountry(c.id)}>
                {c.countryName}
              </Tag>
            ))}
          </div>
        </Card>
      )}

      <Modal
        title={editingProduct ? '编辑产品' : '添加产品'}
        open={productModalVisible}
        onCancel={() => { setProductModalVisible(false); setEditingProduct(null); }}
        footer={null}
      >
        <Form form={productForm} layout="vertical" onFinish={handleProductSubmit}>
          <Form.Item name="name" label="产品名称" rules={[{ required: true, message: '请输入产品名称' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="category" label="主品类" rules={[{ required: true, message: '请选择主品类' }]}>
            <Select placeholder="请选择主品类">
              <Option value="consumer_electronics">消费电子</Option>
              <Option value="apparel">服装纺织</Option>
              <Option value="machinery">机械设备</Option>
              <Option value="home_goods">家居用品</Option>
              <Option value="toys">玩具礼品</Option>
            </Select>
          </Form.Item>
          <Form.Item name="subCategory" label="子品类">
            <Input placeholder="请输入子品类" />
          </Form.Item>
          <Form.Item name="priceMin" label="最低价格" rules={[{ required: true, message: '请输入最低价格' }]}>
            <InputNumber style={{ width: '100%' }} min={0} />
          </Form.Item>
          <Form.Item name="priceMax" label="最高价格" rules={[{ required: true, message: '请输入最高价格' }]}>
            <InputNumber style={{ width: '100%' }} min={0} />
          </Form.Item>
          <Form.Item name="moq" label="起订量" rules={[{ required: true, message: '请输入起订量' }]}>
            <InputNumber style={{ width: '100%' }} min={1} />
          </Form.Item>
          <Form.Item name="description" label="产品描述">
            <Input.TextArea rows={3} placeholder="请输入产品描述" />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>保存</Button>
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title={editingKeyword ? '编辑关键词' : '添加关键词'}
        open={keywordModalVisible}
        onCancel={() => { setKeywordModalVisible(false); setEditingKeyword(null); }}
        footer={null}
      >
        <Form form={keywordForm} layout="vertical" onFinish={handleKeywordSubmit}>
          <Form.Item name="keyword" label="关键词" rules={[{ required: true, message: '请输入关键词' }]}>
            <Input placeholder="请输入关键词" />
          </Form.Item>
          <Form.Item name="type" label="类型" rules={[{ required: true, message: '请选择类型' }]}>
            <Select placeholder="请选择类型">
              <Option value="include">包含</Option>
              <Option value="exclude">排除</Option>
            </Select>
          </Form.Item>
          <Form.Item name="weight" label="权重" rules={[{ required: true, message: '请输入权重' }]}>
            <InputNumber style={{ width: '100%' }} min={1} max={10} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>保存</Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};
