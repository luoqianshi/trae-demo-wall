import { useState } from 'react';
import { Form, Input, Button, Card, message, Typography, Divider, Checkbox } from 'antd';
import { UserOutlined, LockOutlined, MailOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { authApi } from '@/services/api';

const { Title, Text } = Typography;

export const Login = () => {
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();

  const handleSubmit = async (values: { email: string; password: string }) => {
    setLoading(true);
    try {
      const response = await authApi.login(values);
      if (response.data.success) {
        const { token, user } = response.data.data as { token: string; user: unknown };
        login(token, user as any);
        message.success('登录成功');
        // 导航由 PublicRoute 的 useEffect 处理
      } else {
        message.error(response.data.message);
      }
    } catch (error) {
      message.error('登录失败，请检查邮箱或密码');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 via-white to-gold-50 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <div className="text-center mb-6">
          <Title level={2} className="text-primary-600">TradeHunter Pro</Title>
          <Text className="text-gray-500">外贸智能获客系统</Text>
        </div>

        <Form
          name="login"
          onFinish={handleSubmit}
          layout="vertical"
          size="large"
        >
          <Form.Item
            name="email"
            label="邮箱"
            rules={[
              { required: true, message: '请输入邮箱' },
              { type: 'email', message: '请输入有效的邮箱' },
            ]}
          >
            <Input prefix={<MailOutlined />} placeholder="请输入邮箱" />
          </Form.Item>

          <Form.Item
            name="password"
            label="密码"
            rules={[{ required: true, message: '请输入密码' }]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="请输入密码" />
          </Form.Item>

          <Form.Item className="flex justify-between items-center">
            <Form.Item name="remember" valuePropName="checked" noStyle>
              <Checkbox>记住我</Checkbox>
            </Form.Item>
            <Link to="/forgot-password" className="text-primary-600">忘记密码?</Link>
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading} className="w-full">
              登录
            </Button>
          </Form.Item>
        </Form>

        <Divider plain>或者</Divider>

        <div className="flex gap-4">
          <Button className="flex-1" icon={<UserOutlined />}>
            Google登录
          </Button>
          <Button className="flex-1">
            LinkedIn登录
          </Button>
        </div>

        <div className="text-center mt-4">
          <Text>还没有账号? </Text>
          <Link to="/register" className="text-primary-600 font-medium">立即注册</Link>
        </div>
      </Card>
    </div>
  );
};