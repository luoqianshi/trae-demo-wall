from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, List

app = FastAPI(title="TradeHunter Pro AI Service", version="1.0")

class LeadAnalysisRequest(BaseModel):
    companyName: str
    description: Optional[str] = ""
    website: Optional[str] = ""
    industry: Optional[str] = ""

class LeadAnalysisResponse(BaseModel):
    score: int
    grade: str
    summary: str
    tags: List[str]
    confidence: float

class EmailGenerationRequest(BaseModel):
    leadId: str
    companyName: str
    contactName: str
    email: str
    product: str
    templateType: str = "introduction"

class EmailGenerationResponse(BaseModel):
    subject: str
    body: str
    language: str
    quality: str

class TaskResultRequest(BaseModel):
    taskId: str
    status: str
    data: dict

@app.post("/analyze-lead", response_model=LeadAnalysisResponse)
async def analyze_lead(request: LeadAnalysisRequest):
    return {
        "score": 85,
        "grade": "A",
        "summary": f"{request.companyName} is a high-value potential customer in the {request.industry or 'unknown'} industry.",
        "tags": ["potential", "high-value", request.industry or "general"],
        "confidence": 0.85,
    }

@app.post("/generate-email", response_model=EmailGenerationResponse)
async def generate_email(request: EmailGenerationRequest):
    return {
        "subject": f"Introduction to {request.product} Solutions",
        "body": f"Dear {request.contactName},\n\nI hope this email finds you well. We noticed {request.companyName} is doing great work in your industry.\n\nWe would like to introduce our {request.product} solutions that could help your business grow.\n\nBest regards,\nTradeHunter Pro Team",
        "language": "English",
        "quality": "high",
    }

@app.post("/process-task")
async def process_task(request: TaskResultRequest):
    return {"status": "success", "message": "Task processed successfully"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "tradehunter-ai"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)