#!/bin/bash
echo "正在启动 FastTicket AI Demo..."
node server.js
