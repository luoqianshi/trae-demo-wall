@echo off
chcp 65001 >nul
echo 正在启动 FastTicket AI Demo...
node server.js
pause
