# FastTicket AI 演示说明

## 离线演示方式（无需安装依赖）

本目录已包含构建产物 `dist/` 和零依赖 Node 静态服务器，无需 `node_modules` 即可演示。

### Windows

双击运行：

```
start.bat
```

然后浏览器访问：

```
http://localhost:4173
```

### macOS / Linux

```bash
chmod +x start.sh
./start.sh
```

然后浏览器访问：

```
http://localhost:4173
```

### 手动启动

如果已安装 Node.js：

```bash
node server.js
```

## 开发方式（需要安装依赖）

```bash
npm install
npm run dev
```

## 注意事项

- 本项目为 AI 购票策略模拟 Demo，不连接真实票务平台，不提供自动抢票功能
- 演示时使用 Google Fonts，建议保持网络连接以获得最佳字体效果；无网络时会自动回退到系统字体
