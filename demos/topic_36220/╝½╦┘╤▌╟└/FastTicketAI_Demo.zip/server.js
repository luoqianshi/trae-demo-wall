import http from 'http'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const PORT = process.env.PORT || 4173
const DIST_DIR = path.join(__dirname, 'dist')

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
}

function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase()
  return MIME_TYPES[ext] || 'application/octet-stream'
}

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url.split('?')[0])

  // SPA fallback
  let filePath = path.join(DIST_DIR, urlPath)
  if (urlPath.endsWith('/')) {
    filePath = path.join(filePath, 'index.html')
  } else if (!path.extname(filePath)) {
    const withHtml = filePath + '.html'
    if (fs.existsSync(withHtml)) {
      filePath = withHtml
    } else {
      filePath = path.join(DIST_DIR, 'index.html')
    }
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // Fallback to index.html for client-side routes
        const indexFile = path.join(DIST_DIR, 'index.html')
        fs.readFile(indexFile, (indexErr, indexData) => {
          if (indexErr) {
            res.writeHead(404)
            res.end('Not Found')
            return
          }
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
          res.end(indexData)
        })
      } else {
        res.writeHead(500)
        res.end('Server Error')
      }
      return
    }

    res.writeHead(200, { 'Content-Type': getMimeType(filePath) })
    res.end(data)
  })
})

server.listen(PORT, () => {
  console.log(`\n✅ FastTicket AI Demo 已启动`)
  console.log(`🌐 打开浏览器访问: http://localhost:${PORT}`)
  console.log(`⚠️  如需联网字体请保持网络畅通，否则将回退到系统字体`)
  console.log(`📦 按 Ctrl+C 停止服务\n`)
})
